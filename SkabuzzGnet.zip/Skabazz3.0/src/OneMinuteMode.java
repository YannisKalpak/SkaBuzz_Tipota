import java.util.ArrayList;
import java.util.Scanner;

public class OneMinuteMode extends Modes {
	
	public OneMinuteMode(DataBase questionsData,String currentCategory,int currentCategoryPos,Players[] allPlayers) {
		ModeName = "One Minute Mode";
		importData(questionsData,currentCategory,currentCategoryPos,allPlayers);
		
	}	
	
	
	public void run() {
		ModeAvailable = false;
		QuestionsData.CompleteStack( CurrentCategoryPos );
		boolean TimerRunOut = false;
		
		Scanner input = new Scanner(System.in);
		makeList();
		
		int QuestionsAnswered = 0;
		ArrayList<Integer> QuestionPos = new ArrayList<>();
		
		for(int i=0;i<20;i++) {
			QuestionPos.add(QuestionsData.PickingStack.peek());
			QuestionsData.PickingStack.pop();
		}


		long TimeStart = System.currentTimeMillis();
		long TimerEnd = TimeStart + 60 * 1000; // 60 seconds * 1000 ms/sec
		

		for(Players CurrentPlayer : PlayersList) {
			QuestionsAnswered=0;
			while( !TimerRunOut  && QuestionsAnswered<20 ) {
				int CurrentQuestion = QuestionsData.PickingStack.peek();
				
				System.out.println(QuestionsData.Questions[CurrentQuestion]);            // ta minimata afta tha emfanizontai sto GUI
				System.out.println(QuestionsData.Answers[CurrentQuestion][0] + " " + QuestionsData.Answers[CurrentQuestion][1]);
				System.out.println(QuestionsData.Answers[CurrentQuestion][2] + " " + QuestionsData.Answers[CurrentQuestion][3]);
				
				int PlayersAnswer = input.nextInt() - 1;
				QuestionsAnswered++;
					
				if(QuestionsData.CheckAnswer(PlayersAnswer,CurrentQuestion) == true) {
					CurrentPlayer.addPoints(100);
				}
				
				if(System.currentTimeMillis() > TimerEnd) {
					TimerRunOut = true;
				}
				
		    }
		}
	}
}
