import java.util.*;

public class QuickGame extends GameType{
	
	public QuickGame() {
		String Player1Name = "Player1";
		String Player2Name = "Player2";
		String Player3Name = "Player3";
		String Player4Name = "Player4";
		
		AllPlayers[0] = new Players(Player1Name);
		AllPlayers[1] = new Players(Player2Name);
		AllPlayers[2] = new Players(Player3Name);
		AllPlayers[3] = new Players(Player4Name);
		
		for(int i=0;i<4;i++) {
			PlayersList.add( AllPlayers[i] );
		}
	}
	
	public void run() {
		DataBase QuestionsData = new DataBase();
		Scanner input = new Scanner(System.in);
		QuestionsData.CompleteStack(0);
		
		int RoundsPickedByPlayers=2;
		
		for(int i=0;i<RoundsPickedByPlayers;i++) {
			for(int j=0;j<8;j++) {
				for(Players CurrentPlayer : PlayersList){

					int CurrentQuestion = QuestionsData.PickingStack.peek() + j * 50;
					
					System.out.println(QuestionsData.Questions[CurrentQuestion]);            // ta minimata afta tha emfanizontai sto GUI
					System.out.println(QuestionsData.Answers[CurrentQuestion][0] + "     " + QuestionsData.Answers[CurrentQuestion][1]);
					System.out.println(QuestionsData.Answers[CurrentQuestion][2] + "     " + QuestionsData.Answers[CurrentQuestion][3]);
					

					int PlayersAnswer = input.nextInt() - 1;
					
					if(QuestionsData.CheckAnswer(PlayersAnswer,CurrentQuestion) == true) {
						System.out.println("Μπράβο απάντησες σωστά");
						CurrentPlayer.addPoints(100);
					}
					else {
						System.out.println("Λάθος απάντηση");
						QuestionsData.ShowCorrectAnswer(CurrentQuestion);
					}	
					
				}		
				QuestionsData.PickingStack.pop();
			}
		}
		System.out.println( pickAWinner(PlayersList).getPlayerName() + " είναι ο νικητής " ) ;
	}
	
	
}
