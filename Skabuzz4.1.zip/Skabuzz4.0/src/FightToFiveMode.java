import java.util.*;

public class FightToFiveMode extends Modes {
    
    public FightToFiveMode(DataBase questionsData,String currentCategory,int currentCategoryPos,Players[] allPlayers) {
		ModeName = "FightToFive Mode";
		importData(questionsData,currentCategory,currentCategoryPos,allPlayers);
		
	}	

       public void run(){ 
               ModeAvailable = false;
               QuestionsData.CompleteStack( CurrentCategoryPos );    
               Scanner input = new Scanner(System.in);
               makeList();
                
               boolean ModeStillOn = true;
		int j = 0; 
                
                
                int NumberOfRightAnswers = 0;
                
                
                while(ModeStillOn){
                   for(Players CurrentPlayer : PlayersList){
                         NumberOfRightAnswers = 0;              
                     int CurrentQuestion = QuestionsData.PickingStack.peek();
			 	
		     System.out.println(QuestionsData.Questions[CurrentQuestion]);            // ta minimata afta tha emfanizontai sto GUI
		     System.out.println(QuestionsData.Answers[CurrentQuestion][0] + " 	 " + QuestionsData.Answers[CurrentQuestion][1]);
		     System.out.println(QuestionsData.Answers[CurrentQuestion][2] + "	 " + QuestionsData.Answers[CurrentQuestion][3]);
		
		       int PlayersAnswer = input.nextInt() - 1;  //edw tha epistrefete i timi analoga me to ti exei pathsei o xristis 
				
		      if(QuestionsData.CheckAnswer(PlayersAnswer,CurrentQuestion) == true){
		               NumberOfRightAnswers++;
                               NumberOfRightAnswers += NumberOfRightAnswers; 
                       }
			else {
			       System.out.println("Λάθος απάντηση");
			       QuestionsData.ShowCorrectAnswer(CurrentQuestion);   
                        }
			   
                    
                      QuestionsData.PickingStack.pop();
                    

                    }
                     
                    if(NumberOfRightAnswers == 1 ){
                        CurrentPlayer.addPoints(100);
                    
                    }
                   
                     if(NumberOfRightAnswers == 2 ){
                         CurrentPlayer.addPoints(300);
                    }
                    
                     if(NumberOfRightAnswers == 3 ){
                       CurrentPlayer.addPoints(500);
                    }
                    
                    
                     if(NumberOfRightAnswers == 4 ){
                        CurrentPlayer.addPoints(800);
                    }
                    
                     if(NumberOfRightAnswers == 5 ){
                        CurrentPlayer.addPoints(1200);
                    }
                    
                      j++;
                 
                     if( NumberOfRightAnswers == 5 || j == 30)
                                ModeStillOn = false;      
                } 
              for(int i=0;i<4;i++)
                  System.out.println(AllPlayers[i].getPoints());
       }   

 }
