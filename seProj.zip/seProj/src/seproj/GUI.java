package seproj;


public class GUI extends javax.swing.JFrame {


    public GUI() {
        initComponents();
        getContentPane().removeAll();
        getContentPane().add(openPanel);
    }

    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jScrollPane1 = new javax.swing.JScrollPane();
        jEditorPane1 = new javax.swing.JEditorPane();
        openPanel = new javax.swing.JPanel();
        openPanel1 = new javax.swing.JPanel();
        openPanelTitleLabel = new javax.swing.JLabel();
        openPanelStartBtn = new javax.swing.JButton();
        openPanelIconLabel = new javax.swing.JLabel();
        mainMenuPanel = new javax.swing.JPanel();
        mainMenuLabelPanel = new javax.swing.JPanel();
        mainMenuPanel2 = new javax.swing.JPanel();
        mainMenuTitleLabel = new javax.swing.JLabel();
        mainMenuBtnPanel = new javax.swing.JPanel();
        quickGameBtn = new javax.swing.JButton();
        arcadeGameBtn = new javax.swing.JButton();
        playerNamePanel = new javax.swing.JPanel();
        playerNameGeneralPanel = new javax.swing.JPanel();
        playerNameTitlePanel = new javax.swing.JPanel();
        playerNameTitleLabel = new javax.swing.JLabel();
        playerNameInfoPanel1 = new javax.swing.JPanel();
        playerNamePlayer1Label = new javax.swing.JLabel();
        playerNamePlayer1Field = new javax.swing.JTextField();
        playerNameInfoPanel2 = new javax.swing.JPanel();
        playerNamePlayer2Label = new javax.swing.JLabel();
        playerNamePlayer2Field = new javax.swing.JTextField();
        playerNameInfoPanel3 = new javax.swing.JPanel();
        playerNamePlayer3Label = new javax.swing.JLabel();
        playerNamePlayer3Field = new javax.swing.JTextField();
        playerNameInfoPanel4 = new javax.swing.JPanel();
        playerNamePlayer4Label = new javax.swing.JLabel();
        playerNamePlayer4Field = new javax.swing.JTextField();
        playerNameBeginBtn = new javax.swing.JButton();
        playerNameBackBtn = new javax.swing.JButton();
        classicModePanel = new javax.swing.JPanel();
        classicModeGeneralPanel = new javax.swing.JPanel();
        classicModeTitlePanel = new javax.swing.JPanel();
        classicModeTitleLabel1 = new javax.swing.JLabel();
        classicModeTitleLabel2 = new javax.swing.JLabel();
        classicModeQuestionPanel = new javax.swing.JPanel();
        classicModeQuestionScrollPane = new javax.swing.JScrollPane();
        classicModeQuestionTextArea = new javax.swing.JTextArea();
        classicModeQuestionLabel = new javax.swing.JLabel();
        classicModePlayerLabel = new javax.swing.JLabel();
        classicModeAnswerPanel = new javax.swing.JPanel();
        classicModeAnswerLabel = new javax.swing.JLabel();
        classicModeAnswer1 = new javax.swing.JButton();
        classicModeAnswer2 = new javax.swing.JButton();
        classicModeAnswer3 = new javax.swing.JButton();
        classicModeAnswer4 = new javax.swing.JButton();
        jPanel1 = new javax.swing.JPanel();
        timeattackModeQInfoLabel1 = new javax.swing.JLabel();
        timeattackModeNoOfQuestLabel1 = new javax.swing.JLabel();
        timeattackModePanel = new javax.swing.JPanel();
        timeattackModeGeneralPanel = new javax.swing.JPanel();
        timeattackModeGeneralPanel2 = new javax.swing.JPanel();
        timeattackModeTitlePanel = new javax.swing.JPanel();
        timeattackModeTitleLabel1 = new javax.swing.JLabel();
        timeattackModeTitleLabel2 = new javax.swing.JLabel();
        timeattackModeQuestionPanel = new javax.swing.JPanel();
        timeattackModeQuestionScrollPane = new javax.swing.JScrollPane();
        timeattackQuestionTextArea = new javax.swing.JTextArea();
        timeattackModeQuestionLabel = new javax.swing.JLabel();
        timeattackModePlayerLabel = new javax.swing.JLabel();
        timeattackModeAnswerPanel = new javax.swing.JPanel();
        timeattackModeAnswerLabel = new javax.swing.JLabel();
        timeattackModeAnswer1 = new javax.swing.JButton();
        timeattackModeAnswer2 = new javax.swing.JButton();
        timeattackModeAnswer3 = new javax.swing.JButton();
        timeattackModeAnswer4 = new javax.swing.JButton();
        timeattackModeInfoPanel = new javax.swing.JPanel();
        timeattackModeQInfoLabel = new javax.swing.JLabel();
        timeattackModeNoOfQuestLabel = new javax.swing.JLabel();
        timeattackModeTimeInfoLabel = new javax.swing.JLabel();
        timeattackModeTimeLabel = new javax.swing.JLabel();
        elevatorModePanel = new javax.swing.JPanel();
        elevatorModeGeneralPanel1 = new javax.swing.JPanel();
        elevatorModeGeneralPanel2 = new javax.swing.JPanel();
        elevatorModeGeneralPanel3 = new javax.swing.JPanel();
        elevatorModeTitlePanel = new javax.swing.JPanel();
        elevatorModeTitleLabel1 = new javax.swing.JLabel();
        elevatorModeTitleLabel2 = new javax.swing.JLabel();
        elevatorModeQuestionPanel = new javax.swing.JPanel();
        elevatorModeQuestionScrollPane = new javax.swing.JScrollPane();
        elevatorModeQuestionTextArea = new javax.swing.JTextArea();
        elevatorModeQuestionLabel = new javax.swing.JLabel();
        elevatorModePlayerLabel = new javax.swing.JLabel();
        elevatorModeAnswerPanel = new javax.swing.JPanel();
        elevatorModeAnswerLabel = new javax.swing.JLabel();
        elevatorModeAnswer1 = new javax.swing.JButton();
        elevatorModeAnswer2 = new javax.swing.JButton();
        elevatorModeAnswer3 = new javax.swing.JButton();
        elevatorModeAnswer4 = new javax.swing.JButton();
        elevatorModeInfoPanel = new javax.swing.JPanel();
        elevatorModeQInfoLabel = new javax.swing.JLabel();
        elevatorModeNoOfQuestLabel = new javax.swing.JLabel();
        elevatorModeTimeInfoLabel = new javax.swing.JLabel();
        elevatorModeTimeLabel = new javax.swing.JLabel();
        oneminquestModePanel = new javax.swing.JPanel();
        oneminquestModeGeneralPanel = new javax.swing.JPanel();
        oneminquestModeTitlePanel = new javax.swing.JPanel();
        oneminquestModeTitleLabel1 = new javax.swing.JLabel();
        oneminquestModeTitleLabel2 = new javax.swing.JLabel();
        oneminquestModeQuestionPanel = new javax.swing.JPanel();
        oneminquestModeQuestionScrollPane = new javax.swing.JScrollPane();
        oneminquestModeQuestionTextArea = new javax.swing.JTextArea();
        oneminquestModeQuestionLabel = new javax.swing.JLabel();
        oneminquestModePlayerLabel = new javax.swing.JLabel();
        oneminquestModeAnswerPanel = new javax.swing.JPanel();
        oneminquestModeAnswerLabel = new javax.swing.JLabel();
        oneminquestModeAnswer1 = new javax.swing.JButton();
        oneminquestModeAnswer2 = new javax.swing.JButton();
        oneminquestModeAnswer3 = new javax.swing.JButton();
        oneminquestModeAnswer4 = new javax.swing.JButton();
        oneminquestModeInfoPanel = new javax.swing.JPanel();
        oneminquestModeQInfoLabel = new javax.swing.JLabel();
        oneminquestModeNoOfQuestLabel = new javax.swing.JLabel();
        oneminquestModeTimeInfoLabel = new javax.swing.JLabel();
        oneminquestModeTimeLabel = new javax.swing.JLabel();

        jScrollPane1.setViewportView(jEditorPane1);

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        setTitle("ΣΚΑ-BUZZ ΤΙΠΟΤΑ?");
        setMaximumSize(new java.awt.Dimension(500, 500));

        openPanelTitleLabel.setFont(new java.awt.Font("Arial Black", 0, 48)); // NOI18N
        openPanelTitleLabel.setText("ΣΚΑ-BUZZ ΤΙΠΟΤΑ?");

        openPanelStartBtn.setFont(new java.awt.Font("Arial", 0, 24)); // NOI18N
        openPanelStartBtn.setText("ΕΝΑΡΞΗ");
        openPanelStartBtn.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                openPanelStartBtnActionPerformed(evt);
            }
        });

        openPanelIconLabel.setIcon(new javax.swing.ImageIcon(getClass().getResource("/seproj/f0cc2c50d18cc31ad9d4dee546f4abdec53f4c520d0e7da59b9a34c61eff.png"))); // NOI18N

        javax.swing.GroupLayout openPanel1Layout = new javax.swing.GroupLayout(openPanel1);
        openPanel1.setLayout(openPanel1Layout);
        openPanel1Layout.setHorizontalGroup(
            openPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(openPanel1Layout.createSequentialGroup()
                .addGap(150, 150, 150)
                .addComponent(openPanelTitleLabel)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, openPanel1Layout.createSequentialGroup()
                .addContainerGap(50, Short.MAX_VALUE)
                .addGroup(openPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, openPanel1Layout.createSequentialGroup()
                        .addComponent(openPanelIconLabel, javax.swing.GroupLayout.PREFERRED_SIZE, 746, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(39, 39, 39))
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, openPanel1Layout.createSequentialGroup()
                        .addComponent(openPanelStartBtn, javax.swing.GroupLayout.PREFERRED_SIZE, 275, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(279, 279, 279))))
        );
        openPanel1Layout.setVerticalGroup(
            openPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(openPanel1Layout.createSequentialGroup()
                .addGap(62, 62, 62)
                .addComponent(openPanelTitleLabel, javax.swing.GroupLayout.PREFERRED_SIZE, 46, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18)
                .addComponent(openPanelIconLabel, javax.swing.GroupLayout.PREFERRED_SIZE, 376, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(28, 28, 28)
                .addComponent(openPanelStartBtn, javax.swing.GroupLayout.PREFERRED_SIZE, 95, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(97, Short.MAX_VALUE))
        );

        javax.swing.GroupLayout openPanelLayout = new javax.swing.GroupLayout(openPanel);
        openPanel.setLayout(openPanelLayout);
        openPanelLayout.setHorizontalGroup(
            openPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, openPanelLayout.createSequentialGroup()
                .addContainerGap(208, Short.MAX_VALUE)
                .addComponent(openPanel1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(178, 178, 178))
        );
        openPanelLayout.setVerticalGroup(
            openPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(openPanelLayout.createSequentialGroup()
                .addGap(28, 28, 28)
                .addComponent(openPanel1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(49, Short.MAX_VALUE))
        );

        mainMenuPanel.setPreferredSize(new java.awt.Dimension(1201, 777));

        mainMenuTitleLabel.setFont(new java.awt.Font("Arial Black", 0, 48)); // NOI18N
        mainMenuTitleLabel.setText("ΕΠΙΛΕΞΤΕ MODE");

        javax.swing.GroupLayout mainMenuPanel2Layout = new javax.swing.GroupLayout(mainMenuPanel2);
        mainMenuPanel2.setLayout(mainMenuPanel2Layout);
        mainMenuPanel2Layout.setHorizontalGroup(
            mainMenuPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(mainMenuPanel2Layout.createSequentialGroup()
                .addGap(28, 28, 28)
                .addComponent(mainMenuTitleLabel)
                .addContainerGap(28, Short.MAX_VALUE))
        );
        mainMenuPanel2Layout.setVerticalGroup(
            mainMenuPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(mainMenuPanel2Layout.createSequentialGroup()
                .addGap(32, 32, 32)
                .addComponent(mainMenuTitleLabel, javax.swing.GroupLayout.PREFERRED_SIZE, 37, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(31, Short.MAX_VALUE))
        );

        quickGameBtn.setFont(new java.awt.Font("Arial", 0, 24)); // NOI18N
        quickGameBtn.setText("QUICK MODE");
        quickGameBtn.setPreferredSize(new java.awt.Dimension(70, 20));
        quickGameBtn.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                quickGameBtnActionPerformed(evt);
            }
        });

        arcadeGameBtn.setFont(new java.awt.Font("Arial", 0, 24)); // NOI18N
        arcadeGameBtn.setText("ARCADE MODE");
        arcadeGameBtn.setPreferredSize(new java.awt.Dimension(70, 20));
        arcadeGameBtn.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                arcadeGameBtnActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout mainMenuBtnPanelLayout = new javax.swing.GroupLayout(mainMenuBtnPanel);
        mainMenuBtnPanel.setLayout(mainMenuBtnPanelLayout);
        mainMenuBtnPanelLayout.setHorizontalGroup(
            mainMenuBtnPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(mainMenuBtnPanelLayout.createSequentialGroup()
                .addGap(152, 152, 152)
                .addGroup(mainMenuBtnPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                    .addComponent(quickGameBtn, javax.swing.GroupLayout.DEFAULT_SIZE, 218, Short.MAX_VALUE)
                    .addComponent(arcadeGameBtn, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                .addContainerGap(156, Short.MAX_VALUE))
        );
        mainMenuBtnPanelLayout.setVerticalGroup(
            mainMenuBtnPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(mainMenuBtnPanelLayout.createSequentialGroup()
                .addGap(32, 32, 32)
                .addComponent(quickGameBtn, javax.swing.GroupLayout.PREFERRED_SIZE, 70, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(62, 62, 62)
                .addComponent(arcadeGameBtn, javax.swing.GroupLayout.PREFERRED_SIZE, 70, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(46, Short.MAX_VALUE))
        );

        javax.swing.GroupLayout mainMenuLabelPanelLayout = new javax.swing.GroupLayout(mainMenuLabelPanel);
        mainMenuLabelPanel.setLayout(mainMenuLabelPanelLayout);
        mainMenuLabelPanelLayout.setHorizontalGroup(
            mainMenuLabelPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(mainMenuLabelPanelLayout.createSequentialGroup()
                .addGap(272, 272, 272)
                .addGroup(mainMenuLabelPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(mainMenuBtnPanel, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(mainMenuPanel2, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addContainerGap(248, Short.MAX_VALUE))
        );
        mainMenuLabelPanelLayout.setVerticalGroup(
            mainMenuLabelPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(mainMenuLabelPanelLayout.createSequentialGroup()
                .addGap(56, 56, 56)
                .addComponent(mainMenuPanel2, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(125, 125, 125)
                .addComponent(mainMenuBtnPanel, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(144, Short.MAX_VALUE))
        );

        javax.swing.GroupLayout mainMenuPanelLayout = new javax.swing.GroupLayout(mainMenuPanel);
        mainMenuPanel.setLayout(mainMenuPanelLayout);
        mainMenuPanelLayout.setHorizontalGroup(
            mainMenuPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, mainMenuPanelLayout.createSequentialGroup()
                .addContainerGap(87, Short.MAX_VALUE)
                .addComponent(mainMenuLabelPanel, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(68, 68, 68))
        );
        mainMenuPanelLayout.setVerticalGroup(
            mainMenuPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(mainMenuPanelLayout.createSequentialGroup()
                .addGap(31, 31, 31)
                .addComponent(mainMenuLabelPanel, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(41, Short.MAX_VALUE))
        );

        playerNamePanel.setPreferredSize(new java.awt.Dimension(1201, 777));

        playerNameTitleLabel.setFont(new java.awt.Font("Arial Black", 0, 36)); // NOI18N
        playerNameTitleLabel.setText("ΚΑΤΑΧΩΡΗΣΤΕ ΤΑ ΟΝΟΜΑΤΑ ΤΩΝ ΠΑΙΚΤΩΝ");

        javax.swing.GroupLayout playerNameTitlePanelLayout = new javax.swing.GroupLayout(playerNameTitlePanel);
        playerNameTitlePanel.setLayout(playerNameTitlePanelLayout);
        playerNameTitlePanelLayout.setHorizontalGroup(
            playerNameTitlePanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(playerNameTitlePanelLayout.createSequentialGroup()
                .addContainerGap()
                .addComponent(playerNameTitleLabel, javax.swing.GroupLayout.DEFAULT_SIZE, 888, Short.MAX_VALUE)
                .addContainerGap())
        );
        playerNameTitlePanelLayout.setVerticalGroup(
            playerNameTitlePanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, playerNameTitlePanelLayout.createSequentialGroup()
                .addContainerGap(28, Short.MAX_VALUE)
                .addComponent(playerNameTitleLabel, javax.swing.GroupLayout.PREFERRED_SIZE, 48, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(24, 24, 24))
        );

        playerNamePlayer1Label.setFont(new java.awt.Font("Arial", 0, 30)); // NOI18N
        playerNamePlayer1Label.setText("ΠΑΙΚΤΗΣ 1: ");

        playerNamePlayer1Field.setFont(new java.awt.Font("Arial", 0, 24)); // NOI18N

        javax.swing.GroupLayout playerNameInfoPanel1Layout = new javax.swing.GroupLayout(playerNameInfoPanel1);
        playerNameInfoPanel1.setLayout(playerNameInfoPanel1Layout);
        playerNameInfoPanel1Layout.setHorizontalGroup(
            playerNameInfoPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(playerNameInfoPanel1Layout.createSequentialGroup()
                .addGap(21, 21, 21)
                .addComponent(playerNamePlayer1Label, javax.swing.GroupLayout.PREFERRED_SIZE, 223, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(40, 40, 40)
                .addComponent(playerNamePlayer1Field, javax.swing.GroupLayout.PREFERRED_SIZE, 348, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(24, Short.MAX_VALUE))
        );
        playerNameInfoPanel1Layout.setVerticalGroup(
            playerNameInfoPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, playerNameInfoPanel1Layout.createSequentialGroup()
                .addContainerGap(22, Short.MAX_VALUE)
                .addGroup(playerNameInfoPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                    .addComponent(playerNamePlayer1Label, javax.swing.GroupLayout.DEFAULT_SIZE, 39, Short.MAX_VALUE)
                    .addComponent(playerNamePlayer1Field))
                .addGap(19, 19, 19))
        );

        playerNamePlayer2Label.setFont(new java.awt.Font("Arial", 0, 30)); // NOI18N
        playerNamePlayer2Label.setText("ΠΑΙΚΤΗΣ 2:");

        playerNamePlayer2Field.setFont(new java.awt.Font("Arial", 0, 24)); // NOI18N

        javax.swing.GroupLayout playerNameInfoPanel2Layout = new javax.swing.GroupLayout(playerNameInfoPanel2);
        playerNameInfoPanel2.setLayout(playerNameInfoPanel2Layout);
        playerNameInfoPanel2Layout.setHorizontalGroup(
            playerNameInfoPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(playerNameInfoPanel2Layout.createSequentialGroup()
                .addGap(21, 21, 21)
                .addComponent(playerNamePlayer2Label, javax.swing.GroupLayout.PREFERRED_SIZE, 170, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(playerNamePlayer2Field, javax.swing.GroupLayout.PREFERRED_SIZE, 348, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(25, 25, 25))
        );
        playerNameInfoPanel2Layout.setVerticalGroup(
            playerNameInfoPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, playerNameInfoPanel2Layout.createSequentialGroup()
                .addContainerGap(26, Short.MAX_VALUE)
                .addGroup(playerNameInfoPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(playerNamePlayer2Label, javax.swing.GroupLayout.PREFERRED_SIZE, 43, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(playerNamePlayer2Field))
                .addContainerGap())
        );

        playerNamePlayer3Label.setFont(new java.awt.Font("Arial", 0, 30)); // NOI18N
        playerNamePlayer3Label.setText("ΠΑΙΚΤΗΣ 3:");

        playerNamePlayer3Field.setFont(new java.awt.Font("Arial", 0, 24)); // NOI18N

        javax.swing.GroupLayout playerNameInfoPanel3Layout = new javax.swing.GroupLayout(playerNameInfoPanel3);
        playerNameInfoPanel3.setLayout(playerNameInfoPanel3Layout);
        playerNameInfoPanel3Layout.setHorizontalGroup(
            playerNameInfoPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(playerNameInfoPanel3Layout.createSequentialGroup()
                .addGap(21, 21, 21)
                .addComponent(playerNamePlayer3Label, javax.swing.GroupLayout.PREFERRED_SIZE, 170, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(playerNamePlayer3Field, javax.swing.GroupLayout.PREFERRED_SIZE, 348, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(24, 24, 24))
        );
        playerNameInfoPanel3Layout.setVerticalGroup(
            playerNameInfoPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, playerNameInfoPanel3Layout.createSequentialGroup()
                .addContainerGap(26, Short.MAX_VALUE)
                .addGroup(playerNameInfoPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(playerNamePlayer3Label, javax.swing.GroupLayout.PREFERRED_SIZE, 43, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(playerNamePlayer3Field))
                .addContainerGap())
        );

        playerNamePlayer4Label.setFont(new java.awt.Font("Arial", 0, 30)); // NOI18N
        playerNamePlayer4Label.setText("ΠΑΙΚΤΗΣ 4:");

        playerNamePlayer4Field.setFont(new java.awt.Font("Arial", 0, 24)); // NOI18N

        javax.swing.GroupLayout playerNameInfoPanel4Layout = new javax.swing.GroupLayout(playerNameInfoPanel4);
        playerNameInfoPanel4.setLayout(playerNameInfoPanel4Layout);
        playerNameInfoPanel4Layout.setHorizontalGroup(
            playerNameInfoPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(playerNameInfoPanel4Layout.createSequentialGroup()
                .addGap(21, 21, 21)
                .addComponent(playerNamePlayer4Label, javax.swing.GroupLayout.PREFERRED_SIZE, 170, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(playerNamePlayer4Field, javax.swing.GroupLayout.PREFERRED_SIZE, 348, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(22, 22, 22))
        );
        playerNameInfoPanel4Layout.setVerticalGroup(
            playerNameInfoPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, playerNameInfoPanel4Layout.createSequentialGroup()
                .addContainerGap(26, Short.MAX_VALUE)
                .addGroup(playerNameInfoPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(playerNamePlayer4Label, javax.swing.GroupLayout.PREFERRED_SIZE, 43, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(playerNamePlayer4Field))
                .addContainerGap())
        );

        playerNameBeginBtn.setFont(new java.awt.Font("Arial", 0, 24)); // NOI18N
        playerNameBeginBtn.setText("ΠΑΙΞΤΕ");

        playerNameBackBtn.setFont(new java.awt.Font("Arial", 0, 24)); // NOI18N
        playerNameBackBtn.setText("ΠΙΣΩ");
        playerNameBackBtn.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                playerNameBackBtnActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout playerNameGeneralPanelLayout = new javax.swing.GroupLayout(playerNameGeneralPanel);
        playerNameGeneralPanel.setLayout(playerNameGeneralPanelLayout);
        playerNameGeneralPanelLayout.setHorizontalGroup(
            playerNameGeneralPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(playerNameGeneralPanelLayout.createSequentialGroup()
                .addGap(243, 243, 243)
                .addGroup(playerNameGeneralPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                    .addComponent(playerNameInfoPanel4, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(playerNameInfoPanel1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(playerNameInfoPanel2, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(playerNameInfoPanel3, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, playerNameGeneralPanelLayout.createSequentialGroup()
                .addContainerGap(132, Short.MAX_VALUE)
                .addComponent(playerNameTitlePanel, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(131, 131, 131))
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, playerNameGeneralPanelLayout.createSequentialGroup()
                .addGap(24, 24, 24)
                .addComponent(playerNameBackBtn, javax.swing.GroupLayout.PREFERRED_SIZE, 197, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(playerNameBeginBtn, javax.swing.GroupLayout.PREFERRED_SIZE, 200, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(29, 29, 29))
        );
        playerNameGeneralPanelLayout.setVerticalGroup(
            playerNameGeneralPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(playerNameGeneralPanelLayout.createSequentialGroup()
                .addGap(29, 29, 29)
                .addComponent(playerNameTitlePanel, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18)
                .addComponent(playerNameInfoPanel1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(63, 63, 63)
                .addComponent(playerNameInfoPanel2, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(67, 67, 67)
                .addComponent(playerNameInfoPanel3, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(62, 62, 62)
                .addComponent(playerNameInfoPanel4, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(playerNameGeneralPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                    .addComponent(playerNameBackBtn, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(playerNameBeginBtn, javax.swing.GroupLayout.DEFAULT_SIZE, 91, Short.MAX_VALUE))
                .addContainerGap(23, Short.MAX_VALUE))
        );

        javax.swing.GroupLayout playerNamePanelLayout = new javax.swing.GroupLayout(playerNamePanel);
        playerNamePanel.setLayout(playerNamePanelLayout);
        playerNamePanelLayout.setHorizontalGroup(
            playerNamePanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(playerNamePanelLayout.createSequentialGroup()
                .addGap(20, 20, 20)
                .addComponent(playerNameGeneralPanel, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addContainerGap())
        );
        playerNamePanelLayout.setVerticalGroup(
            playerNamePanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(playerNamePanelLayout.createSequentialGroup()
                .addContainerGap()
                .addComponent(playerNameGeneralPanel, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );

        classicModePanel.setPreferredSize(new java.awt.Dimension(1201, 777));
        classicModePanel.setRequestFocusEnabled(false);

        classicModeTitleLabel1.setFont(new java.awt.Font("Arial Black", 0, 36)); // NOI18N
        classicModeTitleLabel1.setText("ΓΥΡΟΣ");

        classicModeTitleLabel2.setFont(new java.awt.Font("Arial Black", 0, 36)); // NOI18N

        javax.swing.GroupLayout classicModeTitlePanelLayout = new javax.swing.GroupLayout(classicModeTitlePanel);
        classicModeTitlePanel.setLayout(classicModeTitlePanelLayout);
        classicModeTitlePanelLayout.setHorizontalGroup(
            classicModeTitlePanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(classicModeTitlePanelLayout.createSequentialGroup()
                .addGap(216, 216, 216)
                .addComponent(classicModeTitleLabel1)
                .addGap(18, 18, 18)
                .addComponent(classicModeTitleLabel2, javax.swing.GroupLayout.PREFERRED_SIZE, 71, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(225, Short.MAX_VALUE))
        );
        classicModeTitlePanelLayout.setVerticalGroup(
            classicModeTitlePanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(classicModeTitlePanelLayout.createSequentialGroup()
                .addContainerGap()
                .addGroup(classicModeTitlePanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(classicModeTitleLabel2, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(classicModeTitleLabel1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                .addContainerGap())
        );

        classicModeQuestionScrollPane.setHorizontalScrollBarPolicy(javax.swing.ScrollPaneConstants.HORIZONTAL_SCROLLBAR_NEVER);
        classicModeQuestionScrollPane.setVerticalScrollBarPolicy(javax.swing.ScrollPaneConstants.VERTICAL_SCROLLBAR_NEVER);

        classicModeQuestionTextArea.setColumns(20);
        classicModeQuestionTextArea.setFont(new java.awt.Font("Arial", 2, 24)); // NOI18N
        classicModeQuestionTextArea.setLineWrap(true);
        classicModeQuestionTextArea.setRows(5);
        classicModeQuestionScrollPane.setViewportView(classicModeQuestionTextArea);

        classicModeQuestionLabel.setFont(new java.awt.Font("Arial", 0, 24)); // NOI18N
        classicModeQuestionLabel.setText("ΕΡΩΤΗΣΗ ΓΙΑ ΤΟΝ ΠΑΙΚΤΗ:");

        classicModePlayerLabel.setFont(new java.awt.Font("Arial", 2, 24)); // NOI18N

        javax.swing.GroupLayout classicModeQuestionPanelLayout = new javax.swing.GroupLayout(classicModeQuestionPanel);
        classicModeQuestionPanel.setLayout(classicModeQuestionPanelLayout);
        classicModeQuestionPanelLayout.setHorizontalGroup(
            classicModeQuestionPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(classicModeQuestionPanelLayout.createSequentialGroup()
                .addGap(20, 20, 20)
                .addGroup(classicModeQuestionPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(classicModeQuestionScrollPane)
                    .addGroup(classicModeQuestionPanelLayout.createSequentialGroup()
                        .addComponent(classicModeQuestionLabel)
                        .addGap(18, 18, 18)
                        .addComponent(classicModePlayerLabel, javax.swing.GroupLayout.PREFERRED_SIZE, 238, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(0, 377, Short.MAX_VALUE)))
                .addContainerGap())
        );
        classicModeQuestionPanelLayout.setVerticalGroup(
            classicModeQuestionPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, classicModeQuestionPanelLayout.createSequentialGroup()
                .addGroup(classicModeQuestionPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(classicModeQuestionLabel, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(classicModePlayerLabel, javax.swing.GroupLayout.PREFERRED_SIZE, 29, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(classicModeQuestionScrollPane, javax.swing.GroupLayout.PREFERRED_SIZE, 90, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap())
        );

        classicModeAnswerLabel.setFont(new java.awt.Font("Arial", 0, 24)); // NOI18N
        classicModeAnswerLabel.setText("ΑΠΑΝΤΗΣΕΙΣ:");

        classicModeAnswer1.setFont(new java.awt.Font("Arial", 0, 24)); // NOI18N

        classicModeAnswer2.setFont(new java.awt.Font("Arial", 0, 24)); // NOI18N

        classicModeAnswer3.setFont(new java.awt.Font("Arial", 0, 24)); // NOI18N

        classicModeAnswer4.setFont(new java.awt.Font("Arial", 0, 24)); // NOI18N

        javax.swing.GroupLayout classicModeAnswerPanelLayout = new javax.swing.GroupLayout(classicModeAnswerPanel);
        classicModeAnswerPanel.setLayout(classicModeAnswerPanelLayout);
        classicModeAnswerPanelLayout.setHorizontalGroup(
            classicModeAnswerPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(classicModeAnswerPanelLayout.createSequentialGroup()
                .addGroup(classicModeAnswerPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(classicModeAnswerLabel)
                    .addGroup(classicModeAnswerPanelLayout.createSequentialGroup()
                        .addContainerGap()
                        .addGroup(classicModeAnswerPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                            .addComponent(classicModeAnswer3, javax.swing.GroupLayout.DEFAULT_SIZE, 350, Short.MAX_VALUE)
                            .addComponent(classicModeAnswer1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 159, Short.MAX_VALUE)
                        .addGroup(classicModeAnswerPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                            .addComponent(classicModeAnswer2, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                            .addComponent(classicModeAnswer4, javax.swing.GroupLayout.DEFAULT_SIZE, 350, Short.MAX_VALUE))))
                .addGap(45, 45, 45))
        );
        classicModeAnswerPanelLayout.setVerticalGroup(
            classicModeAnswerPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(classicModeAnswerPanelLayout.createSequentialGroup()
                .addContainerGap()
                .addComponent(classicModeAnswerLabel, javax.swing.GroupLayout.PREFERRED_SIZE, 36, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(29, 29, 29)
                .addGroup(classicModeAnswerPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(classicModeAnswer1, javax.swing.GroupLayout.PREFERRED_SIZE, 80, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(classicModeAnswer2, javax.swing.GroupLayout.PREFERRED_SIZE, 80, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(64, 64, 64)
                .addGroup(classicModeAnswerPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(classicModeAnswer4, javax.swing.GroupLayout.PREFERRED_SIZE, 81, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(classicModeAnswer3, javax.swing.GroupLayout.PREFERRED_SIZE, 81, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(114, 114, 114))
        );

        timeattackModeQInfoLabel1.setFont(new java.awt.Font("Arial Narrow", 0, 30)); // NOI18N
        timeattackModeQInfoLabel1.setText("ΕΡΩΤΗΣΕΙΣ ΠΟΥ ΑΠΟΜΕΝΟΥΝ:");
        timeattackModeQInfoLabel1.setBorder(new javax.swing.border.SoftBevelBorder(javax.swing.border.BevelBorder.RAISED));

        timeattackModeNoOfQuestLabel1.setFont(new java.awt.Font("Arial Narrow", 0, 30)); // NOI18N
        timeattackModeNoOfQuestLabel1.setBorder(new javax.swing.border.SoftBevelBorder(javax.swing.border.BevelBorder.RAISED));

        javax.swing.GroupLayout jPanel1Layout = new javax.swing.GroupLayout(jPanel1);
        jPanel1.setLayout(jPanel1Layout);
        jPanel1Layout.setHorizontalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addGap(67, 67, 67)
                .addComponent(timeattackModeQInfoLabel1)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(timeattackModeNoOfQuestLabel1, javax.swing.GroupLayout.PREFERRED_SIZE, 42, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(476, Short.MAX_VALUE))
        );
        jPanel1Layout.setVerticalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addGap(14, 14, 14)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(timeattackModeNoOfQuestLabel1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(timeattackModeQInfoLabel1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                .addContainerGap())
        );

        javax.swing.GroupLayout classicModeGeneralPanelLayout = new javax.swing.GroupLayout(classicModeGeneralPanel);
        classicModeGeneralPanel.setLayout(classicModeGeneralPanelLayout);
        classicModeGeneralPanelLayout.setHorizontalGroup(
            classicModeGeneralPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(classicModeGeneralPanelLayout.createSequentialGroup()
                .addContainerGap(94, Short.MAX_VALUE)
                .addGroup(classicModeGeneralPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jPanel1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addGroup(classicModeGeneralPanelLayout.createSequentialGroup()
                        .addGap(126, 126, 126)
                        .addComponent(classicModeTitlePanel, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(classicModeGeneralPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                        .addComponent(classicModeAnswerPanel, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addComponent(classicModeQuestionPanel, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addContainerGap(102, Short.MAX_VALUE))
        );
        classicModeGeneralPanelLayout.setVerticalGroup(
            classicModeGeneralPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(classicModeGeneralPanelLayout.createSequentialGroup()
                .addGap(37, 37, 37)
                .addComponent(classicModeTitlePanel, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jPanel1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(classicModeQuestionPanel, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(classicModeAnswerPanel, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );

        javax.swing.GroupLayout classicModePanelLayout = new javax.swing.GroupLayout(classicModePanel);
        classicModePanel.setLayout(classicModePanelLayout);
        classicModePanelLayout.setHorizontalGroup(
            classicModePanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, classicModePanelLayout.createSequentialGroup()
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(classicModeGeneralPanel, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(33, 33, 33))
        );
        classicModePanelLayout.setVerticalGroup(
            classicModePanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(classicModePanelLayout.createSequentialGroup()
                .addContainerGap()
                .addComponent(classicModeGeneralPanel, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addContainerGap())
        );

        timeattackModePanel.setPreferredSize(new java.awt.Dimension(1201, 777));

        timeattackModeGeneralPanel.setPreferredSize(new java.awt.Dimension(1201, 777));

        timeattackModeTitleLabel1.setFont(new java.awt.Font("Arial Black", 0, 36)); // NOI18N
        timeattackModeTitleLabel1.setText("ΓΥΡΟΣ");

        timeattackModeTitleLabel2.setFont(new java.awt.Font("Arial Black", 0, 36)); // NOI18N

        javax.swing.GroupLayout timeattackModeTitlePanelLayout = new javax.swing.GroupLayout(timeattackModeTitlePanel);
        timeattackModeTitlePanel.setLayout(timeattackModeTitlePanelLayout);
        timeattackModeTitlePanelLayout.setHorizontalGroup(
            timeattackModeTitlePanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(timeattackModeTitlePanelLayout.createSequentialGroup()
                .addGap(216, 216, 216)
                .addComponent(timeattackModeTitleLabel1)
                .addGap(18, 18, 18)
                .addComponent(timeattackModeTitleLabel2, javax.swing.GroupLayout.PREFERRED_SIZE, 71, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(225, Short.MAX_VALUE))
        );
        timeattackModeTitlePanelLayout.setVerticalGroup(
            timeattackModeTitlePanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(timeattackModeTitlePanelLayout.createSequentialGroup()
                .addContainerGap()
                .addGroup(timeattackModeTitlePanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(timeattackModeTitleLabel2, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(timeattackModeTitleLabel1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                .addContainerGap())
        );

        timeattackModeQuestionScrollPane.setHorizontalScrollBarPolicy(javax.swing.ScrollPaneConstants.HORIZONTAL_SCROLLBAR_NEVER);
        timeattackModeQuestionScrollPane.setVerticalScrollBarPolicy(javax.swing.ScrollPaneConstants.VERTICAL_SCROLLBAR_NEVER);

        timeattackQuestionTextArea.setColumns(20);
        timeattackQuestionTextArea.setFont(new java.awt.Font("Arial", 2, 24)); // NOI18N
        timeattackQuestionTextArea.setLineWrap(true);
        timeattackQuestionTextArea.setRows(5);
        timeattackModeQuestionScrollPane.setViewportView(timeattackQuestionTextArea);

        timeattackModeQuestionLabel.setFont(new java.awt.Font("Arial", 0, 24)); // NOI18N
        timeattackModeQuestionLabel.setText("ΕΡΩΤΗΣΗ ΓΙΑ ΤΟΝ ΠΑΙΚΤΗ:");

        timeattackModePlayerLabel.setFont(new java.awt.Font("Arial", 2, 24)); // NOI18N

        javax.swing.GroupLayout timeattackModeQuestionPanelLayout = new javax.swing.GroupLayout(timeattackModeQuestionPanel);
        timeattackModeQuestionPanel.setLayout(timeattackModeQuestionPanelLayout);
        timeattackModeQuestionPanelLayout.setHorizontalGroup(
            timeattackModeQuestionPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(timeattackModeQuestionPanelLayout.createSequentialGroup()
                .addGap(20, 20, 20)
                .addGroup(timeattackModeQuestionPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(timeattackModeQuestionScrollPane)
                    .addGroup(timeattackModeQuestionPanelLayout.createSequentialGroup()
                        .addComponent(timeattackModeQuestionLabel)
                        .addGap(18, 18, 18)
                        .addComponent(timeattackModePlayerLabel, javax.swing.GroupLayout.PREFERRED_SIZE, 238, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(0, 419, Short.MAX_VALUE)))
                .addContainerGap())
        );
        timeattackModeQuestionPanelLayout.setVerticalGroup(
            timeattackModeQuestionPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, timeattackModeQuestionPanelLayout.createSequentialGroup()
                .addGroup(timeattackModeQuestionPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(timeattackModeQuestionLabel, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(timeattackModePlayerLabel, javax.swing.GroupLayout.PREFERRED_SIZE, 29, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(timeattackModeQuestionScrollPane, javax.swing.GroupLayout.PREFERRED_SIZE, 90, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(20, 20, 20))
        );

        timeattackModeAnswerLabel.setFont(new java.awt.Font("Arial", 0, 24)); // NOI18N
        timeattackModeAnswerLabel.setText("ΑΠΑΝΤΗΣΕΙΣ:");

        timeattackModeAnswer1.setFont(new java.awt.Font("Arial", 0, 24)); // NOI18N

        timeattackModeAnswer2.setFont(new java.awt.Font("Arial", 0, 24)); // NOI18N

        timeattackModeAnswer3.setFont(new java.awt.Font("Arial", 0, 24)); // NOI18N

        timeattackModeAnswer4.setFont(new java.awt.Font("Arial", 0, 24)); // NOI18N

        javax.swing.GroupLayout timeattackModeAnswerPanelLayout = new javax.swing.GroupLayout(timeattackModeAnswerPanel);
        timeattackModeAnswerPanel.setLayout(timeattackModeAnswerPanelLayout);
        timeattackModeAnswerPanelLayout.setHorizontalGroup(
            timeattackModeAnswerPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(timeattackModeAnswerPanelLayout.createSequentialGroup()
                .addGroup(timeattackModeAnswerPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(timeattackModeAnswerLabel)
                    .addGroup(timeattackModeAnswerPanelLayout.createSequentialGroup()
                        .addContainerGap()
                        .addGroup(timeattackModeAnswerPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                            .addComponent(timeattackModeAnswer3, javax.swing.GroupLayout.DEFAULT_SIZE, 350, Short.MAX_VALUE)
                            .addComponent(timeattackModeAnswer1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 159, Short.MAX_VALUE)
                        .addGroup(timeattackModeAnswerPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                            .addComponent(timeattackModeAnswer2, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                            .addComponent(timeattackModeAnswer4, javax.swing.GroupLayout.DEFAULT_SIZE, 350, Short.MAX_VALUE))))
                .addGap(45, 45, 45))
        );
        timeattackModeAnswerPanelLayout.setVerticalGroup(
            timeattackModeAnswerPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(timeattackModeAnswerPanelLayout.createSequentialGroup()
                .addContainerGap()
                .addComponent(timeattackModeAnswerLabel, javax.swing.GroupLayout.PREFERRED_SIZE, 36, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(29, 29, 29)
                .addGroup(timeattackModeAnswerPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(timeattackModeAnswer1, javax.swing.GroupLayout.PREFERRED_SIZE, 80, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(timeattackModeAnswer2, javax.swing.GroupLayout.PREFERRED_SIZE, 80, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(64, 64, 64)
                .addGroup(timeattackModeAnswerPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(timeattackModeAnswer4, javax.swing.GroupLayout.PREFERRED_SIZE, 81, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(timeattackModeAnswer3, javax.swing.GroupLayout.PREFERRED_SIZE, 81, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addContainerGap(90, Short.MAX_VALUE))
        );

        timeattackModeQInfoLabel.setFont(new java.awt.Font("Arial Narrow", 0, 30)); // NOI18N
        timeattackModeQInfoLabel.setText("ΕΡΩΤΗΣΕΙΣ ΠΟΥ ΑΠΟΜΕΝΟΥΝ:");
        timeattackModeQInfoLabel.setBorder(new javax.swing.border.SoftBevelBorder(javax.swing.border.BevelBorder.RAISED));

        timeattackModeNoOfQuestLabel.setFont(new java.awt.Font("Arial Narrow", 0, 30)); // NOI18N
        timeattackModeNoOfQuestLabel.setBorder(new javax.swing.border.SoftBevelBorder(javax.swing.border.BevelBorder.RAISED));

        timeattackModeTimeInfoLabel.setFont(new java.awt.Font("Arial Narrow", 0, 30)); // NOI18N
        timeattackModeTimeInfoLabel.setText("ΧΡΟΝΟΣ:");
        timeattackModeTimeInfoLabel.setBorder(new javax.swing.border.SoftBevelBorder(javax.swing.border.BevelBorder.RAISED));

        timeattackModeTimeLabel.setFont(new java.awt.Font("Arial Narrow", 0, 30)); // NOI18N
        timeattackModeTimeLabel.setBorder(new javax.swing.border.SoftBevelBorder(javax.swing.border.BevelBorder.RAISED));

        javax.swing.GroupLayout timeattackModeInfoPanelLayout = new javax.swing.GroupLayout(timeattackModeInfoPanel);
        timeattackModeInfoPanel.setLayout(timeattackModeInfoPanelLayout);
        timeattackModeInfoPanelLayout.setHorizontalGroup(
            timeattackModeInfoPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(timeattackModeInfoPanelLayout.createSequentialGroup()
                .addGap(71, 71, 71)
                .addComponent(timeattackModeQInfoLabel)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(timeattackModeNoOfQuestLabel, javax.swing.GroupLayout.PREFERRED_SIZE, 25, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(117, 117, 117)
                .addComponent(timeattackModeTimeInfoLabel)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(timeattackModeTimeLabel, javax.swing.GroupLayout.PREFERRED_SIZE, 32, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );
        timeattackModeInfoPanelLayout.setVerticalGroup(
            timeattackModeInfoPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, timeattackModeInfoPanelLayout.createSequentialGroup()
                .addContainerGap()
                .addGroup(timeattackModeInfoPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(timeattackModeQInfoLabel, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(timeattackModeTimeInfoLabel, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(timeattackModeTimeLabel, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(timeattackModeNoOfQuestLabel, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                .addContainerGap())
        );

        javax.swing.GroupLayout timeattackModeGeneralPanel2Layout = new javax.swing.GroupLayout(timeattackModeGeneralPanel2);
        timeattackModeGeneralPanel2.setLayout(timeattackModeGeneralPanel2Layout);
        timeattackModeGeneralPanel2Layout.setHorizontalGroup(
            timeattackModeGeneralPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(timeattackModeGeneralPanel2Layout.createSequentialGroup()
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addGroup(timeattackModeGeneralPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING, false)
                    .addComponent(timeattackModeAnswerPanel, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(timeattackModeQuestionPanel, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(timeattackModeInfoPanel, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
            .addGroup(timeattackModeGeneralPanel2Layout.createSequentialGroup()
                .addGap(262, 262, 262)
                .addComponent(timeattackModeTitlePanel, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(285, Short.MAX_VALUE))
        );
        timeattackModeGeneralPanel2Layout.setVerticalGroup(
            timeattackModeGeneralPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(timeattackModeGeneralPanel2Layout.createSequentialGroup()
                .addGap(25, 25, 25)
                .addComponent(timeattackModeTitlePanel, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18)
                .addComponent(timeattackModeInfoPanel, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18)
                .addComponent(timeattackModeQuestionPanel, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18)
                .addComponent(timeattackModeAnswerPanel, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );

        javax.swing.GroupLayout timeattackModeGeneralPanelLayout = new javax.swing.GroupLayout(timeattackModeGeneralPanel);
        timeattackModeGeneralPanel.setLayout(timeattackModeGeneralPanelLayout);
        timeattackModeGeneralPanelLayout.setHorizontalGroup(
            timeattackModeGeneralPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, timeattackModeGeneralPanelLayout.createSequentialGroup()
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(timeattackModeGeneralPanel2, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(33, 33, 33))
        );
        timeattackModeGeneralPanelLayout.setVerticalGroup(
            timeattackModeGeneralPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(timeattackModeGeneralPanelLayout.createSequentialGroup()
                .addContainerGap()
                .addComponent(timeattackModeGeneralPanel2, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addContainerGap())
        );

        javax.swing.GroupLayout timeattackModePanelLayout = new javax.swing.GroupLayout(timeattackModePanel);
        timeattackModePanel.setLayout(timeattackModePanelLayout);
        timeattackModePanelLayout.setHorizontalGroup(
            timeattackModePanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 0, Short.MAX_VALUE)
            .addGroup(timeattackModePanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                .addGroup(timeattackModePanelLayout.createSequentialGroup()
                    .addContainerGap()
                    .addComponent(timeattackModeGeneralPanel, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)))
        );
        timeattackModePanelLayout.setVerticalGroup(
            timeattackModePanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 0, Short.MAX_VALUE)
            .addGroup(timeattackModePanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                .addGroup(timeattackModePanelLayout.createSequentialGroup()
                    .addContainerGap()
                    .addComponent(timeattackModeGeneralPanel, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)))
        );

        elevatorModePanel.setPreferredSize(new java.awt.Dimension(1201, 777));

        elevatorModeGeneralPanel2.setPreferredSize(new java.awt.Dimension(1201, 777));

        elevatorModeTitleLabel1.setFont(new java.awt.Font("Arial Black", 0, 36)); // NOI18N
        elevatorModeTitleLabel1.setText("ΓΥΡΟΣ");

        elevatorModeTitleLabel2.setFont(new java.awt.Font("Arial Black", 0, 36)); // NOI18N

        javax.swing.GroupLayout elevatorModeTitlePanelLayout = new javax.swing.GroupLayout(elevatorModeTitlePanel);
        elevatorModeTitlePanel.setLayout(elevatorModeTitlePanelLayout);
        elevatorModeTitlePanelLayout.setHorizontalGroup(
            elevatorModeTitlePanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(elevatorModeTitlePanelLayout.createSequentialGroup()
                .addGap(216, 216, 216)
                .addComponent(elevatorModeTitleLabel1)
                .addGap(18, 18, 18)
                .addComponent(elevatorModeTitleLabel2, javax.swing.GroupLayout.PREFERRED_SIZE, 71, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(225, Short.MAX_VALUE))
        );
        elevatorModeTitlePanelLayout.setVerticalGroup(
            elevatorModeTitlePanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(elevatorModeTitlePanelLayout.createSequentialGroup()
                .addContainerGap()
                .addGroup(elevatorModeTitlePanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(elevatorModeTitleLabel2, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(elevatorModeTitleLabel1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                .addContainerGap())
        );

        elevatorModeQuestionScrollPane.setHorizontalScrollBarPolicy(javax.swing.ScrollPaneConstants.HORIZONTAL_SCROLLBAR_NEVER);
        elevatorModeQuestionScrollPane.setVerticalScrollBarPolicy(javax.swing.ScrollPaneConstants.VERTICAL_SCROLLBAR_NEVER);

        elevatorModeQuestionTextArea.setColumns(20);
        elevatorModeQuestionTextArea.setFont(new java.awt.Font("Arial", 2, 24)); // NOI18N
        elevatorModeQuestionTextArea.setLineWrap(true);
        elevatorModeQuestionTextArea.setRows(5);
        elevatorModeQuestionScrollPane.setViewportView(elevatorModeQuestionTextArea);

        elevatorModeQuestionLabel.setFont(new java.awt.Font("Arial", 0, 24)); // NOI18N
        elevatorModeQuestionLabel.setText("ΕΡΩΤΗΣΗ ΓΙΑ ΤΟΝ ΠΑΙΚΤΗ:");

        elevatorModePlayerLabel.setFont(new java.awt.Font("Arial", 2, 24)); // NOI18N

        javax.swing.GroupLayout elevatorModeQuestionPanelLayout = new javax.swing.GroupLayout(elevatorModeQuestionPanel);
        elevatorModeQuestionPanel.setLayout(elevatorModeQuestionPanelLayout);
        elevatorModeQuestionPanelLayout.setHorizontalGroup(
            elevatorModeQuestionPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(elevatorModeQuestionPanelLayout.createSequentialGroup()
                .addGap(20, 20, 20)
                .addGroup(elevatorModeQuestionPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(elevatorModeQuestionScrollPane)
                    .addGroup(elevatorModeQuestionPanelLayout.createSequentialGroup()
                        .addComponent(elevatorModeQuestionLabel)
                        .addGap(18, 18, 18)
                        .addComponent(elevatorModePlayerLabel, javax.swing.GroupLayout.PREFERRED_SIZE, 238, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(0, 419, Short.MAX_VALUE)))
                .addContainerGap())
        );
        elevatorModeQuestionPanelLayout.setVerticalGroup(
            elevatorModeQuestionPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, elevatorModeQuestionPanelLayout.createSequentialGroup()
                .addGroup(elevatorModeQuestionPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(elevatorModeQuestionLabel, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(elevatorModePlayerLabel, javax.swing.GroupLayout.PREFERRED_SIZE, 29, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(elevatorModeQuestionScrollPane, javax.swing.GroupLayout.PREFERRED_SIZE, 90, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(20, 20, 20))
        );

        elevatorModeAnswerLabel.setFont(new java.awt.Font("Arial", 0, 24)); // NOI18N
        elevatorModeAnswerLabel.setText("ΑΠΑΝΤΗΣΕΙΣ:");

        elevatorModeAnswer1.setFont(new java.awt.Font("Arial", 0, 24)); // NOI18N

        elevatorModeAnswer2.setFont(new java.awt.Font("Arial", 0, 24)); // NOI18N

        elevatorModeAnswer3.setFont(new java.awt.Font("Arial", 0, 24)); // NOI18N

        elevatorModeAnswer4.setFont(new java.awt.Font("Arial", 0, 24)); // NOI18N

        javax.swing.GroupLayout elevatorModeAnswerPanelLayout = new javax.swing.GroupLayout(elevatorModeAnswerPanel);
        elevatorModeAnswerPanel.setLayout(elevatorModeAnswerPanelLayout);
        elevatorModeAnswerPanelLayout.setHorizontalGroup(
            elevatorModeAnswerPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(elevatorModeAnswerPanelLayout.createSequentialGroup()
                .addGroup(elevatorModeAnswerPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(elevatorModeAnswerLabel)
                    .addGroup(elevatorModeAnswerPanelLayout.createSequentialGroup()
                        .addContainerGap()
                        .addGroup(elevatorModeAnswerPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                            .addComponent(elevatorModeAnswer3, javax.swing.GroupLayout.DEFAULT_SIZE, 350, Short.MAX_VALUE)
                            .addComponent(elevatorModeAnswer1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 159, Short.MAX_VALUE)
                        .addGroup(elevatorModeAnswerPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                            .addComponent(elevatorModeAnswer2, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                            .addComponent(elevatorModeAnswer4, javax.swing.GroupLayout.DEFAULT_SIZE, 350, Short.MAX_VALUE))))
                .addGap(45, 45, 45))
        );
        elevatorModeAnswerPanelLayout.setVerticalGroup(
            elevatorModeAnswerPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(elevatorModeAnswerPanelLayout.createSequentialGroup()
                .addContainerGap()
                .addComponent(elevatorModeAnswerLabel, javax.swing.GroupLayout.PREFERRED_SIZE, 36, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(29, 29, 29)
                .addGroup(elevatorModeAnswerPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(elevatorModeAnswer1, javax.swing.GroupLayout.PREFERRED_SIZE, 80, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(elevatorModeAnswer2, javax.swing.GroupLayout.PREFERRED_SIZE, 80, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(64, 64, 64)
                .addGroup(elevatorModeAnswerPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(elevatorModeAnswer4, javax.swing.GroupLayout.PREFERRED_SIZE, 81, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(elevatorModeAnswer3, javax.swing.GroupLayout.PREFERRED_SIZE, 81, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addContainerGap(90, Short.MAX_VALUE))
        );

        elevatorModeQInfoLabel.setFont(new java.awt.Font("Arial Narrow", 0, 30)); // NOI18N
        elevatorModeQInfoLabel.setText("ΕΡΩΤΗΣΕΙΣ ΠΟΥ ΑΠΟΜΕΝΟΥΝ:");
        elevatorModeQInfoLabel.setBorder(new javax.swing.border.SoftBevelBorder(javax.swing.border.BevelBorder.RAISED));

        elevatorModeNoOfQuestLabel.setFont(new java.awt.Font("Arial Narrow", 0, 30)); // NOI18N
        elevatorModeNoOfQuestLabel.setBorder(new javax.swing.border.SoftBevelBorder(javax.swing.border.BevelBorder.RAISED));

        elevatorModeTimeInfoLabel.setFont(new java.awt.Font("Arial Narrow", 0, 30)); // NOI18N
        elevatorModeTimeInfoLabel.setText("ΜΕΤΡΗΤΗΣ:");
        elevatorModeTimeInfoLabel.setBorder(new javax.swing.border.SoftBevelBorder(javax.swing.border.BevelBorder.RAISED));

        elevatorModeTimeLabel.setFont(new java.awt.Font("Arial Narrow", 0, 30)); // NOI18N
        elevatorModeTimeLabel.setBorder(new javax.swing.border.SoftBevelBorder(javax.swing.border.BevelBorder.RAISED));

        javax.swing.GroupLayout elevatorModeInfoPanelLayout = new javax.swing.GroupLayout(elevatorModeInfoPanel);
        elevatorModeInfoPanel.setLayout(elevatorModeInfoPanelLayout);
        elevatorModeInfoPanelLayout.setHorizontalGroup(
            elevatorModeInfoPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(elevatorModeInfoPanelLayout.createSequentialGroup()
                .addGap(71, 71, 71)
                .addComponent(elevatorModeQInfoLabel)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(elevatorModeNoOfQuestLabel, javax.swing.GroupLayout.PREFERRED_SIZE, 25, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(117, 117, 117)
                .addComponent(elevatorModeTimeInfoLabel)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(elevatorModeTimeLabel, javax.swing.GroupLayout.PREFERRED_SIZE, 40, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(225, Short.MAX_VALUE))
        );
        elevatorModeInfoPanelLayout.setVerticalGroup(
            elevatorModeInfoPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, elevatorModeInfoPanelLayout.createSequentialGroup()
                .addContainerGap()
                .addGroup(elevatorModeInfoPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(elevatorModeQInfoLabel, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(elevatorModeTimeInfoLabel, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(elevatorModeTimeLabel, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(elevatorModeNoOfQuestLabel, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                .addContainerGap())
        );

        javax.swing.GroupLayout elevatorModeGeneralPanel3Layout = new javax.swing.GroupLayout(elevatorModeGeneralPanel3);
        elevatorModeGeneralPanel3.setLayout(elevatorModeGeneralPanel3Layout);
        elevatorModeGeneralPanel3Layout.setHorizontalGroup(
            elevatorModeGeneralPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(elevatorModeGeneralPanel3Layout.createSequentialGroup()
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addGroup(elevatorModeGeneralPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING, false)
                    .addComponent(elevatorModeAnswerPanel, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(elevatorModeQuestionPanel, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(elevatorModeInfoPanel, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
            .addGroup(elevatorModeGeneralPanel3Layout.createSequentialGroup()
                .addGap(262, 262, 262)
                .addComponent(elevatorModeTitlePanel, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(285, Short.MAX_VALUE))
        );
        elevatorModeGeneralPanel3Layout.setVerticalGroup(
            elevatorModeGeneralPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(elevatorModeGeneralPanel3Layout.createSequentialGroup()
                .addGap(25, 25, 25)
                .addComponent(elevatorModeTitlePanel, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18)
                .addComponent(elevatorModeInfoPanel, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18)
                .addComponent(elevatorModeQuestionPanel, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18)
                .addComponent(elevatorModeAnswerPanel, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );

        javax.swing.GroupLayout elevatorModeGeneralPanel2Layout = new javax.swing.GroupLayout(elevatorModeGeneralPanel2);
        elevatorModeGeneralPanel2.setLayout(elevatorModeGeneralPanel2Layout);
        elevatorModeGeneralPanel2Layout.setHorizontalGroup(
            elevatorModeGeneralPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, elevatorModeGeneralPanel2Layout.createSequentialGroup()
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(elevatorModeGeneralPanel3, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(33, 33, 33))
        );
        elevatorModeGeneralPanel2Layout.setVerticalGroup(
            elevatorModeGeneralPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(elevatorModeGeneralPanel2Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(elevatorModeGeneralPanel3, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addContainerGap())
        );

        javax.swing.GroupLayout elevatorModeGeneralPanel1Layout = new javax.swing.GroupLayout(elevatorModeGeneralPanel1);
        elevatorModeGeneralPanel1.setLayout(elevatorModeGeneralPanel1Layout);
        elevatorModeGeneralPanel1Layout.setHorizontalGroup(
            elevatorModeGeneralPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 1221, Short.MAX_VALUE)
            .addGroup(elevatorModeGeneralPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                .addGroup(elevatorModeGeneralPanel1Layout.createSequentialGroup()
                    .addContainerGap()
                    .addComponent(elevatorModeGeneralPanel2, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)))
        );
        elevatorModeGeneralPanel1Layout.setVerticalGroup(
            elevatorModeGeneralPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 799, Short.MAX_VALUE)
            .addGroup(elevatorModeGeneralPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                .addGroup(elevatorModeGeneralPanel1Layout.createSequentialGroup()
                    .addContainerGap()
                    .addComponent(elevatorModeGeneralPanel2, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)))
        );

        javax.swing.GroupLayout elevatorModePanelLayout = new javax.swing.GroupLayout(elevatorModePanel);
        elevatorModePanel.setLayout(elevatorModePanelLayout);
        elevatorModePanelLayout.setHorizontalGroup(
            elevatorModePanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 0, Short.MAX_VALUE)
            .addGroup(elevatorModePanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                .addGroup(elevatorModePanelLayout.createSequentialGroup()
                    .addContainerGap()
                    .addComponent(elevatorModeGeneralPanel1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)))
        );
        elevatorModePanelLayout.setVerticalGroup(
            elevatorModePanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 0, Short.MAX_VALUE)
            .addGroup(elevatorModePanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                .addGroup(elevatorModePanelLayout.createSequentialGroup()
                    .addContainerGap()
                    .addComponent(elevatorModeGeneralPanel1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)))
        );

        oneminquestModeTitleLabel1.setFont(new java.awt.Font("Arial Black", 0, 36)); // NOI18N
        oneminquestModeTitleLabel1.setText("ΓΥΡΟΣ");

        oneminquestModeTitleLabel2.setFont(new java.awt.Font("Arial Black", 0, 36)); // NOI18N

        javax.swing.GroupLayout oneminquestModeTitlePanelLayout = new javax.swing.GroupLayout(oneminquestModeTitlePanel);
        oneminquestModeTitlePanel.setLayout(oneminquestModeTitlePanelLayout);
        oneminquestModeTitlePanelLayout.setHorizontalGroup(
            oneminquestModeTitlePanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(oneminquestModeTitlePanelLayout.createSequentialGroup()
                .addGap(216, 216, 216)
                .addComponent(oneminquestModeTitleLabel1)
                .addGap(18, 18, 18)
                .addComponent(oneminquestModeTitleLabel2, javax.swing.GroupLayout.PREFERRED_SIZE, 71, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(225, Short.MAX_VALUE))
        );
        oneminquestModeTitlePanelLayout.setVerticalGroup(
            oneminquestModeTitlePanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(oneminquestModeTitlePanelLayout.createSequentialGroup()
                .addContainerGap()
                .addGroup(oneminquestModeTitlePanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(oneminquestModeTitleLabel2, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(oneminquestModeTitleLabel1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                .addContainerGap())
        );

        oneminquestModeQuestionScrollPane.setHorizontalScrollBarPolicy(javax.swing.ScrollPaneConstants.HORIZONTAL_SCROLLBAR_NEVER);
        oneminquestModeQuestionScrollPane.setVerticalScrollBarPolicy(javax.swing.ScrollPaneConstants.VERTICAL_SCROLLBAR_NEVER);

        oneminquestModeQuestionTextArea.setColumns(20);
        oneminquestModeQuestionTextArea.setFont(new java.awt.Font("Arial", 2, 24)); // NOI18N
        oneminquestModeQuestionTextArea.setLineWrap(true);
        oneminquestModeQuestionTextArea.setRows(5);
        oneminquestModeQuestionScrollPane.setViewportView(oneminquestModeQuestionTextArea);

        oneminquestModeQuestionLabel.setFont(new java.awt.Font("Arial", 0, 24)); // NOI18N
        oneminquestModeQuestionLabel.setText("ΕΡΩΤΗΣΗ ΓΙΑ ΤΟΝ ΠΑΙΚΤΗ:");

        oneminquestModePlayerLabel.setFont(new java.awt.Font("Arial", 2, 24)); // NOI18N

        javax.swing.GroupLayout oneminquestModeQuestionPanelLayout = new javax.swing.GroupLayout(oneminquestModeQuestionPanel);
        oneminquestModeQuestionPanel.setLayout(oneminquestModeQuestionPanelLayout);
        oneminquestModeQuestionPanelLayout.setHorizontalGroup(
            oneminquestModeQuestionPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(oneminquestModeQuestionPanelLayout.createSequentialGroup()
                .addGap(20, 20, 20)
                .addGroup(oneminquestModeQuestionPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(oneminquestModeQuestionScrollPane)
                    .addGroup(oneminquestModeQuestionPanelLayout.createSequentialGroup()
                        .addComponent(oneminquestModeQuestionLabel)
                        .addGap(18, 18, 18)
                        .addComponent(oneminquestModePlayerLabel, javax.swing.GroupLayout.PREFERRED_SIZE, 238, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(0, 445, Short.MAX_VALUE)))
                .addContainerGap())
        );
        oneminquestModeQuestionPanelLayout.setVerticalGroup(
            oneminquestModeQuestionPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, oneminquestModeQuestionPanelLayout.createSequentialGroup()
                .addGroup(oneminquestModeQuestionPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(oneminquestModeQuestionLabel, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(oneminquestModePlayerLabel, javax.swing.GroupLayout.PREFERRED_SIZE, 29, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(oneminquestModeQuestionScrollPane, javax.swing.GroupLayout.PREFERRED_SIZE, 90, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(20, 20, 20))
        );

        oneminquestModeAnswerLabel.setFont(new java.awt.Font("Arial", 0, 24)); // NOI18N
        oneminquestModeAnswerLabel.setText("ΑΠΑΝΤΗΣΕΙΣ:");

        oneminquestModeAnswer1.setFont(new java.awt.Font("Arial", 0, 24)); // NOI18N

        oneminquestModeAnswer2.setFont(new java.awt.Font("Arial", 0, 24)); // NOI18N

        oneminquestModeAnswer3.setFont(new java.awt.Font("Arial", 0, 24)); // NOI18N

        oneminquestModeAnswer4.setFont(new java.awt.Font("Arial", 0, 24)); // NOI18N

        javax.swing.GroupLayout oneminquestModeAnswerPanelLayout = new javax.swing.GroupLayout(oneminquestModeAnswerPanel);
        oneminquestModeAnswerPanel.setLayout(oneminquestModeAnswerPanelLayout);
        oneminquestModeAnswerPanelLayout.setHorizontalGroup(
            oneminquestModeAnswerPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(oneminquestModeAnswerPanelLayout.createSequentialGroup()
                .addGroup(oneminquestModeAnswerPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(oneminquestModeAnswerLabel)
                    .addGroup(oneminquestModeAnswerPanelLayout.createSequentialGroup()
                        .addContainerGap()
                        .addGroup(oneminquestModeAnswerPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                            .addComponent(oneminquestModeAnswer3, javax.swing.GroupLayout.DEFAULT_SIZE, 350, Short.MAX_VALUE)
                            .addComponent(oneminquestModeAnswer1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 159, Short.MAX_VALUE)
                        .addGroup(oneminquestModeAnswerPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                            .addComponent(oneminquestModeAnswer2, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                            .addComponent(oneminquestModeAnswer4, javax.swing.GroupLayout.DEFAULT_SIZE, 350, Short.MAX_VALUE))))
                .addGap(45, 45, 45))
        );
        oneminquestModeAnswerPanelLayout.setVerticalGroup(
            oneminquestModeAnswerPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(oneminquestModeAnswerPanelLayout.createSequentialGroup()
                .addContainerGap()
                .addComponent(oneminquestModeAnswerLabel, javax.swing.GroupLayout.PREFERRED_SIZE, 36, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(29, 29, 29)
                .addGroup(oneminquestModeAnswerPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(oneminquestModeAnswer1, javax.swing.GroupLayout.PREFERRED_SIZE, 80, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(oneminquestModeAnswer2, javax.swing.GroupLayout.PREFERRED_SIZE, 80, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(64, 64, 64)
                .addGroup(oneminquestModeAnswerPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(oneminquestModeAnswer4, javax.swing.GroupLayout.PREFERRED_SIZE, 81, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(oneminquestModeAnswer3, javax.swing.GroupLayout.PREFERRED_SIZE, 81, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addContainerGap(90, Short.MAX_VALUE))
        );

        oneminquestModeQInfoLabel.setFont(new java.awt.Font("Arial Narrow", 0, 30)); // NOI18N
        oneminquestModeQInfoLabel.setText("ΕΡΩΤΗΣΕΙΣ ΠΟΥ ΑΠΑΝΤΗΘΗΚΑΝ:");
        oneminquestModeQInfoLabel.setBorder(new javax.swing.border.SoftBevelBorder(javax.swing.border.BevelBorder.RAISED));

        oneminquestModeNoOfQuestLabel.setFont(new java.awt.Font("Arial Narrow", 0, 30)); // NOI18N
        oneminquestModeNoOfQuestLabel.setBorder(new javax.swing.border.SoftBevelBorder(javax.swing.border.BevelBorder.RAISED));

        oneminquestModeTimeInfoLabel.setFont(new java.awt.Font("Arial Narrow", 0, 30)); // NOI18N
        oneminquestModeTimeInfoLabel.setText("ΧΡΟΝΟΣ:");
        oneminquestModeTimeInfoLabel.setBorder(new javax.swing.border.SoftBevelBorder(javax.swing.border.BevelBorder.RAISED));

        oneminquestModeTimeLabel.setFont(new java.awt.Font("Arial Narrow", 0, 30)); // NOI18N
        oneminquestModeTimeLabel.setBorder(new javax.swing.border.SoftBevelBorder(javax.swing.border.BevelBorder.RAISED));

        javax.swing.GroupLayout oneminquestModeInfoPanelLayout = new javax.swing.GroupLayout(oneminquestModeInfoPanel);
        oneminquestModeInfoPanel.setLayout(oneminquestModeInfoPanelLayout);
        oneminquestModeInfoPanelLayout.setHorizontalGroup(
            oneminquestModeInfoPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(oneminquestModeInfoPanelLayout.createSequentialGroup()
                .addGap(71, 71, 71)
                .addComponent(oneminquestModeQInfoLabel)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(oneminquestModeNoOfQuestLabel, javax.swing.GroupLayout.PREFERRED_SIZE, 33, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(109, 109, 109)
                .addComponent(oneminquestModeTimeInfoLabel)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(oneminquestModeTimeLabel, javax.swing.GroupLayout.PREFERRED_SIZE, 33, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );
        oneminquestModeInfoPanelLayout.setVerticalGroup(
            oneminquestModeInfoPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, oneminquestModeInfoPanelLayout.createSequentialGroup()
                .addContainerGap()
                .addGroup(oneminquestModeInfoPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(oneminquestModeQInfoLabel, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(oneminquestModeTimeInfoLabel, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(oneminquestModeTimeLabel, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(oneminquestModeNoOfQuestLabel, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                .addContainerGap())
        );

        javax.swing.GroupLayout oneminquestModeGeneralPanelLayout = new javax.swing.GroupLayout(oneminquestModeGeneralPanel);
        oneminquestModeGeneralPanel.setLayout(oneminquestModeGeneralPanelLayout);
        oneminquestModeGeneralPanelLayout.setHorizontalGroup(
            oneminquestModeGeneralPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(oneminquestModeGeneralPanelLayout.createSequentialGroup()
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addGroup(oneminquestModeGeneralPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING, false)
                    .addComponent(oneminquestModeAnswerPanel, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(oneminquestModeQuestionPanel, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(oneminquestModeInfoPanel, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
            .addGroup(oneminquestModeGeneralPanelLayout.createSequentialGroup()
                .addGap(262, 262, 262)
                .addComponent(oneminquestModeTitlePanel, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(285, Short.MAX_VALUE))
        );
        oneminquestModeGeneralPanelLayout.setVerticalGroup(
            oneminquestModeGeneralPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(oneminquestModeGeneralPanelLayout.createSequentialGroup()
                .addGap(25, 25, 25)
                .addComponent(oneminquestModeTitlePanel, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18)
                .addComponent(oneminquestModeInfoPanel, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18)
                .addComponent(oneminquestModeQuestionPanel, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18)
                .addComponent(oneminquestModeAnswerPanel, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );

        javax.swing.GroupLayout oneminquestModePanelLayout = new javax.swing.GroupLayout(oneminquestModePanel);
        oneminquestModePanel.setLayout(oneminquestModePanelLayout);
        oneminquestModePanelLayout.setHorizontalGroup(
            oneminquestModePanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, oneminquestModePanelLayout.createSequentialGroup()
                .addContainerGap(25, Short.MAX_VALUE)
                .addComponent(oneminquestModeGeneralPanel, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18))
        );
        oneminquestModePanelLayout.setVerticalGroup(
            oneminquestModePanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(oneminquestModePanelLayout.createSequentialGroup()
                .addContainerGap()
                .addComponent(oneminquestModeGeneralPanel, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addContainerGap())
        );

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(openPanel, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
            .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                .addGroup(layout.createSequentialGroup()
                    .addGap(0, 0, Short.MAX_VALUE)
                    .addComponent(mainMenuPanel, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addGap(0, 0, Short.MAX_VALUE)))
            .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                .addGroup(layout.createSequentialGroup()
                    .addGap(0, 0, Short.MAX_VALUE)
                    .addComponent(playerNamePanel, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addGap(0, 0, Short.MAX_VALUE)))
            .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                .addGroup(layout.createSequentialGroup()
                    .addGap(0, 0, Short.MAX_VALUE)
                    .addComponent(classicModePanel, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addGap(0, 0, Short.MAX_VALUE)))
            .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                .addGroup(layout.createSequentialGroup()
                    .addGap(0, 0, Short.MAX_VALUE)
                    .addComponent(timeattackModePanel, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addGap(0, 0, Short.MAX_VALUE)))
            .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                .addGroup(layout.createSequentialGroup()
                    .addGap(0, 0, Short.MAX_VALUE)
                    .addComponent(elevatorModePanel, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addGap(0, 0, Short.MAX_VALUE)))
            .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                .addGroup(layout.createSequentialGroup()
                    .addGap(0, 0, Short.MAX_VALUE)
                    .addComponent(oneminquestModePanel, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addGap(0, 0, Short.MAX_VALUE)))
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(openPanel, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
            .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                .addGroup(layout.createSequentialGroup()
                    .addGap(0, 0, Short.MAX_VALUE)
                    .addComponent(mainMenuPanel, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addGap(0, 0, Short.MAX_VALUE)))
            .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                .addGroup(layout.createSequentialGroup()
                    .addGap(0, 0, Short.MAX_VALUE)
                    .addComponent(playerNamePanel, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addGap(0, 0, Short.MAX_VALUE)))
            .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                .addGroup(layout.createSequentialGroup()
                    .addGap(0, 0, Short.MAX_VALUE)
                    .addComponent(classicModePanel, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addGap(0, 0, Short.MAX_VALUE)))
            .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                .addGroup(layout.createSequentialGroup()
                    .addGap(0, 0, Short.MAX_VALUE)
                    .addComponent(timeattackModePanel, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addGap(0, 0, Short.MAX_VALUE)))
            .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                .addGroup(layout.createSequentialGroup()
                    .addGap(0, 0, Short.MAX_VALUE)
                    .addComponent(elevatorModePanel, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addGap(0, 0, Short.MAX_VALUE)))
            .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                .addGroup(layout.createSequentialGroup()
                    .addGap(0, 0, Short.MAX_VALUE)
                    .addComponent(oneminquestModePanel, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addGap(0, 0, Short.MAX_VALUE)))
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void changePanels(javax.swing.JPanel p1,javax.swing.JPanel p2){
        p1.setVisible(false);
        getContentPane().removeAll();
        getContentPane().add(p2);
        p2.setVisible(true);
    }
    
    private void openPanelStartBtnActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_openPanelStartBtnActionPerformed
        changePanels(openPanel,mainMenuPanel);
    }//GEN-LAST:event_openPanelStartBtnActionPerformed

    private void quickGameBtnActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_quickGameBtnActionPerformed
        changePanels(mainMenuPanel,playerNamePanel);
        //Δημιούργησε αντικείμενο τύπου Quick Game.
    }//GEN-LAST:event_quickGameBtnActionPerformed

    private void arcadeGameBtnActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_arcadeGameBtnActionPerformed
        changePanels(mainMenuPanel,playerNamePanel);
        //Δημιούργησε αντικείμενο τύπου Arcade Game.
    }//GEN-LAST:event_arcadeGameBtnActionPerformed

    private void playerNameBackBtnActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_playerNameBackBtnActionPerformed
        changePanels(playerNamePanel,mainMenuPanel);
    }//GEN-LAST:event_playerNameBackBtnActionPerformed

    /*private void gameTypeChoiceActionPerformed(java.awt.event.ActionEvent evt){
        if(evt.getSource(quickGameBtn))
        {
            changePanels(mainMenuPanel,playerNamePanel);
            //Δημιούργησε αντικείμενο τύπου Quick Game.
        }
        else if(evt.getSource().equals(arcadeGameBtn))
        {
            changePanels(mainMenuPanel,playerNamePanel);
            //Δημιούργησε αντικείμενο τύπου Arcade Game.
        }
    }
    */

    public static void main(String args[]) {
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(GUI.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(GUI.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(GUI.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(GUI.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
       


        java.awt.EventQueue.invokeLater(new Runnable() {
            @Override
            public void run() {
                new GUI().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton arcadeGameBtn;
    private javax.swing.JButton classicModeAnswer1;
    private javax.swing.JButton classicModeAnswer2;
    private javax.swing.JButton classicModeAnswer3;
    private javax.swing.JButton classicModeAnswer4;
    private javax.swing.JLabel classicModeAnswerLabel;
    private javax.swing.JPanel classicModeAnswerPanel;
    private javax.swing.JPanel classicModeGeneralPanel;
    private javax.swing.JPanel classicModePanel;
    private javax.swing.JLabel classicModePlayerLabel;
    private javax.swing.JLabel classicModeQuestionLabel;
    private javax.swing.JPanel classicModeQuestionPanel;
    private javax.swing.JScrollPane classicModeQuestionScrollPane;
    private javax.swing.JTextArea classicModeQuestionTextArea;
    private javax.swing.JLabel classicModeTitleLabel1;
    private javax.swing.JLabel classicModeTitleLabel2;
    private javax.swing.JPanel classicModeTitlePanel;
    private javax.swing.JButton elevatorModeAnswer1;
    private javax.swing.JButton elevatorModeAnswer2;
    private javax.swing.JButton elevatorModeAnswer3;
    private javax.swing.JButton elevatorModeAnswer4;
    private javax.swing.JLabel elevatorModeAnswerLabel;
    private javax.swing.JPanel elevatorModeAnswerPanel;
    private javax.swing.JPanel elevatorModeGeneralPanel1;
    private javax.swing.JPanel elevatorModeGeneralPanel2;
    private javax.swing.JPanel elevatorModeGeneralPanel3;
    private javax.swing.JPanel elevatorModeInfoPanel;
    private javax.swing.JLabel elevatorModeNoOfQuestLabel;
    private javax.swing.JPanel elevatorModePanel;
    private javax.swing.JLabel elevatorModePlayerLabel;
    private javax.swing.JLabel elevatorModeQInfoLabel;
    private javax.swing.JLabel elevatorModeQuestionLabel;
    private javax.swing.JPanel elevatorModeQuestionPanel;
    private javax.swing.JScrollPane elevatorModeQuestionScrollPane;
    private javax.swing.JTextArea elevatorModeQuestionTextArea;
    private javax.swing.JLabel elevatorModeTimeInfoLabel;
    private javax.swing.JLabel elevatorModeTimeLabel;
    private javax.swing.JLabel elevatorModeTitleLabel1;
    private javax.swing.JLabel elevatorModeTitleLabel2;
    private javax.swing.JPanel elevatorModeTitlePanel;
    private javax.swing.JEditorPane jEditorPane1;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JPanel mainMenuBtnPanel;
    private javax.swing.JPanel mainMenuLabelPanel;
    private javax.swing.JPanel mainMenuPanel;
    private javax.swing.JPanel mainMenuPanel2;
    private javax.swing.JLabel mainMenuTitleLabel;
    private javax.swing.JButton oneminquestModeAnswer1;
    private javax.swing.JButton oneminquestModeAnswer2;
    private javax.swing.JButton oneminquestModeAnswer3;
    private javax.swing.JButton oneminquestModeAnswer4;
    private javax.swing.JLabel oneminquestModeAnswerLabel;
    private javax.swing.JPanel oneminquestModeAnswerPanel;
    private javax.swing.JPanel oneminquestModeGeneralPanel;
    private javax.swing.JPanel oneminquestModeInfoPanel;
    private javax.swing.JLabel oneminquestModeNoOfQuestLabel;
    private javax.swing.JPanel oneminquestModePanel;
    private javax.swing.JLabel oneminquestModePlayerLabel;
    private javax.swing.JLabel oneminquestModeQInfoLabel;
    private javax.swing.JLabel oneminquestModeQuestionLabel;
    private javax.swing.JPanel oneminquestModeQuestionPanel;
    private javax.swing.JScrollPane oneminquestModeQuestionScrollPane;
    private javax.swing.JTextArea oneminquestModeQuestionTextArea;
    private javax.swing.JLabel oneminquestModeTimeInfoLabel;
    private javax.swing.JLabel oneminquestModeTimeLabel;
    private javax.swing.JLabel oneminquestModeTitleLabel1;
    private javax.swing.JLabel oneminquestModeTitleLabel2;
    private javax.swing.JPanel oneminquestModeTitlePanel;
    private javax.swing.JPanel openPanel;
    private javax.swing.JPanel openPanel1;
    private javax.swing.JLabel openPanelIconLabel;
    private javax.swing.JButton openPanelStartBtn;
    private javax.swing.JLabel openPanelTitleLabel;
    private javax.swing.JButton playerNameBackBtn;
    private javax.swing.JButton playerNameBeginBtn;
    private javax.swing.JPanel playerNameGeneralPanel;
    private javax.swing.JPanel playerNameInfoPanel1;
    private javax.swing.JPanel playerNameInfoPanel2;
    private javax.swing.JPanel playerNameInfoPanel3;
    private javax.swing.JPanel playerNameInfoPanel4;
    private javax.swing.JPanel playerNamePanel;
    private javax.swing.JTextField playerNamePlayer1Field;
    private javax.swing.JLabel playerNamePlayer1Label;
    private javax.swing.JTextField playerNamePlayer2Field;
    private javax.swing.JLabel playerNamePlayer2Label;
    private javax.swing.JTextField playerNamePlayer3Field;
    private javax.swing.JLabel playerNamePlayer3Label;
    private javax.swing.JTextField playerNamePlayer4Field;
    private javax.swing.JLabel playerNamePlayer4Label;
    private javax.swing.JLabel playerNameTitleLabel;
    private javax.swing.JPanel playerNameTitlePanel;
    private javax.swing.JButton quickGameBtn;
    private javax.swing.JButton timeattackModeAnswer1;
    private javax.swing.JButton timeattackModeAnswer2;
    private javax.swing.JButton timeattackModeAnswer3;
    private javax.swing.JButton timeattackModeAnswer4;
    private javax.swing.JLabel timeattackModeAnswerLabel;
    private javax.swing.JPanel timeattackModeAnswerPanel;
    private javax.swing.JPanel timeattackModeGeneralPanel;
    private javax.swing.JPanel timeattackModeGeneralPanel2;
    private javax.swing.JPanel timeattackModeInfoPanel;
    private javax.swing.JLabel timeattackModeNoOfQuestLabel;
    private javax.swing.JLabel timeattackModeNoOfQuestLabel1;
    private javax.swing.JPanel timeattackModePanel;
    private javax.swing.JLabel timeattackModePlayerLabel;
    private javax.swing.JLabel timeattackModeQInfoLabel;
    private javax.swing.JLabel timeattackModeQInfoLabel1;
    private javax.swing.JLabel timeattackModeQuestionLabel;
    private javax.swing.JPanel timeattackModeQuestionPanel;
    private javax.swing.JScrollPane timeattackModeQuestionScrollPane;
    private javax.swing.JLabel timeattackModeTimeInfoLabel;
    private javax.swing.JLabel timeattackModeTimeLabel;
    private javax.swing.JLabel timeattackModeTitleLabel1;
    private javax.swing.JLabel timeattackModeTitleLabel2;
    private javax.swing.JPanel timeattackModeTitlePanel;
    private javax.swing.JTextArea timeattackQuestionTextArea;
    // End of variables declaration//GEN-END:variables
}
