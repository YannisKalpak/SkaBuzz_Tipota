import java.util.*;

public class GamblingMode extends Modes {
    
   public GamblingMode(DataBase questionsData,String currentCategory,int currentCategoryPos,Players[] allPlayers){ 
          ModeName = "Gambling Mode"; 
          importData(questionsData,currentCategory,currentCategoryPos,allPlayers);
   
    }

     
    public void run(){ 
          ModeAvailable = false;
          QuestionsData.CompleteStack( CurrentCategoryPos );    
          Scanner input = new Scanner(System.in);
          makeList();
          
              boolean choice = true;
              int bet;
             
              for(int i=0;i<8;i++) {
			for(Players CurrentPlayer : PlayersList){
				
				System.out.println("Σειρά του χρήστη " + CurrentPlayer.getPlayerName() + " για να παίξει");
				
				int CurrentQuestion = QuestionsData.PickingStack.peek();
			
				System.out.println(QuestionsData.Questions[CurrentQuestion]);            // ta minimata afta tha emfanizontai sto GUI
				System.out.println(QuestionsData.Answers[CurrentQuestion][0] + "     " + QuestionsData.Answers[CurrentQuestion][1]);
				System.out.println(QuestionsData.Answers[CurrentQuestion][2] + "     " + QuestionsData.Answers[CurrentQuestion][3]);
	
				int PlayersAnswer = input.nextInt() - 1;  //edw tha epistrefete i timi analoga me to ti exei pathsei o xristis 
			
				if(QuestionsData.CheckAnswer(PlayersAnswer,CurrentQuestion) == true) {
					System.out.println("Μπράβο απάντησες σωστά");
					CurrentPlayer.addPoints(100);
				}
				else {
					System.out.println("Λάθος απάντηση");
					QuestionsData.ShowCorrectAnswer(CurrentQuestion);
				}	
			
                               if(choice == QuestionsData.CheckAnswer(PlayersAnswer,CurrentQuestion)){ 
                                         Players.addPoints(bet *2);
                               }
                               
                               else{
                                    Players.removePoints(bet);
                               }
                                   
                        }  
			QuestionsData.PickingStack.pop();
		}	
     }
}
