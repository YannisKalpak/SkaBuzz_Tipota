import java.util.ArrayList;
import java.util.Scanner;

public class SurvivalMode extends Modes{
	ArrayList<Players> PRPList = new ArrayList<Players>();
	
	public SurvivalMode(DataBase questionsData,String currentCategory,int currentCategoryPos,Players[] allPlayers) {
		ModeName = "Survival Mode";
		importData(questionsData,currentCategory,currentCategoryPos,allPlayers);
		
	}
	
	
	public void run() {
		ModeAvailable = false;
		QuestionsData.CompleteStack( CurrentCategoryPos );
		Scanner input = new Scanner(System.in);
		makeList();

		
		
		int PointsToRemove = 500;
		
		for(int i=0;i<4;i++) {
			PRPList.add(AllPlayers[i]);
		}
		
		boolean ModeStillOn = true;
		int j = 0;
		

		
		while(ModeStillOn) {
			for(Players CurrentPlayer : PlayersList) {
				System.out.println("hello");
				if(CurrentPlayer.getLives() > 0) {
					System.out.println("Σειρά του χρήστη " + CurrentPlayer.getPlayerName() + " για να παίξει");
					
					int CurrentQuestion = QuestionsData.PickingStack.peek();
				
					System.out.println(QuestionsData.Questions[CurrentQuestion]);            // ta minimata afta tha emfanizontai sto GUI
					System.out.println(QuestionsData.Answers[CurrentQuestion][0] + " 	 " + QuestionsData.Answers[CurrentQuestion][1]);
					System.out.println(QuestionsData.Answers[CurrentQuestion][2] + "	 " + QuestionsData.Answers[CurrentQuestion][3]);
		
					int PlayersAnswer = input.nextInt() - 1;  //edw tha epistrefete i timi analoga me to ti exei pathsei o xristis 
				
					if(QuestionsData.CheckAnswer(PlayersAnswer,CurrentQuestion) == true) {
						System.out.println("Μπράβο απάντησες σωστά");
					}
					else {
						System.out.println("Λάθος απάντηση");
						QuestionsData.ShowCorrectAnswer(CurrentQuestion);
						CurrentPlayer.RemoveLive();
					}
				     
                                        CurrentPlayer.addPoints(CurrentPlayer.getLives() * 300 + BannedPlayers() * 100);
                                       System.out.println("Ο παίκτης : " + CurrentPlayer.getPlayerName() + " έχει : " + CurrentPlayer.getPoints() + " πόντους");
                                }
				QuestionsData.PickingStack.pop();
			}
			
			if(BannedPlayers() != 0) {
				for(Players CurrentPlayer : PlayersList) {
					if(CurrentPlayer.getLives() == 0) {
						if(	PRPList.contains(CurrentPlayer)	) {
							System.out.println("Ο παίκτης : " + CurrentPlayer.getPlayerName() + " χάνει : " + CurrentPlayer.getPoints() + " πόντους");
							CurrentPlayer.removePoints(PointsToRemove);
							PRPList.remove(CurrentPlayer);
						}
					}
					
				}
				PointsToRemove = 500 - BannedPlayers() * 200;
			}
			
			j++;
			
			if(BannedPlayers() >= 3 || j == 10) {
				ModeStillOn = false;
			}
		}
		
		/*for(Players CurrentPlayer : PlayersList) {
			if(CurrentPlayer.getLives() > 0) {
				CurrentPlayer.addPoints(CurrentPlayer.getLives() * 300 + BannedPlayers() * 100);
			}
	
		System.out.println("Ο παίκτης : " + CurrentPlayer.getPlayerName() + " έχει : " + CurrentPlayer.getPoints() + " πόντους");
		}*/
	}
	
	public int BannedPlayers() {
		int bannedPlayers = 0;
		for(Players CurrentPlayer : PlayersList) {
			if(CurrentPlayer.getLives() == 0) {
				bannedPlayers++;
			}
		}
		return bannedPlayers;
	}
}
