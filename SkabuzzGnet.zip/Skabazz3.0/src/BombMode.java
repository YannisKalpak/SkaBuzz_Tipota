import java.util.*;

public class BombMode extends Modes{
	
	public BombMode(DataBase questionsData,String currentCategory,int currentCategoryPos,Players[] allPlayers){
		ModeName = "Bomb Mode";
		importData(questionsData,currentCategory,currentCategoryPos,allPlayers);
		
	}
	
	
	public void run() {
		ModeAvailable = false;
		QuestionsData.CompleteStack( CurrentCategoryPos );
		Scanner input = new Scanner(System.in);
		
		
		boolean TimerRunOut = false;
		boolean PlayerAnswered = true;

		
		int NextHolder = new Random().nextInt(4);
		Players PlayerHoldingTheBomb = AllPlayers[NextHolder] ;

		int NumberOfWrongAnswers = 0;
		
		int BombSeconds = new Random().nextInt(45) + 45;
		long BombTimeStart = System.currentTimeMillis();
		long BombTimerEnd = BombTimeStart + BombSeconds * 1000; // 60 seconds * 1000 ms/sec
		
		
		while (!TimerRunOut && PlayerAnswered == true && NumberOfWrongAnswers <4)
		{
			PlayerAnswered = false;
			
			int CurrentQuestion = QuestionsData.PickingStack.peek();
			System.out.println(QuestionsData.Questions[CurrentQuestion]);            // ta minimata afta tha emfanizontai sto GUI
			System.out.println(QuestionsData.Answers[CurrentQuestion][0] + " " + QuestionsData.Answers[CurrentQuestion][1]);
			System.out.println(QuestionsData.Answers[CurrentQuestion][2] + " " + QuestionsData.Answers[CurrentQuestion][3]);
			
			int PlayersAnswer = input.nextInt() - 1;
			PlayerAnswered = true;
			
			if(QuestionsData.CheckAnswer(PlayersAnswer,CurrentQuestion) == true) {
				NumberOfWrongAnswers = 0;
				NextHolder = new Random().nextInt(4);
				PlayerHoldingTheBomb = AllPlayers[NextHolder];
			}
			else {
				NumberOfWrongAnswers++;
			}
			
			QuestionsData.PickingStack.pop();
			
			if(System.currentTimeMillis() > BombTimerEnd) {
				TimerRunOut = true;
			}
				
		}
		System.out.println("Time is up");
		System.out.println("Ο παίκτης " + PlayerHoldingTheBomb.getPlayerName() + "χάνει 500 πόντους");
		PlayerHoldingTheBomb.removePoints(500);	
	}
	
}


