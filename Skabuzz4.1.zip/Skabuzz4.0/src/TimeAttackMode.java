import java.util.*;

public class TimeAttackMode extends Modes {
    
     public TimeAttackMode(DataBase questionsData,String currentCategory,int currentCategoryPos,Players[] allPlayers) {
		ModeName = "Time Attack Mode";
		importData(questionsData,currentCategory,currentCategoryPos,allPlayers);
		
	}	

        public void run(){ 
               ModeAvailable = false;
               QuestionsData.CompleteStack( CurrentCategoryPos );    
               Scanner input = new Scanner(System.in); 
               makeList();
                
                long TimerStart = System.currentTimeMillis();
		long TimerEnd = TimerStart + 15*1000;
                int TimeLeft;
                boolean TimeRunout = false;
               
                for(int i=0;i<10;i++){
                   for(Players CurrentPlayer : PlayersList){   
                     while(!TimeRunout){
                         int CurrentQuestion = QuestionsData.PickingStack.peek();
      		
                         System.out.println(QuestionsData.Questions[CurrentQuestion]);            // ta minimata afta tha emfanizontai sto GUI
			 System.out.println(QuestionsData.Answers[CurrentQuestion][0] + " " + QuestionsData.Answers[CurrentQuestion][1]);
			 System.out.println(QuestionsData.Answers[CurrentQuestion][2] + " " + QuestionsData.Answers[CurrentQuestion][3]);
			
			 int PlayersAnswer = input.nextInt() - 1;
                    
                         if(QuestionsData.CheckAnswer(PlayersAnswer,CurrentQuestion) == true) {
					System.out.println("Μπράβο απάντησες σωστά");
					CurrentPlayer.addPoints(TimeLeft * 10);
				}
				else {
					System.out.println("Λάθος απάντηση");
					QuestionsData.ShowCorrectAnswer(CurrentQuestion);
                                } 
                             if(System.currentTimeMillis() > TimerEnd)
                                     TimeRunout = true;
                        }
                   }
               
                    QuestionsData.PickingStack.pop();
            
               }
        }










}
