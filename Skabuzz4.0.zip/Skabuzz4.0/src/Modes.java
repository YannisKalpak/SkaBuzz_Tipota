import java.util.ArrayList;

public abstract class Modes {

	protected boolean ModeAvailable = true;
	protected String ModeName;
	protected DataBase QuestionsData;
	protected String CurrentCategory;
	protected int CurrentCategoryPos;
	protected Players[] AllPlayers = new Players[4] ;
	protected ArrayList<Players> PlayersList = new ArrayList<Players>();
	protected Players CurrentPlayer;

	
	public String getModeName()
	{
		return ModeName;
	}
	
	public void importData(DataBase questionsData,String currentCategory,int currentCategoryPos,Players[] allPlayers) {
		QuestionsData = questionsData;
		CurrentCategory = currentCategory;
		CurrentCategoryPos = currentCategoryPos;
		AllPlayers = allPlayers;
	}
	
	public void makeList() {
		for(int i=0;i<4;i++) {
			PlayersList.add( AllPlayers[i] );
		}
	}
	
	public abstract void run();
}
