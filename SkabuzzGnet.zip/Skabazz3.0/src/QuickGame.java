import java.util.*;


public class QuickGame extends GameType{
	
    private javax.swing.JButton quickGameAnswer1;
    private javax.swing.JButton quickGameAnswer2;
    private javax.swing.JButton quickGameAnswer3;
    private javax.swing.JButton quickGameAnswer4;
    private javax.swing.JLabel quickGameAnswerLabel;
    private javax.swing.JPanel quickGameAnswerPanel;
    private javax.swing.JButton quickGameBtn;
    private javax.swing.JPanel quickGameGeneralPanel;
    private javax.swing.JPanel quickGamePanel;
    private javax.swing.JLabel quickGamePlayerLabel;
    private javax.swing.JLabel quickGameQuestionLabel;
    private javax.swing.JPanel quickGameQuestionPanel;
    private javax.swing.JScrollPane quickGameQuestionScrollPane;
    private javax.swing.JTextArea quickGameQuestionTextArea;
    private javax.swing.JLabel quickGameTitleLabel1;
    private javax.swing.JLabel quickGameTitleLabel2;
    private javax.swing.JPanel quickGameTitlePanel;
    private javax.swing.JPanel quickGRoundSelectCheckPanel;
    private javax.swing.JPanel quickGRoundSelectGeneralPanel;
    private javax.swing.JLabel quickGRoundSelectNoOfRLabel;
    private javax.swing.JPanel quickGRoundSelectPanel;
    private javax.swing.JRadioButton quickGRoundSelectRadioBtn1;
    private javax.swing.JRadioButton quickGRoundSelectRadioBtn2;
    private javax.swing.JRadioButton quickGRoundSelectRadioBtn3;
    private javax.swing.JRadioButton quickGRoundSelectRadioBtn4;
    private javax.swing.JRadioButton quickGRoundSelectRadioBtn5;
    private javax.swing.JLabel quickGRoundSelectTitleLabel;
    private javax.swing.JPanel quickGRoundSelectTitlePanel;
    private javax.swing.JButton jButton1;
    
    private javax.swing.JFrame mainFrame;
    
    int RoundsPickedByPlayers = 1;
    int PlayersAnswer ;
    boolean ButtonPressed = false;
    
    
    
    
	public QuickGame() {
		String Player1Name = "Player1";
		String Player2Name = "Player2";
		String Player3Name = "Player3";
		String Player4Name = "Player4";
		
		AllPlayers[0] = new Players(Player1Name);
		AllPlayers[1] = new Players(Player2Name);
		AllPlayers[2] = new Players(Player3Name);
		AllPlayers[3] = new Players(Player4Name);
		
		for(int i=0;i<4;i++) {
			PlayersList.add( AllPlayers[i] );
		}
                
                                
                this.createQuickGamePanel();
                this.createQuickGRSelect();
                
                mainFrame = new javax.swing.JFrame();
                mainFrame.setSize(1201, 777);
                //mainPanel.add(quickGamePanel);
                mainFrame.setVisible(true);
                mainFrame.add(quickGRoundSelectPanel);
                
                //quickGRoundSelectPanel.setVisible(false);
                //getContentPane().removeAll();
               // mainFrame.setVisible(true);
                //quickGamePanel.setVisible(false);
                quickGRoundSelectPanel.setVisible(false);
                


	}
	
	public void run() {
		DataBase QuestionsData = new DataBase();
		Scanner input = new Scanner(System.in);
		QuestionsData.CompleteStack(0);
                
               // getContentPane().add(quickGRoundSelectPanel);
                quickGRoundSelectPanel.setVisible(true);
                //changePanels(quickGRoundSelectPanel);
                System.out.println("EISAI MALAKAS");
		
		for(int i=0;i<RoundsPickedByPlayers;i++) {
                    quickGameTitleLabel2.setText(Integer.toString(i));
			for(int j=0;j<8;j++) {
				for(Players CurrentPlayer : PlayersList){
                                    ButtonPressed = false;
                                    quickGamePlayerLabel.setText(CurrentPlayer.getPlayerName());
                                    int CurrentQuestion = QuestionsData.PickingStack.peek() + j * 50;
                                    quickGameQuestionLabel.setText(QuestionsData.Questions[CurrentQuestion]);
                                    quickGameAnswer1.setText(QuestionsData.Answers[CurrentQuestion][0]);
                                    quickGameAnswer2.setText(QuestionsData.Answers[CurrentQuestion][1]);
                                    quickGameAnswer3.setText(QuestionsData.Answers[CurrentQuestion][2]);
                                    quickGameAnswer4.setText(QuestionsData.Answers[CurrentQuestion][3]);
                                    
                                    
                                    while(!ButtonPressed)
                                    {
					if(  ButtonPressed && ( QuestionsData.CheckAnswer(PlayersAnswer,CurrentQuestion) == true) ) {
						CurrentPlayer.addPoints(100);
					}
	
                                    }
				}		
				QuestionsData.PickingStack.pop();
			}
		}
	}
	
        
        public void createQuickGamePanel()
        {
            
 
        quickGameBtn = new javax.swing.JButton();

        quickGamePanel = new javax.swing.JPanel();
        quickGameGeneralPanel = new javax.swing.JPanel();
        quickGameTitlePanel = new javax.swing.JPanel();
        quickGameTitleLabel1 = new javax.swing.JLabel();
        quickGameTitleLabel2 = new javax.swing.JLabel();
        quickGameQuestionPanel = new javax.swing.JPanel();
        quickGameQuestionScrollPane = new javax.swing.JScrollPane();
        quickGameQuestionTextArea = new javax.swing.JTextArea();
        quickGameQuestionLabel = new javax.swing.JLabel();
        quickGamePlayerLabel = new javax.swing.JLabel();
        quickGameAnswerPanel = new javax.swing.JPanel();
        quickGameAnswerLabel = new javax.swing.JLabel();
        quickGameAnswer1 = new javax.swing.JButton();
        quickGameAnswer2 = new javax.swing.JButton();
        quickGameAnswer3 = new javax.swing.JButton();
        quickGameAnswer4 = new javax.swing.JButton();


              
         quickGamePanel.setPreferredSize(new java.awt.Dimension(1201, 777));

        quickGameTitleLabel1.setFont(new java.awt.Font("Arial Black", 0, 36)); // NOI18N
        quickGameTitleLabel1.setText("ΓΥΡΟΣ");

        quickGameTitleLabel2.setFont(new java.awt.Font("Arial Black", 0, 36)); // NOI18N

        javax.swing.GroupLayout quickGameTitlePanelLayout = new javax.swing.GroupLayout(quickGameTitlePanel);
        quickGameTitlePanel.setLayout(quickGameTitlePanelLayout);
        quickGameTitlePanelLayout.setHorizontalGroup(
            quickGameTitlePanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(quickGameTitlePanelLayout.createSequentialGroup()
                .addGap(216, 216, 216)
                .addComponent(quickGameTitleLabel1)
                .addGap(18, 18, 18)
                .addComponent(quickGameTitleLabel2, javax.swing.GroupLayout.PREFERRED_SIZE, 71, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(225, Short.MAX_VALUE))
        );
        quickGameTitlePanelLayout.setVerticalGroup(
            quickGameTitlePanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(quickGameTitlePanelLayout.createSequentialGroup()
                .addContainerGap()
                .addGroup(quickGameTitlePanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(quickGameTitleLabel2, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(quickGameTitleLabel1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                .addContainerGap())
        );

        quickGameQuestionScrollPane.setHorizontalScrollBarPolicy(javax.swing.ScrollPaneConstants.HORIZONTAL_SCROLLBAR_NEVER);
        quickGameQuestionScrollPane.setVerticalScrollBarPolicy(javax.swing.ScrollPaneConstants.VERTICAL_SCROLLBAR_NEVER);

        quickGameQuestionTextArea.setColumns(20);
        quickGameQuestionTextArea.setFont(new java.awt.Font("Arial", 2, 24)); // NOI18N
        quickGameQuestionTextArea.setLineWrap(true);
        quickGameQuestionTextArea.setRows(5);
        quickGameQuestionScrollPane.setViewportView(quickGameQuestionTextArea);

        quickGameQuestionLabel.setFont(new java.awt.Font("Arial", 0, 24)); // NOI18N
        quickGameQuestionLabel.setText("ΕΡΩΤΗΣΗ ΓΙΑ ΤΟΝ ΠΑΙΚΤΗ:");

        quickGamePlayerLabel.setFont(new java.awt.Font("Arial", 2, 24)); // NOI18N

        javax.swing.GroupLayout quickGameQuestionPanelLayout = new javax.swing.GroupLayout(quickGameQuestionPanel);
        quickGameQuestionPanel.setLayout(quickGameQuestionPanelLayout);
        quickGameQuestionPanelLayout.setHorizontalGroup(
            quickGameQuestionPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(quickGameQuestionPanelLayout.createSequentialGroup()
                .addGap(20, 20, 20)
                .addGroup(quickGameQuestionPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(quickGameQuestionScrollPane)
                    .addGroup(quickGameQuestionPanelLayout.createSequentialGroup()
                        .addComponent(quickGameQuestionLabel)
                        .addGap(18, 18, 18)
                        .addComponent(quickGamePlayerLabel, javax.swing.GroupLayout.PREFERRED_SIZE, 238, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(0, 377, Short.MAX_VALUE)))
                .addContainerGap())
        );
        quickGameQuestionPanelLayout.setVerticalGroup(
            quickGameQuestionPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, quickGameQuestionPanelLayout.createSequentialGroup()
                .addGroup(quickGameQuestionPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(quickGameQuestionLabel, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(quickGamePlayerLabel, javax.swing.GroupLayout.PREFERRED_SIZE, 29, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(quickGameQuestionScrollPane, javax.swing.GroupLayout.PREFERRED_SIZE, 90, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap())
        );

        quickGameAnswerLabel.setFont(new java.awt.Font("Arial", 0, 24)); // NOI18N
        quickGameAnswerLabel.setText("ΑΠΑΝΤΗΣΕΙΣ:");

        quickGameAnswer1.setFont(new java.awt.Font("Arial", 0, 24)); // NOI18N

        quickGameAnswer2.setFont(new java.awt.Font("Arial", 0, 24)); // NOI18N

        quickGameAnswer3.setFont(new java.awt.Font("Arial", 0, 24)); // NOI18N

        quickGameAnswer4.setFont(new java.awt.Font("Arial", 0, 24)); // NOI18N

        javax.swing.GroupLayout quickGameAnswerPanelLayout = new javax.swing.GroupLayout(quickGameAnswerPanel);
        quickGameAnswerPanel.setLayout(quickGameAnswerPanelLayout);
        quickGameAnswerPanelLayout.setHorizontalGroup(
            quickGameAnswerPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(quickGameAnswerPanelLayout.createSequentialGroup()
                .addGroup(quickGameAnswerPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(quickGameAnswerLabel)
                    .addGroup(quickGameAnswerPanelLayout.createSequentialGroup()
                        .addContainerGap()
                        .addGroup(quickGameAnswerPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                            .addComponent(quickGameAnswer3, javax.swing.GroupLayout.DEFAULT_SIZE, 350, Short.MAX_VALUE)
                            .addComponent(quickGameAnswer1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 159, Short.MAX_VALUE)
                        .addGroup(quickGameAnswerPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                            .addComponent(quickGameAnswer2, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                            .addComponent(quickGameAnswer4, javax.swing.GroupLayout.DEFAULT_SIZE, 350, Short.MAX_VALUE))))
                .addGap(45, 45, 45))
        );
        quickGameAnswerPanelLayout.setVerticalGroup(
            quickGameAnswerPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(quickGameAnswerPanelLayout.createSequentialGroup()
                .addContainerGap()
                .addComponent(quickGameAnswerLabel, javax.swing.GroupLayout.PREFERRED_SIZE, 36, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(29, 29, 29)
                .addGroup(quickGameAnswerPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(quickGameAnswer1, javax.swing.GroupLayout.PREFERRED_SIZE, 80, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(quickGameAnswer2, javax.swing.GroupLayout.PREFERRED_SIZE, 80, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(64, 64, 64)
                .addGroup(quickGameAnswerPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(quickGameAnswer4, javax.swing.GroupLayout.PREFERRED_SIZE, 81, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(quickGameAnswer3, javax.swing.GroupLayout.PREFERRED_SIZE, 81, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(114, 114, 114))
        );

        javax.swing.GroupLayout quickGameGeneralPanelLayout = new javax.swing.GroupLayout(quickGameGeneralPanel);
        quickGameGeneralPanel.setLayout(quickGameGeneralPanelLayout);
        quickGameGeneralPanelLayout.setHorizontalGroup(
            quickGameGeneralPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(quickGameGeneralPanelLayout.createSequentialGroup()
                .addContainerGap(94, Short.MAX_VALUE)
                .addGroup(quickGameGeneralPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(quickGameGeneralPanelLayout.createSequentialGroup()
                        .addGap(126, 126, 126)
                        .addComponent(quickGameTitlePanel, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(quickGameGeneralPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                        .addComponent(quickGameAnswerPanel, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addComponent(quickGameQuestionPanel, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addContainerGap(102, Short.MAX_VALUE))
        );
        quickGameGeneralPanelLayout.setVerticalGroup(
            quickGameGeneralPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(quickGameGeneralPanelLayout.createSequentialGroup()
                .addGap(37, 37, 37)
                .addComponent(quickGameTitlePanel, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(79, 79, 79)
                .addComponent(quickGameQuestionPanel, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(quickGameAnswerPanel, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );

        javax.swing.GroupLayout quickGamePanelLayout = new javax.swing.GroupLayout(quickGamePanel);
        quickGamePanel.setLayout(quickGamePanelLayout);
        quickGamePanelLayout.setHorizontalGroup(
            quickGamePanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, quickGamePanelLayout.createSequentialGroup()
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(quickGameGeneralPanel, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(33, 33, 33))
        );
        quickGamePanelLayout.setVerticalGroup(
            quickGamePanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(quickGamePanelLayout.createSequentialGroup()
                .addContainerGap()
                .addComponent(quickGameGeneralPanel, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addContainerGap())
        );
        }
	
        public void createQuickGRSelect()
        {
         
                    quickGRoundSelectPanel = new javax.swing.JPanel();
        quickGRoundSelectGeneralPanel = new javax.swing.JPanel();
        quickGRoundSelectTitlePanel = new javax.swing.JPanel();
        quickGRoundSelectTitleLabel = new javax.swing.JLabel();
        quickGRoundSelectCheckPanel = new javax.swing.JPanel();
        quickGRoundSelectNoOfRLabel = new javax.swing.JLabel();
        quickGRoundSelectRadioBtn1 = new javax.swing.JRadioButton();
        quickGRoundSelectRadioBtn2 = new javax.swing.JRadioButton();
        quickGRoundSelectRadioBtn3 = new javax.swing.JRadioButton();
        quickGRoundSelectRadioBtn4 = new javax.swing.JRadioButton();
        quickGRoundSelectRadioBtn5 = new javax.swing.JRadioButton();
         jButton1 = new javax.swing.JButton();
            
        quickGRoundSelectPanel.setPreferredSize(new java.awt.Dimension(1201, 777));

        quickGRoundSelectTitleLabel.setFont(new java.awt.Font("Arial Black", 0, 36)); // NOI18N
        quickGRoundSelectTitleLabel.setText("ΕΠΙΛΕΞΤΕ ΑΡΙΘΜΟ ΓΥΡΩΝ");

        
                jButton1.setText("mounoskylo");
        jButton1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton1ActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout quickGRoundSelectCheckPanelLayout = new javax.swing.GroupLayout(quickGRoundSelectCheckPanel);
        quickGRoundSelectCheckPanel.setLayout(quickGRoundSelectCheckPanelLayout);
        quickGRoundSelectCheckPanelLayout.setHorizontalGroup(
            quickGRoundSelectCheckPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(quickGRoundSelectCheckPanelLayout.createSequentialGroup()
                .addGroup(quickGRoundSelectCheckPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(quickGRoundSelectCheckPanelLayout.createSequentialGroup()
                        .addContainerGap()
                        .addComponent(quickGRoundSelectNoOfRLabel, javax.swing.GroupLayout.PREFERRED_SIZE, 333, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(16, 16, 16)
                        .addComponent(quickGRoundSelectRadioBtn1, javax.swing.GroupLayout.PREFERRED_SIZE, 65, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(10, 10, 10)
                        .addComponent(quickGRoundSelectRadioBtn2, javax.swing.GroupLayout.PREFERRED_SIZE, 65, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(18, 18, 18)
                        .addComponent(quickGRoundSelectRadioBtn4, javax.swing.GroupLayout.PREFERRED_SIZE, 65, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addComponent(quickGRoundSelectRadioBtn5, javax.swing.GroupLayout.PREFERRED_SIZE, 65, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addComponent(quickGRoundSelectRadioBtn3, javax.swing.GroupLayout.PREFERRED_SIZE, 65, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(quickGRoundSelectCheckPanelLayout.createSequentialGroup()
                        .addGap(231, 231, 231)
                        .addComponent(jButton1, javax.swing.GroupLayout.PREFERRED_SIZE, 229, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addContainerGap(114, Short.MAX_VALUE))
        );
        quickGRoundSelectCheckPanelLayout.setVerticalGroup(
            quickGRoundSelectCheckPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(quickGRoundSelectCheckPanelLayout.createSequentialGroup()
                .addGap(122, 122, 122)
                .addGroup(quickGRoundSelectCheckPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(quickGRoundSelectNoOfRLabel, javax.swing.GroupLayout.PREFERRED_SIZE, 61, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(quickGRoundSelectRadioBtn1, javax.swing.GroupLayout.PREFERRED_SIZE, 33, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(quickGRoundSelectRadioBtn2, javax.swing.GroupLayout.PREFERRED_SIZE, 33, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(quickGRoundSelectRadioBtn4, javax.swing.GroupLayout.PREFERRED_SIZE, 33, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(quickGRoundSelectRadioBtn3, javax.swing.GroupLayout.PREFERRED_SIZE, 33, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(quickGRoundSelectRadioBtn5, javax.swing.GroupLayout.PREFERRED_SIZE, 33, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 92, Short.MAX_VALUE)
                .addComponent(jButton1, javax.swing.GroupLayout.PREFERRED_SIZE, 83, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(56, 56, 56))
        );
        
        javax.swing.GroupLayout quickGRoundSelectTitlePanelLayout = new javax.swing.GroupLayout(quickGRoundSelectTitlePanel);
        quickGRoundSelectTitlePanel.setLayout(quickGRoundSelectTitlePanelLayout);
        quickGRoundSelectTitlePanelLayout.setHorizontalGroup(
            quickGRoundSelectTitlePanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(quickGRoundSelectTitlePanelLayout.createSequentialGroup()
                .addGap(106, 106, 106)
                .addComponent(quickGRoundSelectTitleLabel)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );
        quickGRoundSelectTitlePanelLayout.setVerticalGroup(
            quickGRoundSelectTitlePanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, quickGRoundSelectTitlePanelLayout.createSequentialGroup()
                .addContainerGap(25, Short.MAX_VALUE)
                .addComponent(quickGRoundSelectTitleLabel, javax.swing.GroupLayout.PREFERRED_SIZE, 64, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap())
        );

        quickGRoundSelectNoOfRLabel.setFont(new java.awt.Font("Arial", 2, 36)); // NOI18N
        quickGRoundSelectNoOfRLabel.setText("ΑΡΙΘΜΟΣ ΓΥΡΩΝ:");
        quickGRoundSelectNoOfRLabel.setBorder(javax.swing.BorderFactory.createBevelBorder(javax.swing.border.BevelBorder.RAISED));

        quickGRoundSelectRadioBtn1.setFont(new java.awt.Font("Arial", 0, 36)); // NOI18N
        quickGRoundSelectRadioBtn1.setText("1");
        quickGRoundSelectRadioBtn1.setBorder(javax.swing.BorderFactory.createBevelBorder(javax.swing.border.BevelBorder.RAISED));
        quickGRoundSelectRadioBtn1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                quickGRoundSelectRadioBtn1ActionPerformed(evt);
            }
        });

        quickGRoundSelectRadioBtn2.setFont(new java.awt.Font("Arial", 0, 36)); // NOI18N
        quickGRoundSelectRadioBtn2.setText("2");
        quickGRoundSelectRadioBtn2.setBorder(javax.swing.BorderFactory.createBevelBorder(javax.swing.border.BevelBorder.RAISED));
        quickGRoundSelectRadioBtn2.setPreferredSize(new java.awt.Dimension(45, 51));
        quickGRoundSelectRadioBtn2.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                quickGRoundSelectRadioBtn2ActionPerformed(evt);
            }
        });

        quickGRoundSelectRadioBtn3.setFont(new java.awt.Font("Arial", 0, 36)); // NOI18N
        quickGRoundSelectRadioBtn3.setText("5");
        quickGRoundSelectRadioBtn3.setBorder(javax.swing.BorderFactory.createBevelBorder(javax.swing.border.BevelBorder.RAISED));
        quickGRoundSelectRadioBtn3.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                quickGRoundSelectRadioBtn3ActionPerformed(evt);
            }
        });

        quickGRoundSelectRadioBtn4.setFont(new java.awt.Font("Arial", 0, 36)); // NOI18N
        quickGRoundSelectRadioBtn4.setText("3");
        quickGRoundSelectRadioBtn4.setBorder(javax.swing.BorderFactory.createBevelBorder(javax.swing.border.BevelBorder.RAISED));
        quickGRoundSelectRadioBtn4.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                quickGRoundSelectRadioBtn4ActionPerformed(evt);
            }
        });

        quickGRoundSelectRadioBtn5.setFont(new java.awt.Font("Arial", 0, 36)); // NOI18N
        quickGRoundSelectRadioBtn5.setText("4");
        quickGRoundSelectRadioBtn5.setBorder(javax.swing.BorderFactory.createBevelBorder(javax.swing.border.BevelBorder.RAISED));
        quickGRoundSelectRadioBtn5.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                quickGRoundSelectRadioBtn5ActionPerformed(evt);
            }
        });

        /*javax.swing.GroupLayout quickGRoundSelectCheckPanelLayout = new javax.swing.GroupLayout(quickGRoundSelectCheckPanel);
        quickGRoundSelectCheckPanel.setLayout(quickGRoundSelectCheckPanelLayout);
        quickGRoundSelectCheckPanelLayout.setHorizontalGroup(
            quickGRoundSelectCheckPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(quickGRoundSelectCheckPanelLayout.createSequentialGroup()
                .addContainerGap()
                .addComponent(quickGRoundSelectNoOfRLabel, javax.swing.GroupLayout.PREFERRED_SIZE, 333, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(16, 16, 16)
                .addComponent(quickGRoundSelectRadioBtn1, javax.swing.GroupLayout.PREFERRED_SIZE, 65, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(10, 10, 10)
                .addComponent(quickGRoundSelectRadioBtn2, javax.swing.GroupLayout.PREFERRED_SIZE, 65, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18)
                .addComponent(quickGRoundSelectRadioBtn4, javax.swing.GroupLayout.PREFERRED_SIZE, 65, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(quickGRoundSelectRadioBtn5, javax.swing.GroupLayout.PREFERRED_SIZE, 65, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(quickGRoundSelectRadioBtn3, javax.swing.GroupLayout.PREFERRED_SIZE, 65, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(114, Short.MAX_VALUE))
        );
        quickGRoundSelectCheckPanelLayout.setVerticalGroup(
            quickGRoundSelectCheckPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(quickGRoundSelectCheckPanelLayout.createSequentialGroup()
                .addGap(122, 122, 122)
                .addGroup(quickGRoundSelectCheckPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(quickGRoundSelectNoOfRLabel, javax.swing.GroupLayout.PREFERRED_SIZE, 61, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(quickGRoundSelectRadioBtn1, javax.swing.GroupLayout.PREFERRED_SIZE, 33, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(quickGRoundSelectRadioBtn2, javax.swing.GroupLayout.PREFERRED_SIZE, 33, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(quickGRoundSelectRadioBtn4, javax.swing.GroupLayout.PREFERRED_SIZE, 33, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(quickGRoundSelectRadioBtn3, javax.swing.GroupLayout.PREFERRED_SIZE, 33, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(quickGRoundSelectRadioBtn5, javax.swing.GroupLayout.PREFERRED_SIZE, 33, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addContainerGap(231, Short.MAX_VALUE))
        );*/

        javax.swing.GroupLayout quickGRoundSelectGeneralPanelLayout = new javax.swing.GroupLayout(quickGRoundSelectGeneralPanel);
        quickGRoundSelectGeneralPanel.setLayout(quickGRoundSelectGeneralPanelLayout);
        quickGRoundSelectGeneralPanelLayout.setHorizontalGroup(
            quickGRoundSelectGeneralPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(quickGRoundSelectGeneralPanelLayout.createSequentialGroup()
                .addGap(185, 185, 185)
                .addGroup(quickGRoundSelectGeneralPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                    .addComponent(quickGRoundSelectTitlePanel, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(quickGRoundSelectCheckPanel, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                .addContainerGap(150, Short.MAX_VALUE))
        );
        quickGRoundSelectGeneralPanelLayout.setVerticalGroup(
            quickGRoundSelectGeneralPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(quickGRoundSelectGeneralPanelLayout.createSequentialGroup()
                .addGap(28, 28, 28)
                .addComponent(quickGRoundSelectTitlePanel, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(85, 85, 85)
                .addComponent(quickGRoundSelectCheckPanel, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(128, Short.MAX_VALUE))
        );

        javax.swing.GroupLayout quickGRoundSelectPanelLayout = new javax.swing.GroupLayout(quickGRoundSelectPanel);
        quickGRoundSelectPanel.setLayout(quickGRoundSelectPanelLayout);
        quickGRoundSelectPanelLayout.setHorizontalGroup(
            quickGRoundSelectPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(quickGRoundSelectPanelLayout.createSequentialGroup()
                .addContainerGap()
                .addComponent(quickGRoundSelectGeneralPanel, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addContainerGap())
        );
        quickGRoundSelectPanelLayout.setVerticalGroup(
            quickGRoundSelectPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, quickGRoundSelectPanelLayout.createSequentialGroup()
                .addContainerGap()
                .addComponent(quickGRoundSelectGeneralPanel, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addContainerGap())
                
        );
        }
        
                private void changePanels(javax.swing.JPanel p1){
        getContentPane().removeAll();
        getContentPane().add(p1);
        p1.setVisible(true);
    }
        
    private void quickGRoundSelectRadioBtn1ActionPerformed(java.awt.event.ActionEvent evt) {                                                           
        RoundsPickedByPlayers = 1;
        //changePanels(quickGamePanel);
                //getContentPane().remove(quickGRoundSelectPanel);
       // getContentPane().add(quickGamePanel);
       quickGRoundSelectPanel.setVisible(false);
       //getContentPane().add(quickGamePanel);
       mainFrame.add(quickGamePanel);
        quickGamePanel.setVisible(true);
        //changePanels(quickGamePanel); 
        //getContentPane().removeAll();
        //quickGamePanel.setVisible(true);
    }                                                         

    private void quickGRoundSelectRadioBtn2ActionPerformed(java.awt.event.ActionEvent evt) {                                                           
        RoundsPickedByPlayers = 2;
        changePanels(quickGamePanel);
    }                                                          

    private void quickGRoundSelectRadioBtn3ActionPerformed(java.awt.event.ActionEvent evt) {                                                           
        RoundsPickedByPlayers = 3;
        changePanels(quickGamePanel);
    }                                                          

    private void quickGRoundSelectRadioBtn4ActionPerformed(java.awt.event.ActionEvent evt) {                                                           
        RoundsPickedByPlayers = 4;
        changePanels(quickGamePanel);
    }                                                          

    private void quickGRoundSelectRadioBtn5ActionPerformed(java.awt.event.ActionEvent evt) {                                                           
        RoundsPickedByPlayers = 5;
        changePanels(quickGamePanel);
    }
    
    private void quickGameAnswer1ActionPerformed(java.awt.event.ActionEvent evt,int PlayerAnswer,boolean ButtonPressed) {                                                 
        PlayerAnswer = 0;
        ButtonPressed = true ;
    }
    
    private void quickGameAnswer2ActionPerformed(java.awt.event.ActionEvent evt,int PlayerAnswer,boolean ButtonPressed) {                                                 
        PlayerAnswer = 1;
        ButtonPressed = true ;
    } 
    
    private void quickGameAnswer3ActionPerformed(java.awt.event.ActionEvent evt,int PlayerAnswer,boolean ButtonPressed) {                                                 
        PlayerAnswer = 2;
        ButtonPressed = true ;
    } 
    
    private void quickGameAnswer4ActionPerformed(java.awt.event.ActionEvent evt,int PlayerAnswer,boolean ButtonPressed) {                                                 
        PlayerAnswer = 3;
        ButtonPressed = true;
    }  
    
    private void jButton1ActionPerformed(java.awt.event.ActionEvent evt) {                                         
                RoundsPickedByPlayers = 1;
        
        
        //getContentPane().remove(quickGRoundSelectPanel);
       // getContentPane().add(quickGamePanel);
       quickGRoundSelectPanel.setVisible(false);
       mainFrame.remove(quickGRoundSelectPanel);
       //getContentPane().add(quickGamePanel);
       mainFrame.add(quickGamePanel);
        quickGamePanel.setVisible(true);
        //changePanels(quickGamePanel); 
        //getContentPane().removeAll();
        //quickGamePanel.setVisible(true);
        
    } 
}