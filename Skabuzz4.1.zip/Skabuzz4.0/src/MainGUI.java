
public class MainGUI {
	
	public MainGUI() {
		
	//	ArcadeGame arcadeGame = new ArcadeGame();
		QuickGame quickGame = new QuickGame();
	//	arcadeGame.run();
		quickGame.run();
 
		
	}
}
