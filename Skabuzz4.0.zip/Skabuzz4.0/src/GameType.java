import java.util.ArrayList;

public abstract class GameType {

	protected Players[] AllPlayers = new Players[4];
	protected ArrayList<Players> PlayersList = new ArrayList<Players>();
	        
        public Players pickAWinner(ArrayList<Players> AllPlayers) {
		Players winner = new Players(" ");
		for(Players currentPlayer : AllPlayers) {
			if(currentPlayer.getPoints() >= winner.getPoints()) {
				winner = currentPlayer;
			}
		}
		return winner;
	}
	
	public abstract void run();
}
