import java.util.ArrayList;

public class ArcadeGame extends GameType{

	private Modes ModesBoard[] = new Modes[4];
	
	public ArcadeGame() {
		
		String Player1Name = "Player1";
		String Player2Name = "Player2";
		String Player3Name = "Player3";
		String Player4Name = "Player4";
		
		AllPlayers[0] = new Players(Player1Name);
		AllPlayers[1] = new Players(Player2Name);
		AllPlayers[2] = new Players(Player3Name);
		AllPlayers[3] = new Players(Player4Name);
		
		for(int i=0;i<4;i++) {
			PlayersList.add( AllPlayers[i] );
		}
		
		DataBase questions = new DataBase();
		
		ClassicMode classicMode = new ClassicMode(questions , questions.CategoryNames[0],questions.CategoryPos[0], AllPlayers);
		SurvivalMode survivalMode = new SurvivalMode(questions , questions.CategoryNames[0],questions.CategoryPos[0], AllPlayers);	
		BombMode bombMode = new BombMode(questions , questions.CategoryNames[0],questions.CategoryPos[0], AllPlayers);
		OneMinuteMode oneMinuteMode = new OneMinuteMode(questions , questions.CategoryNames[0],questions.CategoryPos[0], AllPlayers);

		
		ModesBoard[0] = classicMode;
		ModesBoard[1] = survivalMode;
		ModesBoard[2] = bombMode;
		ModesBoard[3] = oneMinuteMode;
		
	}
	
	public void run() {
		ModesBoard[0].run();
		
		ModesBoard[1].run();
		ModesBoard[2].run();
		ModesBoard[3].run();
	}
	

}
