package seproj;


public class GUI extends javax.swing.JFrame {


    public GUI() {
        initComponents();
        getContentPane().removeAll();
        getContentPane().add(openPanel);
    }

    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        openPanel = new javax.swing.JPanel();
        openPanel1 = new javax.swing.JPanel();
        openPanelTitleLabel = new javax.swing.JLabel();
        openPanelStartBtn = new javax.swing.JButton();
        openPanelIconLabel = new javax.swing.JLabel();
        mainMenuPanel = new javax.swing.JPanel();
        mainMenuLabelPanel = new javax.swing.JPanel();
        mainMenuPanel2 = new javax.swing.JPanel();
        mainMenuTitleLabel = new javax.swing.JLabel();
        mainMenuBtnPanel = new javax.swing.JPanel();
        quickGameBtn = new javax.swing.JButton();
        arcadeGameBtn = new javax.swing.JButton();
        playerNamePanel = new javax.swing.JPanel();
        playerNameGeneralPanel = new javax.swing.JPanel();
        playerNameTitlePanel = new javax.swing.JPanel();
        playerNameTitleLabel = new javax.swing.JLabel();
        playerNameInfoPanel1 = new javax.swing.JPanel();
        playerNamePlayer1Label = new javax.swing.JLabel();
        playerNamePlayer1Field = new javax.swing.JTextField();
        playerNameInfoPanel2 = new javax.swing.JPanel();
        playerNamePlayer2Label = new javax.swing.JLabel();
        playerNamePlayer2Field = new javax.swing.JTextField();
        playerNameInfoPanel3 = new javax.swing.JPanel();
        playerNamePlayer3Label = new javax.swing.JLabel();
        playerNamePlayer3Field = new javax.swing.JTextField();
        playerNameInfoPanel4 = new javax.swing.JPanel();
        playerNamePlayer4Label = new javax.swing.JLabel();
        playerNamePlayer4Field = new javax.swing.JTextField();
        playerNameBeginBtn = new javax.swing.JButton();
        playerNameBackBtn = new javax.swing.JButton();
        classicModePanel = new javax.swing.JPanel();
        classicModeGeneralPanel = new javax.swing.JPanel();
        classicModeTitlePanel = new javax.swing.JPanel();
        classicModeTitleLabel1 = new javax.swing.JLabel();
        classicModeTitleLabel2 = new javax.swing.JLabel();
        classicModeQuestionPanel = new javax.swing.JPanel();
        classicModeQuestionScrollPane = new javax.swing.JScrollPane();
        classicModeQuestionTextArea = new javax.swing.JTextArea();
        classicModeQuestionLabel = new javax.swing.JLabel();
        classicModePlayerLabel = new javax.swing.JLabel();
        classicModeAnswerPanel = new javax.swing.JPanel();
        classicModeAnswerLabel = new javax.swing.JLabel();
        classicModeAnswer1 = new javax.swing.JButton();
        classicModeAnswer2 = new javax.swing.JButton();
        classicModeAnswer3 = new javax.swing.JButton();
        classicModeAnswer4 = new javax.swing.JButton();
        timeattackModePanel = new javax.swing.JPanel();
        timeattackModeGeneralPanel = new javax.swing.JPanel();
        timeattackModeGeneralPanel2 = new javax.swing.JPanel();
        timeattackModeTitlePanel = new javax.swing.JPanel();
        timeattackModeTitleLabel1 = new javax.swing.JLabel();
        timeattackModeTitleLabel2 = new javax.swing.JLabel();
        timeattackModeQuestionPanel = new javax.swing.JPanel();
        timeattackModeQuestionScrollPane = new javax.swing.JScrollPane();
        timeattackQuestionTextArea = new javax.swing.JTextArea();
        timeattackModeQuestionLabel = new javax.swing.JLabel();
        timeattackModePlayerLabel = new javax.swing.JLabel();
        timeattackModeAnswerPanel = new javax.swing.JPanel();
        timeattackModeAnswerLabel = new javax.swing.JLabel();
        timeattackModeAnswer1 = new javax.swing.JButton();
        timeattackModeAnswer2 = new javax.swing.JButton();
        timeattackModeAnswer3 = new javax.swing.JButton();
        timeattackModeAnswer4 = new javax.swing.JButton();
        timeattackModeInfoPanel = new javax.swing.JPanel();
        timeattackModeQInfoLabel = new javax.swing.JLabel();
        timeattackModeNoOfQuestLabel = new javax.swing.JLabel();
        timeattackModeTimeInfoLabel = new javax.swing.JLabel();
        timeattackModeTimeLabel = new javax.swing.JLabel();
        elevatorModePanel = new javax.swing.JPanel();
        elevatorModeGeneralPanel1 = new javax.swing.JPanel();
        elevatorModeGeneralPanel2 = new javax.swing.JPanel();
        elevatorModeGeneralPanel3 = new javax.swing.JPanel();
        elevatorModeTitlePanel = new javax.swing.JPanel();
        elevatorModeTitleLabel1 = new javax.swing.JLabel();
        elevatorModeTitleLabel2 = new javax.swing.JLabel();
        elevatorModeQuestionPanel = new javax.swing.JPanel();
        elevatorModeQuestionScrollPane = new javax.swing.JScrollPane();
        elevatorModeQuestionTextArea = new javax.swing.JTextArea();
        elevatorModeQuestionLabel = new javax.swing.JLabel();
        elevatorModePlayerLabel = new javax.swing.JLabel();
        elevatorModeAnswerPanel = new javax.swing.JPanel();
        elevatorModeAnswerLabel = new javax.swing.JLabel();
        elevatorModeAnswer1 = new javax.swing.JButton();
        elevatorModeAnswer2 = new javax.swing.JButton();
        elevatorModeAnswer3 = new javax.swing.JButton();
        elevatorModeAnswer4 = new javax.swing.JButton();
        elevatorModeInfoPanel = new javax.swing.JPanel();
        elevatorModeQInfoLabel = new javax.swing.JLabel();
        elevatorModeNoOfQuestLabel = new javax.swing.JLabel();
        elevatorModeCountInfoLabel = new javax.swing.JLabel();
        elevatorModeCountLabel = new javax.swing.JLabel();
        oneminquestModePanel = new javax.swing.JPanel();
        oneminquestModeGeneralPanel = new javax.swing.JPanel();
        oneminquestModeTitlePanel = new javax.swing.JPanel();
        oneminquestModeTitleLabel1 = new javax.swing.JLabel();
        oneminquestModeTitleLabel2 = new javax.swing.JLabel();
        oneminquestModeQuestionPanel = new javax.swing.JPanel();
        oneminquestModeQuestionScrollPane = new javax.swing.JScrollPane();
        oneminquestModeQuestionTextArea = new javax.swing.JTextArea();
        oneminquestModeQuestionLabel = new javax.swing.JLabel();
        oneminquestModePlayerLabel = new javax.swing.JLabel();
        oneminquestModeAnswerPanel = new javax.swing.JPanel();
        oneminquestModeAnswerLabel = new javax.swing.JLabel();
        oneminquestModeAnswer1 = new javax.swing.JButton();
        oneminquestModeAnswer2 = new javax.swing.JButton();
        oneminquestModeAnswer3 = new javax.swing.JButton();
        oneminquestModeAnswer4 = new javax.swing.JButton();
        oneminquestModeInfoPanel = new javax.swing.JPanel();
        oneminquestModeAInfoLabel = new javax.swing.JLabel();
        oneminquestModeNoOfAnsLabel = new javax.swing.JLabel();
        oneminquestModeTimeInfoLabel = new javax.swing.JLabel();
        oneminquestModeTimeLabel = new javax.swing.JLabel();
        bombModePanel = new javax.swing.JPanel();
        bombModeGeneralPanel = new javax.swing.JPanel();
        bombModeGeneralPanel2 = new javax.swing.JPanel();
        bombModeTitlePanel = new javax.swing.JPanel();
        bombModeTitleLabel1 = new javax.swing.JLabel();
        bombModeTitleLabel2 = new javax.swing.JLabel();
        bombModeQuestionPanel = new javax.swing.JPanel();
        bombModeQuestionScrollPane = new javax.swing.JScrollPane();
        bombModeQuestionTextArea = new javax.swing.JTextArea();
        bombModeQuestionLabel1 = new javax.swing.JLabel();
        bombModePlayerLabel2 = new javax.swing.JLabel();
        bombModeAnswerPanel = new javax.swing.JPanel();
        bombModeAnswerLabel = new javax.swing.JLabel();
        bombModeAnswer1 = new javax.swing.JButton();
        bombModeAnswer2 = new javax.swing.JButton();
        bombModeAnswer3 = new javax.swing.JButton();
        bombModeAnswer4 = new javax.swing.JButton();
        bombModeInfoPanel = new javax.swing.JPanel();
        bombModeAInfoLabel = new javax.swing.JLabel();
        bombModeNoOfAnsLabel = new javax.swing.JLabel();
        survivalModePanel = new javax.swing.JPanel();
        survivalModeGeneralPanel = new javax.swing.JPanel();
        survivalModeTitlePanel = new javax.swing.JPanel();
        survivalModeTitleLabel1 = new javax.swing.JLabel();
        survivalModeTitleLabel2 = new javax.swing.JLabel();
        survivalModeQuestionPanel = new javax.swing.JPanel();
        survivalModeQuestionScrollPane = new javax.swing.JScrollPane();
        survivalModeQuestionTextArea = new javax.swing.JTextArea();
        survivalModeQuestionLabel1 = new javax.swing.JLabel();
        survivalModePlayerLabel = new javax.swing.JLabel();
        survivalModeAnswerPanel = new javax.swing.JPanel();
        survivalModeAnswerLabel = new javax.swing.JLabel();
        survivalModeAnswer1 = new javax.swing.JButton();
        survivalModeAnswer2 = new javax.swing.JButton();
        survivalModeAnswer3 = new javax.swing.JButton();
        survivalModeAnswer4 = new javax.swing.JButton();
        survivalModeInfoPanel = new javax.swing.JPanel();
        survivalModeQInfoLabel = new javax.swing.JLabel();
        survivalModeNoOfQuestLabel = new javax.swing.JLabel();
        survivalModeLifeInfoLabel = new javax.swing.JLabel();
        survivalModeLifeLabel = new javax.swing.JLabel();
        ftfModePanel = new javax.swing.JPanel();
        ftfModeGeneralPanel = new javax.swing.JPanel();
        ftfModeTitlePanel = new javax.swing.JPanel();
        ftfModeTitleLabel1 = new javax.swing.JLabel();
        ftfModeTitleLabel2 = new javax.swing.JLabel();
        ftfModeQuestionPanel = new javax.swing.JPanel();
        ftfModeQuestionScrollPane = new javax.swing.JScrollPane();
        ftfModeQuestionTextArea = new javax.swing.JTextArea();
        ftfModeQuestionLabel = new javax.swing.JLabel();
        ftfModePlayerLabel = new javax.swing.JLabel();
        ftfModeAnswerPanel = new javax.swing.JPanel();
        ftfModeAnswerLabel = new javax.swing.JLabel();
        ftfModeAnswer1 = new javax.swing.JButton();
        ftfModeAnswer2 = new javax.swing.JButton();
        ftfModeAnswer3 = new javax.swing.JButton();
        ftfModeAnswer4 = new javax.swing.JButton();
        ftfModeInfoPanel = new javax.swing.JPanel();
        ftfModeAInfoLabel = new javax.swing.JLabel();
        ftfModeNoOfAnsLabel = new javax.swing.JLabel();
        gamblingModePanel = new javax.swing.JPanel();
        quickGamePanel = new javax.swing.JPanel();
        quickGameGeneralPanel = new javax.swing.JPanel();
        quickGameTitlePanel = new javax.swing.JPanel();
        quickGameTitleLabel1 = new javax.swing.JLabel();
        quickGameTitleLabel2 = new javax.swing.JLabel();
        quickGameQuestionPanel = new javax.swing.JPanel();
        quickGameQuestionScrollPane = new javax.swing.JScrollPane();
        quickGameQuestionTextArea = new javax.swing.JTextArea();
        quickGameQuestionLabel = new javax.swing.JLabel();
        quickGamePlayerLabel = new javax.swing.JLabel();
        quickGameAnswerPanel = new javax.swing.JPanel();
        quickGameAnswerLabel = new javax.swing.JLabel();
        quickGameAnswer1 = new javax.swing.JButton();
        quickGameAnswer2 = new javax.swing.JButton();
        quickGameAnswer3 = new javax.swing.JButton();
        quickGameAnswer4 = new javax.swing.JButton();
        quickGRoundSelectPanel = new javax.swing.JPanel();
        quickGRoundSelectGeneralPanel = new javax.swing.JPanel();
        quickGRoundSelectTitlePanel = new javax.swing.JPanel();
        quickGRoundSelectTitleLabel = new javax.swing.JLabel();
        quickGRoundSelectCheckPanel = new javax.swing.JPanel();
        quickGRoundSelectNoOfRLabel = new javax.swing.JLabel();
        quickGRoundSelectRadioBtn1 = new javax.swing.JRadioButton();
        quickGRoundSelectRadioBtn2 = new javax.swing.JRadioButton();
        quickGRoundSelectRadioBtn3 = new javax.swing.JRadioButton();
        quickGRoundSelectRadioBtn4 = new javax.swing.JRadioButton();
        quickGRoundSelectRadioBtn5 = new javax.swing.JRadioButton();
        modeCatSelPanel = new javax.swing.JPanel();
        modeCatSelGeneralPanel = new javax.swing.JPanel();
        modeCatSelTitlePanel = new javax.swing.JPanel();
        modeCatSelTitleLabel = new javax.swing.JLabel();
        modeCatSelMCPanel = new javax.swing.JPanel();
        modeCatSelModePanel = new javax.swing.JPanel();
        modeCatSelModeLabel = new javax.swing.JLabel();
        modeCatSelModeBtn1 = new javax.swing.JRadioButton();
        modeCatSelModeBtn2 = new javax.swing.JRadioButton();
        modeCatSelModeBtn3 = new javax.swing.JRadioButton();
        modeCatSelModeBtn4 = new javax.swing.JRadioButton();
        modeCatSelModeBtn5 = new javax.swing.JRadioButton();
        modeCatSelModeBtn6 = new javax.swing.JRadioButton();
        modeCatSelCatPanel = new javax.swing.JPanel();
        modeCatSelCatLabel = new javax.swing.JLabel();
        modeCatSelCatBtn1 = new javax.swing.JRadioButton();
        modeCatSelCatBtn2 = new javax.swing.JRadioButton();
        modeCatSelCatBtn3 = new javax.swing.JRadioButton();
        modeCatSelCatBtn4 = new javax.swing.JRadioButton();
        modeCatSelCatBtn5 = new javax.swing.JRadioButton();
        modeCatSelCatBtn6 = new javax.swing.JRadioButton();
        modeCatSelCatBtn7 = new javax.swing.JRadioButton();
        modeCatSelCatBtn8 = new javax.swing.JRadioButton();
        modeCatSelNextBtn = new javax.swing.JButton();
        scoreTablePanel = new javax.swing.JPanel();
        scoreTableGeneralPanel = new javax.swing.JPanel();
        scoreTableTitlePanel = new javax.swing.JPanel();
        scoreTableTitleLabel = new javax.swing.JLabel();
        scoreTableInfoPanel = new javax.swing.JPanel();
        scoreTableP1Panel = new javax.swing.JPanel();
        scoreTableP1NameLabel = new javax.swing.JLabel();
        scoreTableP1PointsLabel = new javax.swing.JLabel();
        scoreTableP2Panel = new javax.swing.JPanel();
        scoreTableP2NameLabel = new javax.swing.JLabel();
        scoreTableP2PointsLabel = new javax.swing.JLabel();
        scoreTableP3Panel = new javax.swing.JPanel();
        scoreTableP3NameLabel = new javax.swing.JLabel();
        scoreTableP3PointsLabel = new javax.swing.JLabel();
        scoreTableP4Panel = new javax.swing.JPanel();
        scoreTableP4NameLabel = new javax.swing.JLabel();
        scoreTableP4PointsLabel = new javax.swing.JLabel();
        scoreTableNextBtn = new javax.swing.JButton();
        finalQPanel = new javax.swing.JPanel();
        finalQGeneralPanel = new javax.swing.JPanel();
        finalQTitlePanel = new javax.swing.JPanel();
        finalQTitleLabel = new javax.swing.JLabel();
        finalQQuestionPanel = new javax.swing.JPanel();
        finalQQuestionScrollPane = new javax.swing.JScrollPane();
        finalQQuestionTextArea = new javax.swing.JTextArea();
        finalQQuestionLabel = new javax.swing.JLabel();
        finalQPlayerLabel = new javax.swing.JLabel();
        finalQAnswerPanel = new javax.swing.JPanel();
        finalQAnswerLabel = new javax.swing.JLabel();
        finalQAnswer1 = new javax.swing.JButton();
        finalQAnswer2 = new javax.swing.JButton();
        finalQAnswer3 = new javax.swing.JButton();
        finalQAnswer4 = new javax.swing.JButton();
        winnerPanel = new javax.swing.JPanel();
        winnerGeneralPanel = new javax.swing.JPanel();
        winnerTitlePanel = new javax.swing.JPanel();
        winnerTitleLabel = new javax.swing.JLabel();
        winnerInfoPanel = new javax.swing.JPanel();
        winnerP1Panel = new javax.swing.JPanel();
        winnerP1NameLabel = new javax.swing.JLabel();
        winnerP1PointsLabel = new javax.swing.JLabel();
        winnerP2Panel = new javax.swing.JPanel();
        winnerP2NameLabel = new javax.swing.JLabel();
        winnerP2PointsLabel = new javax.swing.JLabel();
        winnerP3Panel = new javax.swing.JPanel();
        winnerP3NameLabel = new javax.swing.JLabel();
        winnerP3PointsLabel = new javax.swing.JLabel();
        winnerP4Panel = new javax.swing.JPanel();
        winnerP4NameLabel = new javax.swing.JLabel();
        winnerP4PointsLabel = new javax.swing.JLabel();
        winnerMMenutBtn = new javax.swing.JButton();
        winnerLabel = new javax.swing.JLabel();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        setTitle("ΣΚΑ-BUZZ ΤΙΠΟΤΑ?");
        setMaximumSize(new java.awt.Dimension(500, 500));

        openPanelTitleLabel.setFont(new java.awt.Font("Arial Black", 0, 48)); // NOI18N
        openPanelTitleLabel.setText("ΣΚΑ-BUZZ ΤΙΠΟΤΑ?");

        openPanelStartBtn.setFont(new java.awt.Font("Arial", 0, 24)); // NOI18N
        openPanelStartBtn.setText("ΕΝΑΡΞΗ");
        openPanelStartBtn.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                openPanelStartBtnActionPerformed(evt);
            }
        });

        openPanelIconLabel.setIcon(new javax.swing.ImageIcon(getClass().getResource("/seproj/f0cc2c50d18cc31ad9d4dee546f4abdec53f4c520d0e7da59b9a34c61eff.png"))); // NOI18N

        javax.swing.GroupLayout openPanel1Layout = new javax.swing.GroupLayout(openPanel1);
        openPanel1.setLayout(openPanel1Layout);
        openPanel1Layout.setHorizontalGroup(
            openPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(openPanel1Layout.createSequentialGroup()
                .addGap(150, 150, 150)
                .addComponent(openPanelTitleLabel)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, openPanel1Layout.createSequentialGroup()
                .addContainerGap(50, Short.MAX_VALUE)
                .addGroup(openPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, openPanel1Layout.createSequentialGroup()
                        .addComponent(openPanelIconLabel, javax.swing.GroupLayout.PREFERRED_SIZE, 746, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(39, 39, 39))
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, openPanel1Layout.createSequentialGroup()
                        .addComponent(openPanelStartBtn, javax.swing.GroupLayout.PREFERRED_SIZE, 275, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(279, 279, 279))))
        );
        openPanel1Layout.setVerticalGroup(
            openPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(openPanel1Layout.createSequentialGroup()
                .addGap(62, 62, 62)
                .addComponent(openPanelTitleLabel, javax.swing.GroupLayout.PREFERRED_SIZE, 46, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18)
                .addComponent(openPanelIconLabel, javax.swing.GroupLayout.PREFERRED_SIZE, 376, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(28, 28, 28)
                .addComponent(openPanelStartBtn, javax.swing.GroupLayout.PREFERRED_SIZE, 95, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(97, Short.MAX_VALUE))
        );

        javax.swing.GroupLayout openPanelLayout = new javax.swing.GroupLayout(openPanel);
        openPanel.setLayout(openPanelLayout);
        openPanelLayout.setHorizontalGroup(
            openPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, openPanelLayout.createSequentialGroup()
                .addContainerGap(208, Short.MAX_VALUE)
                .addComponent(openPanel1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(178, 178, 178))
        );
        openPanelLayout.setVerticalGroup(
            openPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(openPanelLayout.createSequentialGroup()
                .addGap(28, 28, 28)
                .addComponent(openPanel1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(49, Short.MAX_VALUE))
        );

        mainMenuPanel.setPreferredSize(new java.awt.Dimension(1201, 777));

        mainMenuTitleLabel.setFont(new java.awt.Font("Arial Black", 0, 48)); // NOI18N
        mainMenuTitleLabel.setText("ΕΠΙΛΕΞΤΕ MODE");

        javax.swing.GroupLayout mainMenuPanel2Layout = new javax.swing.GroupLayout(mainMenuPanel2);
        mainMenuPanel2.setLayout(mainMenuPanel2Layout);
        mainMenuPanel2Layout.setHorizontalGroup(
            mainMenuPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(mainMenuPanel2Layout.createSequentialGroup()
                .addGap(28, 28, 28)
                .addComponent(mainMenuTitleLabel)
                .addContainerGap(28, Short.MAX_VALUE))
        );
        mainMenuPanel2Layout.setVerticalGroup(
            mainMenuPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(mainMenuPanel2Layout.createSequentialGroup()
                .addGap(32, 32, 32)
                .addComponent(mainMenuTitleLabel, javax.swing.GroupLayout.PREFERRED_SIZE, 37, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(31, Short.MAX_VALUE))
        );

        quickGameBtn.setFont(new java.awt.Font("Arial", 0, 24)); // NOI18N
        quickGameBtn.setText("QUICK MODE");
        quickGameBtn.setPreferredSize(new java.awt.Dimension(70, 20));
        quickGameBtn.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                quickGameBtnActionPerformed(evt);
            }
        });

        arcadeGameBtn.setFont(new java.awt.Font("Arial", 0, 24)); // NOI18N
        arcadeGameBtn.setText("ARCADE MODE");
        arcadeGameBtn.setPreferredSize(new java.awt.Dimension(70, 20));
        arcadeGameBtn.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                arcadeGameBtnActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout mainMenuBtnPanelLayout = new javax.swing.GroupLayout(mainMenuBtnPanel);
        mainMenuBtnPanel.setLayout(mainMenuBtnPanelLayout);
        mainMenuBtnPanelLayout.setHorizontalGroup(
            mainMenuBtnPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(mainMenuBtnPanelLayout.createSequentialGroup()
                .addGap(152, 152, 152)
                .addGroup(mainMenuBtnPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                    .addComponent(quickGameBtn, javax.swing.GroupLayout.DEFAULT_SIZE, 218, Short.MAX_VALUE)
                    .addComponent(arcadeGameBtn, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                .addContainerGap(156, Short.MAX_VALUE))
        );
        mainMenuBtnPanelLayout.setVerticalGroup(
            mainMenuBtnPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(mainMenuBtnPanelLayout.createSequentialGroup()
                .addGap(32, 32, 32)
                .addComponent(quickGameBtn, javax.swing.GroupLayout.PREFERRED_SIZE, 70, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(62, 62, 62)
                .addComponent(arcadeGameBtn, javax.swing.GroupLayout.PREFERRED_SIZE, 70, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(46, Short.MAX_VALUE))
        );

        javax.swing.GroupLayout mainMenuLabelPanelLayout = new javax.swing.GroupLayout(mainMenuLabelPanel);
        mainMenuLabelPanel.setLayout(mainMenuLabelPanelLayout);
        mainMenuLabelPanelLayout.setHorizontalGroup(
            mainMenuLabelPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(mainMenuLabelPanelLayout.createSequentialGroup()
                .addGap(272, 272, 272)
                .addGroup(mainMenuLabelPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(mainMenuBtnPanel, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(mainMenuPanel2, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addContainerGap(248, Short.MAX_VALUE))
        );
        mainMenuLabelPanelLayout.setVerticalGroup(
            mainMenuLabelPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(mainMenuLabelPanelLayout.createSequentialGroup()
                .addGap(56, 56, 56)
                .addComponent(mainMenuPanel2, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(125, 125, 125)
                .addComponent(mainMenuBtnPanel, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(144, Short.MAX_VALUE))
        );

        javax.swing.GroupLayout mainMenuPanelLayout = new javax.swing.GroupLayout(mainMenuPanel);
        mainMenuPanel.setLayout(mainMenuPanelLayout);
        mainMenuPanelLayout.setHorizontalGroup(
            mainMenuPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, mainMenuPanelLayout.createSequentialGroup()
                .addContainerGap(87, Short.MAX_VALUE)
                .addComponent(mainMenuLabelPanel, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(68, 68, 68))
        );
        mainMenuPanelLayout.setVerticalGroup(
            mainMenuPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(mainMenuPanelLayout.createSequentialGroup()
                .addGap(31, 31, 31)
                .addComponent(mainMenuLabelPanel, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(41, Short.MAX_VALUE))
        );

        playerNamePanel.setPreferredSize(new java.awt.Dimension(1201, 777));

        playerNameTitleLabel.setFont(new java.awt.Font("Arial Black", 0, 36)); // NOI18N
        playerNameTitleLabel.setText("ΚΑΤΑΧΩΡΗΣΤΕ ΤΑ ΟΝΟΜΑΤΑ ΤΩΝ ΠΑΙΚΤΩΝ");

        javax.swing.GroupLayout playerNameTitlePanelLayout = new javax.swing.GroupLayout(playerNameTitlePanel);
        playerNameTitlePanel.setLayout(playerNameTitlePanelLayout);
        playerNameTitlePanelLayout.setHorizontalGroup(
            playerNameTitlePanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(playerNameTitlePanelLayout.createSequentialGroup()
                .addContainerGap()
                .addComponent(playerNameTitleLabel, javax.swing.GroupLayout.DEFAULT_SIZE, 888, Short.MAX_VALUE)
                .addContainerGap())
        );
        playerNameTitlePanelLayout.setVerticalGroup(
            playerNameTitlePanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, playerNameTitlePanelLayout.createSequentialGroup()
                .addContainerGap(28, Short.MAX_VALUE)
                .addComponent(playerNameTitleLabel, javax.swing.GroupLayout.PREFERRED_SIZE, 48, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(24, 24, 24))
        );

        playerNamePlayer1Label.setFont(new java.awt.Font("Arial", 0, 30)); // NOI18N
        playerNamePlayer1Label.setText("ΠΑΙΚΤΗΣ 1: ");

        playerNamePlayer1Field.setFont(new java.awt.Font("Arial", 0, 24)); // NOI18N

        javax.swing.GroupLayout playerNameInfoPanel1Layout = new javax.swing.GroupLayout(playerNameInfoPanel1);
        playerNameInfoPanel1.setLayout(playerNameInfoPanel1Layout);
        playerNameInfoPanel1Layout.setHorizontalGroup(
            playerNameInfoPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(playerNameInfoPanel1Layout.createSequentialGroup()
                .addGap(21, 21, 21)
                .addComponent(playerNamePlayer1Label, javax.swing.GroupLayout.PREFERRED_SIZE, 223, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(40, 40, 40)
                .addComponent(playerNamePlayer1Field, javax.swing.GroupLayout.PREFERRED_SIZE, 348, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(24, Short.MAX_VALUE))
        );
        playerNameInfoPanel1Layout.setVerticalGroup(
            playerNameInfoPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, playerNameInfoPanel1Layout.createSequentialGroup()
                .addContainerGap(22, Short.MAX_VALUE)
                .addGroup(playerNameInfoPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                    .addComponent(playerNamePlayer1Label, javax.swing.GroupLayout.DEFAULT_SIZE, 39, Short.MAX_VALUE)
                    .addComponent(playerNamePlayer1Field))
                .addGap(19, 19, 19))
        );

        playerNamePlayer2Label.setFont(new java.awt.Font("Arial", 0, 30)); // NOI18N
        playerNamePlayer2Label.setText("ΠΑΙΚΤΗΣ 2:");

        playerNamePlayer2Field.setFont(new java.awt.Font("Arial", 0, 24)); // NOI18N

        javax.swing.GroupLayout playerNameInfoPanel2Layout = new javax.swing.GroupLayout(playerNameInfoPanel2);
        playerNameInfoPanel2.setLayout(playerNameInfoPanel2Layout);
        playerNameInfoPanel2Layout.setHorizontalGroup(
            playerNameInfoPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(playerNameInfoPanel2Layout.createSequentialGroup()
                .addGap(21, 21, 21)
                .addComponent(playerNamePlayer2Label, javax.swing.GroupLayout.PREFERRED_SIZE, 170, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(playerNamePlayer2Field, javax.swing.GroupLayout.PREFERRED_SIZE, 348, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(25, 25, 25))
        );
        playerNameInfoPanel2Layout.setVerticalGroup(
            playerNameInfoPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, playerNameInfoPanel2Layout.createSequentialGroup()
                .addContainerGap(26, Short.MAX_VALUE)
                .addGroup(playerNameInfoPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(playerNamePlayer2Label, javax.swing.GroupLayout.PREFERRED_SIZE, 43, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(playerNamePlayer2Field))
                .addContainerGap())
        );

        playerNamePlayer3Label.setFont(new java.awt.Font("Arial", 0, 30)); // NOI18N
        playerNamePlayer3Label.setText("ΠΑΙΚΤΗΣ 3:");

        playerNamePlayer3Field.setFont(new java.awt.Font("Arial", 0, 24)); // NOI18N

        javax.swing.GroupLayout playerNameInfoPanel3Layout = new javax.swing.GroupLayout(playerNameInfoPanel3);
        playerNameInfoPanel3.setLayout(playerNameInfoPanel3Layout);
        playerNameInfoPanel3Layout.setHorizontalGroup(
            playerNameInfoPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(playerNameInfoPanel3Layout.createSequentialGroup()
                .addGap(21, 21, 21)
                .addComponent(playerNamePlayer3Label, javax.swing.GroupLayout.PREFERRED_SIZE, 170, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(playerNamePlayer3Field, javax.swing.GroupLayout.PREFERRED_SIZE, 348, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(24, 24, 24))
        );
        playerNameInfoPanel3Layout.setVerticalGroup(
            playerNameInfoPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, playerNameInfoPanel3Layout.createSequentialGroup()
                .addContainerGap(26, Short.MAX_VALUE)
                .addGroup(playerNameInfoPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(playerNamePlayer3Label, javax.swing.GroupLayout.PREFERRED_SIZE, 43, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(playerNamePlayer3Field))
                .addContainerGap())
        );

        playerNamePlayer4Label.setFont(new java.awt.Font("Arial", 0, 30)); // NOI18N
        playerNamePlayer4Label.setText("ΠΑΙΚΤΗΣ 4:");

        playerNamePlayer4Field.setFont(new java.awt.Font("Arial", 0, 24)); // NOI18N

        javax.swing.GroupLayout playerNameInfoPanel4Layout = new javax.swing.GroupLayout(playerNameInfoPanel4);
        playerNameInfoPanel4.setLayout(playerNameInfoPanel4Layout);
        playerNameInfoPanel4Layout.setHorizontalGroup(
            playerNameInfoPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(playerNameInfoPanel4Layout.createSequentialGroup()
                .addGap(21, 21, 21)
                .addComponent(playerNamePlayer4Label, javax.swing.GroupLayout.PREFERRED_SIZE, 170, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(playerNamePlayer4Field, javax.swing.GroupLayout.PREFERRED_SIZE, 348, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(22, 22, 22))
        );
        playerNameInfoPanel4Layout.setVerticalGroup(
            playerNameInfoPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, playerNameInfoPanel4Layout.createSequentialGroup()
                .addContainerGap(26, Short.MAX_VALUE)
                .addGroup(playerNameInfoPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(playerNamePlayer4Label, javax.swing.GroupLayout.PREFERRED_SIZE, 43, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(playerNamePlayer4Field))
                .addContainerGap())
        );

        playerNameBeginBtn.setFont(new java.awt.Font("Arial", 0, 24)); // NOI18N
        playerNameBeginBtn.setText("ΠΑΙΞΤΕ");

        playerNameBackBtn.setFont(new java.awt.Font("Arial", 0, 24)); // NOI18N
        playerNameBackBtn.setText("ΠΙΣΩ");
        playerNameBackBtn.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                playerNameBackBtnActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout playerNameGeneralPanelLayout = new javax.swing.GroupLayout(playerNameGeneralPanel);
        playerNameGeneralPanel.setLayout(playerNameGeneralPanelLayout);
        playerNameGeneralPanelLayout.setHorizontalGroup(
            playerNameGeneralPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(playerNameGeneralPanelLayout.createSequentialGroup()
                .addGap(243, 243, 243)
                .addGroup(playerNameGeneralPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                    .addComponent(playerNameInfoPanel4, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(playerNameInfoPanel1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(playerNameInfoPanel2, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(playerNameInfoPanel3, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, playerNameGeneralPanelLayout.createSequentialGroup()
                .addContainerGap(132, Short.MAX_VALUE)
                .addComponent(playerNameTitlePanel, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(131, 131, 131))
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, playerNameGeneralPanelLayout.createSequentialGroup()
                .addGap(24, 24, 24)
                .addComponent(playerNameBackBtn, javax.swing.GroupLayout.PREFERRED_SIZE, 197, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(playerNameBeginBtn, javax.swing.GroupLayout.PREFERRED_SIZE, 200, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(29, 29, 29))
        );
        playerNameGeneralPanelLayout.setVerticalGroup(
            playerNameGeneralPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(playerNameGeneralPanelLayout.createSequentialGroup()
                .addGap(29, 29, 29)
                .addComponent(playerNameTitlePanel, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18)
                .addComponent(playerNameInfoPanel1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(63, 63, 63)
                .addComponent(playerNameInfoPanel2, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(67, 67, 67)
                .addComponent(playerNameInfoPanel3, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(62, 62, 62)
                .addComponent(playerNameInfoPanel4, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(playerNameGeneralPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                    .addComponent(playerNameBackBtn, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(playerNameBeginBtn, javax.swing.GroupLayout.DEFAULT_SIZE, 91, Short.MAX_VALUE))
                .addContainerGap(23, Short.MAX_VALUE))
        );

        javax.swing.GroupLayout playerNamePanelLayout = new javax.swing.GroupLayout(playerNamePanel);
        playerNamePanel.setLayout(playerNamePanelLayout);
        playerNamePanelLayout.setHorizontalGroup(
            playerNamePanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(playerNamePanelLayout.createSequentialGroup()
                .addGap(20, 20, 20)
                .addComponent(playerNameGeneralPanel, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addContainerGap())
        );
        playerNamePanelLayout.setVerticalGroup(
            playerNamePanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(playerNamePanelLayout.createSequentialGroup()
                .addContainerGap()
                .addComponent(playerNameGeneralPanel, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );

        classicModePanel.setPreferredSize(new java.awt.Dimension(1201, 777));
        classicModePanel.setRequestFocusEnabled(false);

        classicModeTitleLabel1.setFont(new java.awt.Font("Arial Black", 0, 36)); // NOI18N
        classicModeTitleLabel1.setText("ΓΥΡΟΣ");

        classicModeTitleLabel2.setFont(new java.awt.Font("Arial Black", 0, 36)); // NOI18N

        javax.swing.GroupLayout classicModeTitlePanelLayout = new javax.swing.GroupLayout(classicModeTitlePanel);
        classicModeTitlePanel.setLayout(classicModeTitlePanelLayout);
        classicModeTitlePanelLayout.setHorizontalGroup(
            classicModeTitlePanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(classicModeTitlePanelLayout.createSequentialGroup()
                .addGap(216, 216, 216)
                .addComponent(classicModeTitleLabel1)
                .addGap(18, 18, 18)
                .addComponent(classicModeTitleLabel2, javax.swing.GroupLayout.PREFERRED_SIZE, 71, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(225, Short.MAX_VALUE))
        );
        classicModeTitlePanelLayout.setVerticalGroup(
            classicModeTitlePanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(classicModeTitlePanelLayout.createSequentialGroup()
                .addContainerGap()
                .addGroup(classicModeTitlePanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(classicModeTitleLabel2, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(classicModeTitleLabel1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                .addContainerGap())
        );

        classicModeQuestionScrollPane.setHorizontalScrollBarPolicy(javax.swing.ScrollPaneConstants.HORIZONTAL_SCROLLBAR_NEVER);
        classicModeQuestionScrollPane.setVerticalScrollBarPolicy(javax.swing.ScrollPaneConstants.VERTICAL_SCROLLBAR_NEVER);

        classicModeQuestionTextArea.setColumns(20);
        classicModeQuestionTextArea.setFont(new java.awt.Font("Arial", 2, 24)); // NOI18N
        classicModeQuestionTextArea.setLineWrap(true);
        classicModeQuestionTextArea.setRows(5);
        classicModeQuestionScrollPane.setViewportView(classicModeQuestionTextArea);

        classicModeQuestionLabel.setFont(new java.awt.Font("Arial", 0, 24)); // NOI18N
        classicModeQuestionLabel.setText("ΕΡΩΤΗΣΗ ΓΙΑ ΤΟΝ ΠΑΙΚΤΗ:");

        classicModePlayerLabel.setFont(new java.awt.Font("Arial", 2, 24)); // NOI18N

        javax.swing.GroupLayout classicModeQuestionPanelLayout = new javax.swing.GroupLayout(classicModeQuestionPanel);
        classicModeQuestionPanel.setLayout(classicModeQuestionPanelLayout);
        classicModeQuestionPanelLayout.setHorizontalGroup(
            classicModeQuestionPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(classicModeQuestionPanelLayout.createSequentialGroup()
                .addGap(20, 20, 20)
                .addGroup(classicModeQuestionPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(classicModeQuestionScrollPane)
                    .addGroup(classicModeQuestionPanelLayout.createSequentialGroup()
                        .addComponent(classicModeQuestionLabel)
                        .addGap(18, 18, 18)
                        .addComponent(classicModePlayerLabel, javax.swing.GroupLayout.PREFERRED_SIZE, 238, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(0, 377, Short.MAX_VALUE)))
                .addContainerGap())
        );
        classicModeQuestionPanelLayout.setVerticalGroup(
            classicModeQuestionPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, classicModeQuestionPanelLayout.createSequentialGroup()
                .addGroup(classicModeQuestionPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(classicModeQuestionLabel, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(classicModePlayerLabel, javax.swing.GroupLayout.PREFERRED_SIZE, 29, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(classicModeQuestionScrollPane, javax.swing.GroupLayout.PREFERRED_SIZE, 90, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap())
        );

        classicModeAnswerLabel.setFont(new java.awt.Font("Arial", 0, 24)); // NOI18N
        classicModeAnswerLabel.setText("ΑΠΑΝΤΗΣΕΙΣ:");

        classicModeAnswer1.setFont(new java.awt.Font("Arial", 0, 24)); // NOI18N

        classicModeAnswer2.setFont(new java.awt.Font("Arial", 0, 24)); // NOI18N

        classicModeAnswer3.setFont(new java.awt.Font("Arial", 0, 24)); // NOI18N

        classicModeAnswer4.setFont(new java.awt.Font("Arial", 0, 24)); // NOI18N

        javax.swing.GroupLayout classicModeAnswerPanelLayout = new javax.swing.GroupLayout(classicModeAnswerPanel);
        classicModeAnswerPanel.setLayout(classicModeAnswerPanelLayout);
        classicModeAnswerPanelLayout.setHorizontalGroup(
            classicModeAnswerPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(classicModeAnswerPanelLayout.createSequentialGroup()
                .addGroup(classicModeAnswerPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(classicModeAnswerLabel)
                    .addGroup(classicModeAnswerPanelLayout.createSequentialGroup()
                        .addContainerGap()
                        .addGroup(classicModeAnswerPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                            .addComponent(classicModeAnswer3, javax.swing.GroupLayout.DEFAULT_SIZE, 350, Short.MAX_VALUE)
                            .addComponent(classicModeAnswer1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 159, Short.MAX_VALUE)
                        .addGroup(classicModeAnswerPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                            .addComponent(classicModeAnswer2, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                            .addComponent(classicModeAnswer4, javax.swing.GroupLayout.DEFAULT_SIZE, 350, Short.MAX_VALUE))))
                .addGap(45, 45, 45))
        );
        classicModeAnswerPanelLayout.setVerticalGroup(
            classicModeAnswerPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(classicModeAnswerPanelLayout.createSequentialGroup()
                .addContainerGap()
                .addComponent(classicModeAnswerLabel, javax.swing.GroupLayout.PREFERRED_SIZE, 36, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(29, 29, 29)
                .addGroup(classicModeAnswerPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(classicModeAnswer1, javax.swing.GroupLayout.PREFERRED_SIZE, 80, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(classicModeAnswer2, javax.swing.GroupLayout.PREFERRED_SIZE, 80, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(64, 64, 64)
                .addGroup(classicModeAnswerPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(classicModeAnswer4, javax.swing.GroupLayout.PREFERRED_SIZE, 81, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(classicModeAnswer3, javax.swing.GroupLayout.PREFERRED_SIZE, 81, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(114, 114, 114))
        );

        javax.swing.GroupLayout classicModeGeneralPanelLayout = new javax.swing.GroupLayout(classicModeGeneralPanel);
        classicModeGeneralPanel.setLayout(classicModeGeneralPanelLayout);
        classicModeGeneralPanelLayout.setHorizontalGroup(
            classicModeGeneralPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(classicModeGeneralPanelLayout.createSequentialGroup()
                .addContainerGap(94, Short.MAX_VALUE)
                .addGroup(classicModeGeneralPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(classicModeGeneralPanelLayout.createSequentialGroup()
                        .addGap(126, 126, 126)
                        .addComponent(classicModeTitlePanel, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(classicModeGeneralPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                        .addComponent(classicModeAnswerPanel, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addComponent(classicModeQuestionPanel, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addContainerGap(102, Short.MAX_VALUE))
        );
        classicModeGeneralPanelLayout.setVerticalGroup(
            classicModeGeneralPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(classicModeGeneralPanelLayout.createSequentialGroup()
                .addGap(37, 37, 37)
                .addComponent(classicModeTitlePanel, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(79, 79, 79)
                .addComponent(classicModeQuestionPanel, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(classicModeAnswerPanel, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );

        javax.swing.GroupLayout classicModePanelLayout = new javax.swing.GroupLayout(classicModePanel);
        classicModePanel.setLayout(classicModePanelLayout);
        classicModePanelLayout.setHorizontalGroup(
            classicModePanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, classicModePanelLayout.createSequentialGroup()
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(classicModeGeneralPanel, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(33, 33, 33))
        );
        classicModePanelLayout.setVerticalGroup(
            classicModePanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(classicModePanelLayout.createSequentialGroup()
                .addContainerGap()
                .addComponent(classicModeGeneralPanel, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addContainerGap())
        );

        timeattackModePanel.setPreferredSize(new java.awt.Dimension(1201, 777));

        timeattackModeGeneralPanel.setPreferredSize(new java.awt.Dimension(1201, 777));

        timeattackModeTitleLabel1.setFont(new java.awt.Font("Arial Black", 0, 36)); // NOI18N
        timeattackModeTitleLabel1.setText("ΓΥΡΟΣ");

        timeattackModeTitleLabel2.setFont(new java.awt.Font("Arial Black", 0, 36)); // NOI18N

        javax.swing.GroupLayout timeattackModeTitlePanelLayout = new javax.swing.GroupLayout(timeattackModeTitlePanel);
        timeattackModeTitlePanel.setLayout(timeattackModeTitlePanelLayout);
        timeattackModeTitlePanelLayout.setHorizontalGroup(
            timeattackModeTitlePanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(timeattackModeTitlePanelLayout.createSequentialGroup()
                .addGap(216, 216, 216)
                .addComponent(timeattackModeTitleLabel1)
                .addGap(18, 18, 18)
                .addComponent(timeattackModeTitleLabel2, javax.swing.GroupLayout.PREFERRED_SIZE, 71, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(225, Short.MAX_VALUE))
        );
        timeattackModeTitlePanelLayout.setVerticalGroup(
            timeattackModeTitlePanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(timeattackModeTitlePanelLayout.createSequentialGroup()
                .addContainerGap()
                .addGroup(timeattackModeTitlePanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(timeattackModeTitleLabel2, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(timeattackModeTitleLabel1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                .addContainerGap())
        );

        timeattackModeQuestionScrollPane.setHorizontalScrollBarPolicy(javax.swing.ScrollPaneConstants.HORIZONTAL_SCROLLBAR_NEVER);
        timeattackModeQuestionScrollPane.setVerticalScrollBarPolicy(javax.swing.ScrollPaneConstants.VERTICAL_SCROLLBAR_NEVER);

        timeattackQuestionTextArea.setColumns(20);
        timeattackQuestionTextArea.setFont(new java.awt.Font("Arial", 2, 24)); // NOI18N
        timeattackQuestionTextArea.setLineWrap(true);
        timeattackQuestionTextArea.setRows(5);
        timeattackModeQuestionScrollPane.setViewportView(timeattackQuestionTextArea);

        timeattackModeQuestionLabel.setFont(new java.awt.Font("Arial", 0, 24)); // NOI18N
        timeattackModeQuestionLabel.setText("ΕΡΩΤΗΣΗ ΓΙΑ ΤΟΝ ΠΑΙΚΤΗ:");

        timeattackModePlayerLabel.setFont(new java.awt.Font("Arial", 2, 24)); // NOI18N

        javax.swing.GroupLayout timeattackModeQuestionPanelLayout = new javax.swing.GroupLayout(timeattackModeQuestionPanel);
        timeattackModeQuestionPanel.setLayout(timeattackModeQuestionPanelLayout);
        timeattackModeQuestionPanelLayout.setHorizontalGroup(
            timeattackModeQuestionPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(timeattackModeQuestionPanelLayout.createSequentialGroup()
                .addGap(20, 20, 20)
                .addGroup(timeattackModeQuestionPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(timeattackModeQuestionScrollPane)
                    .addGroup(timeattackModeQuestionPanelLayout.createSequentialGroup()
                        .addComponent(timeattackModeQuestionLabel)
                        .addGap(18, 18, 18)
                        .addComponent(timeattackModePlayerLabel, javax.swing.GroupLayout.PREFERRED_SIZE, 238, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(0, 419, Short.MAX_VALUE)))
                .addContainerGap())
        );
        timeattackModeQuestionPanelLayout.setVerticalGroup(
            timeattackModeQuestionPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, timeattackModeQuestionPanelLayout.createSequentialGroup()
                .addGroup(timeattackModeQuestionPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(timeattackModeQuestionLabel, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(timeattackModePlayerLabel, javax.swing.GroupLayout.PREFERRED_SIZE, 29, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(timeattackModeQuestionScrollPane, javax.swing.GroupLayout.PREFERRED_SIZE, 90, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(20, 20, 20))
        );

        timeattackModeAnswerLabel.setFont(new java.awt.Font("Arial", 0, 24)); // NOI18N
        timeattackModeAnswerLabel.setText("ΑΠΑΝΤΗΣΕΙΣ:");

        timeattackModeAnswer1.setFont(new java.awt.Font("Arial", 0, 24)); // NOI18N

        timeattackModeAnswer2.setFont(new java.awt.Font("Arial", 0, 24)); // NOI18N

        timeattackModeAnswer3.setFont(new java.awt.Font("Arial", 0, 24)); // NOI18N

        timeattackModeAnswer4.setFont(new java.awt.Font("Arial", 0, 24)); // NOI18N

        javax.swing.GroupLayout timeattackModeAnswerPanelLayout = new javax.swing.GroupLayout(timeattackModeAnswerPanel);
        timeattackModeAnswerPanel.setLayout(timeattackModeAnswerPanelLayout);
        timeattackModeAnswerPanelLayout.setHorizontalGroup(
            timeattackModeAnswerPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(timeattackModeAnswerPanelLayout.createSequentialGroup()
                .addGroup(timeattackModeAnswerPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(timeattackModeAnswerLabel)
                    .addGroup(timeattackModeAnswerPanelLayout.createSequentialGroup()
                        .addContainerGap()
                        .addGroup(timeattackModeAnswerPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                            .addComponent(timeattackModeAnswer3, javax.swing.GroupLayout.DEFAULT_SIZE, 350, Short.MAX_VALUE)
                            .addComponent(timeattackModeAnswer1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 159, Short.MAX_VALUE)
                        .addGroup(timeattackModeAnswerPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                            .addComponent(timeattackModeAnswer2, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                            .addComponent(timeattackModeAnswer4, javax.swing.GroupLayout.DEFAULT_SIZE, 350, Short.MAX_VALUE))))
                .addGap(45, 45, 45))
        );
        timeattackModeAnswerPanelLayout.setVerticalGroup(
            timeattackModeAnswerPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(timeattackModeAnswerPanelLayout.createSequentialGroup()
                .addContainerGap()
                .addComponent(timeattackModeAnswerLabel, javax.swing.GroupLayout.PREFERRED_SIZE, 36, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(29, 29, 29)
                .addGroup(timeattackModeAnswerPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(timeattackModeAnswer1, javax.swing.GroupLayout.PREFERRED_SIZE, 80, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(timeattackModeAnswer2, javax.swing.GroupLayout.PREFERRED_SIZE, 80, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(64, 64, 64)
                .addGroup(timeattackModeAnswerPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(timeattackModeAnswer4, javax.swing.GroupLayout.PREFERRED_SIZE, 81, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(timeattackModeAnswer3, javax.swing.GroupLayout.PREFERRED_SIZE, 81, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addContainerGap(90, Short.MAX_VALUE))
        );

        timeattackModeQInfoLabel.setFont(new java.awt.Font("Arial Narrow", 0, 30)); // NOI18N
        timeattackModeQInfoLabel.setText("ΕΡΩΤΗΣΕΙΣ ΠΟΥ ΑΠΟΜΕΝΟΥΝ:");
        timeattackModeQInfoLabel.setBorder(new javax.swing.border.SoftBevelBorder(javax.swing.border.BevelBorder.RAISED));

        timeattackModeNoOfQuestLabel.setFont(new java.awt.Font("Arial Narrow", 0, 30)); // NOI18N
        timeattackModeNoOfQuestLabel.setBorder(new javax.swing.border.SoftBevelBorder(javax.swing.border.BevelBorder.RAISED));

        timeattackModeTimeInfoLabel.setFont(new java.awt.Font("Arial Narrow", 0, 30)); // NOI18N
        timeattackModeTimeInfoLabel.setText("ΧΡΟΝΟΣ:");
        timeattackModeTimeInfoLabel.setBorder(new javax.swing.border.SoftBevelBorder(javax.swing.border.BevelBorder.RAISED));

        timeattackModeTimeLabel.setFont(new java.awt.Font("Arial Narrow", 0, 30)); // NOI18N
        timeattackModeTimeLabel.setBorder(new javax.swing.border.SoftBevelBorder(javax.swing.border.BevelBorder.RAISED));

        javax.swing.GroupLayout timeattackModeInfoPanelLayout = new javax.swing.GroupLayout(timeattackModeInfoPanel);
        timeattackModeInfoPanel.setLayout(timeattackModeInfoPanelLayout);
        timeattackModeInfoPanelLayout.setHorizontalGroup(
            timeattackModeInfoPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(timeattackModeInfoPanelLayout.createSequentialGroup()
                .addGap(71, 71, 71)
                .addComponent(timeattackModeQInfoLabel)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(timeattackModeNoOfQuestLabel, javax.swing.GroupLayout.PREFERRED_SIZE, 25, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(117, 117, 117)
                .addComponent(timeattackModeTimeInfoLabel)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(timeattackModeTimeLabel, javax.swing.GroupLayout.PREFERRED_SIZE, 32, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );
        timeattackModeInfoPanelLayout.setVerticalGroup(
            timeattackModeInfoPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, timeattackModeInfoPanelLayout.createSequentialGroup()
                .addContainerGap()
                .addGroup(timeattackModeInfoPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(timeattackModeQInfoLabel, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(timeattackModeTimeInfoLabel, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(timeattackModeTimeLabel, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(timeattackModeNoOfQuestLabel, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                .addContainerGap())
        );

        javax.swing.GroupLayout timeattackModeGeneralPanel2Layout = new javax.swing.GroupLayout(timeattackModeGeneralPanel2);
        timeattackModeGeneralPanel2.setLayout(timeattackModeGeneralPanel2Layout);
        timeattackModeGeneralPanel2Layout.setHorizontalGroup(
            timeattackModeGeneralPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(timeattackModeGeneralPanel2Layout.createSequentialGroup()
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addGroup(timeattackModeGeneralPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING, false)
                    .addComponent(timeattackModeAnswerPanel, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(timeattackModeQuestionPanel, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(timeattackModeInfoPanel, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
            .addGroup(timeattackModeGeneralPanel2Layout.createSequentialGroup()
                .addGap(262, 262, 262)
                .addComponent(timeattackModeTitlePanel, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(285, Short.MAX_VALUE))
        );
        timeattackModeGeneralPanel2Layout.setVerticalGroup(
            timeattackModeGeneralPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(timeattackModeGeneralPanel2Layout.createSequentialGroup()
                .addGap(25, 25, 25)
                .addComponent(timeattackModeTitlePanel, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18)
                .addComponent(timeattackModeInfoPanel, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18)
                .addComponent(timeattackModeQuestionPanel, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18)
                .addComponent(timeattackModeAnswerPanel, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );

        javax.swing.GroupLayout timeattackModeGeneralPanelLayout = new javax.swing.GroupLayout(timeattackModeGeneralPanel);
        timeattackModeGeneralPanel.setLayout(timeattackModeGeneralPanelLayout);
        timeattackModeGeneralPanelLayout.setHorizontalGroup(
            timeattackModeGeneralPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, timeattackModeGeneralPanelLayout.createSequentialGroup()
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(timeattackModeGeneralPanel2, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(33, 33, 33))
        );
        timeattackModeGeneralPanelLayout.setVerticalGroup(
            timeattackModeGeneralPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(timeattackModeGeneralPanelLayout.createSequentialGroup()
                .addContainerGap()
                .addComponent(timeattackModeGeneralPanel2, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addContainerGap())
        );

        javax.swing.GroupLayout timeattackModePanelLayout = new javax.swing.GroupLayout(timeattackModePanel);
        timeattackModePanel.setLayout(timeattackModePanelLayout);
        timeattackModePanelLayout.setHorizontalGroup(
            timeattackModePanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 0, Short.MAX_VALUE)
            .addGroup(timeattackModePanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                .addGroup(timeattackModePanelLayout.createSequentialGroup()
                    .addContainerGap()
                    .addComponent(timeattackModeGeneralPanel, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)))
        );
        timeattackModePanelLayout.setVerticalGroup(
            timeattackModePanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 0, Short.MAX_VALUE)
            .addGroup(timeattackModePanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                .addGroup(timeattackModePanelLayout.createSequentialGroup()
                    .addContainerGap()
                    .addComponent(timeattackModeGeneralPanel, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)))
        );

        elevatorModePanel.setPreferredSize(new java.awt.Dimension(1201, 777));

        elevatorModeGeneralPanel2.setPreferredSize(new java.awt.Dimension(1201, 777));

        elevatorModeTitleLabel1.setFont(new java.awt.Font("Arial Black", 0, 36)); // NOI18N
        elevatorModeTitleLabel1.setText("ΓΥΡΟΣ");

        elevatorModeTitleLabel2.setFont(new java.awt.Font("Arial Black", 0, 36)); // NOI18N

        javax.swing.GroupLayout elevatorModeTitlePanelLayout = new javax.swing.GroupLayout(elevatorModeTitlePanel);
        elevatorModeTitlePanel.setLayout(elevatorModeTitlePanelLayout);
        elevatorModeTitlePanelLayout.setHorizontalGroup(
            elevatorModeTitlePanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(elevatorModeTitlePanelLayout.createSequentialGroup()
                .addGap(216, 216, 216)
                .addComponent(elevatorModeTitleLabel1)
                .addGap(18, 18, 18)
                .addComponent(elevatorModeTitleLabel2, javax.swing.GroupLayout.PREFERRED_SIZE, 71, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(225, Short.MAX_VALUE))
        );
        elevatorModeTitlePanelLayout.setVerticalGroup(
            elevatorModeTitlePanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(elevatorModeTitlePanelLayout.createSequentialGroup()
                .addContainerGap()
                .addGroup(elevatorModeTitlePanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(elevatorModeTitleLabel2, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(elevatorModeTitleLabel1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                .addContainerGap())
        );

        elevatorModeQuestionScrollPane.setHorizontalScrollBarPolicy(javax.swing.ScrollPaneConstants.HORIZONTAL_SCROLLBAR_NEVER);
        elevatorModeQuestionScrollPane.setVerticalScrollBarPolicy(javax.swing.ScrollPaneConstants.VERTICAL_SCROLLBAR_NEVER);

        elevatorModeQuestionTextArea.setColumns(20);
        elevatorModeQuestionTextArea.setFont(new java.awt.Font("Arial", 2, 24)); // NOI18N
        elevatorModeQuestionTextArea.setLineWrap(true);
        elevatorModeQuestionTextArea.setRows(5);
        elevatorModeQuestionScrollPane.setViewportView(elevatorModeQuestionTextArea);

        elevatorModeQuestionLabel.setFont(new java.awt.Font("Arial", 0, 24)); // NOI18N
        elevatorModeQuestionLabel.setText("ΕΡΩΤΗΣΗ ΓΙΑ ΤΟΝ ΠΑΙΚΤΗ:");

        elevatorModePlayerLabel.setFont(new java.awt.Font("Arial", 2, 24)); // NOI18N

        javax.swing.GroupLayout elevatorModeQuestionPanelLayout = new javax.swing.GroupLayout(elevatorModeQuestionPanel);
        elevatorModeQuestionPanel.setLayout(elevatorModeQuestionPanelLayout);
        elevatorModeQuestionPanelLayout.setHorizontalGroup(
            elevatorModeQuestionPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(elevatorModeQuestionPanelLayout.createSequentialGroup()
                .addGap(20, 20, 20)
                .addGroup(elevatorModeQuestionPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(elevatorModeQuestionScrollPane)
                    .addGroup(elevatorModeQuestionPanelLayout.createSequentialGroup()
                        .addComponent(elevatorModeQuestionLabel)
                        .addGap(18, 18, 18)
                        .addComponent(elevatorModePlayerLabel, javax.swing.GroupLayout.PREFERRED_SIZE, 238, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(0, 419, Short.MAX_VALUE)))
                .addContainerGap())
        );
        elevatorModeQuestionPanelLayout.setVerticalGroup(
            elevatorModeQuestionPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, elevatorModeQuestionPanelLayout.createSequentialGroup()
                .addGroup(elevatorModeQuestionPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(elevatorModeQuestionLabel, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(elevatorModePlayerLabel, javax.swing.GroupLayout.PREFERRED_SIZE, 29, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(elevatorModeQuestionScrollPane, javax.swing.GroupLayout.PREFERRED_SIZE, 90, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(20, 20, 20))
        );

        elevatorModeAnswerLabel.setFont(new java.awt.Font("Arial", 0, 24)); // NOI18N
        elevatorModeAnswerLabel.setText("ΑΠΑΝΤΗΣΕΙΣ:");

        elevatorModeAnswer1.setFont(new java.awt.Font("Arial", 0, 24)); // NOI18N

        elevatorModeAnswer2.setFont(new java.awt.Font("Arial", 0, 24)); // NOI18N

        elevatorModeAnswer3.setFont(new java.awt.Font("Arial", 0, 24)); // NOI18N

        elevatorModeAnswer4.setFont(new java.awt.Font("Arial", 0, 24)); // NOI18N

        javax.swing.GroupLayout elevatorModeAnswerPanelLayout = new javax.swing.GroupLayout(elevatorModeAnswerPanel);
        elevatorModeAnswerPanel.setLayout(elevatorModeAnswerPanelLayout);
        elevatorModeAnswerPanelLayout.setHorizontalGroup(
            elevatorModeAnswerPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(elevatorModeAnswerPanelLayout.createSequentialGroup()
                .addGroup(elevatorModeAnswerPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(elevatorModeAnswerLabel)
                    .addGroup(elevatorModeAnswerPanelLayout.createSequentialGroup()
                        .addContainerGap()
                        .addGroup(elevatorModeAnswerPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                            .addComponent(elevatorModeAnswer3, javax.swing.GroupLayout.DEFAULT_SIZE, 350, Short.MAX_VALUE)
                            .addComponent(elevatorModeAnswer1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 159, Short.MAX_VALUE)
                        .addGroup(elevatorModeAnswerPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                            .addComponent(elevatorModeAnswer2, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                            .addComponent(elevatorModeAnswer4, javax.swing.GroupLayout.DEFAULT_SIZE, 350, Short.MAX_VALUE))))
                .addGap(45, 45, 45))
        );
        elevatorModeAnswerPanelLayout.setVerticalGroup(
            elevatorModeAnswerPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(elevatorModeAnswerPanelLayout.createSequentialGroup()
                .addContainerGap()
                .addComponent(elevatorModeAnswerLabel, javax.swing.GroupLayout.PREFERRED_SIZE, 36, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(29, 29, 29)
                .addGroup(elevatorModeAnswerPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(elevatorModeAnswer1, javax.swing.GroupLayout.PREFERRED_SIZE, 80, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(elevatorModeAnswer2, javax.swing.GroupLayout.PREFERRED_SIZE, 80, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(64, 64, 64)
                .addGroup(elevatorModeAnswerPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(elevatorModeAnswer4, javax.swing.GroupLayout.PREFERRED_SIZE, 81, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(elevatorModeAnswer3, javax.swing.GroupLayout.PREFERRED_SIZE, 81, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addContainerGap(90, Short.MAX_VALUE))
        );

        elevatorModeQInfoLabel.setFont(new java.awt.Font("Arial Narrow", 0, 30)); // NOI18N
        elevatorModeQInfoLabel.setText("ΕΡΩΤΗΣΕΙΣ ΠΟΥ ΑΠΟΜΕΝΟΥΝ:");
        elevatorModeQInfoLabel.setBorder(new javax.swing.border.SoftBevelBorder(javax.swing.border.BevelBorder.RAISED));

        elevatorModeNoOfQuestLabel.setFont(new java.awt.Font("Arial Narrow", 0, 30)); // NOI18N
        elevatorModeNoOfQuestLabel.setBorder(new javax.swing.border.SoftBevelBorder(javax.swing.border.BevelBorder.RAISED));

        elevatorModeCountInfoLabel.setFont(new java.awt.Font("Arial Narrow", 0, 30)); // NOI18N
        elevatorModeCountInfoLabel.setText("ΜΕΤΡΗΤΗΣ:");
        elevatorModeCountInfoLabel.setBorder(new javax.swing.border.SoftBevelBorder(javax.swing.border.BevelBorder.RAISED));

        elevatorModeCountLabel.setFont(new java.awt.Font("Arial Narrow", 0, 30)); // NOI18N
        elevatorModeCountLabel.setBorder(new javax.swing.border.SoftBevelBorder(javax.swing.border.BevelBorder.RAISED));

        javax.swing.GroupLayout elevatorModeInfoPanelLayout = new javax.swing.GroupLayout(elevatorModeInfoPanel);
        elevatorModeInfoPanel.setLayout(elevatorModeInfoPanelLayout);
        elevatorModeInfoPanelLayout.setHorizontalGroup(
            elevatorModeInfoPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(elevatorModeInfoPanelLayout.createSequentialGroup()
                .addGap(71, 71, 71)
                .addComponent(elevatorModeQInfoLabel)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(elevatorModeNoOfQuestLabel, javax.swing.GroupLayout.PREFERRED_SIZE, 25, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(117, 117, 117)
                .addComponent(elevatorModeCountInfoLabel)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(elevatorModeCountLabel, javax.swing.GroupLayout.PREFERRED_SIZE, 40, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(225, Short.MAX_VALUE))
        );
        elevatorModeInfoPanelLayout.setVerticalGroup(
            elevatorModeInfoPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, elevatorModeInfoPanelLayout.createSequentialGroup()
                .addContainerGap()
                .addGroup(elevatorModeInfoPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(elevatorModeQInfoLabel, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(elevatorModeCountInfoLabel, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(elevatorModeCountLabel, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(elevatorModeNoOfQuestLabel, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                .addContainerGap())
        );

        javax.swing.GroupLayout elevatorModeGeneralPanel3Layout = new javax.swing.GroupLayout(elevatorModeGeneralPanel3);
        elevatorModeGeneralPanel3.setLayout(elevatorModeGeneralPanel3Layout);
        elevatorModeGeneralPanel3Layout.setHorizontalGroup(
            elevatorModeGeneralPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(elevatorModeGeneralPanel3Layout.createSequentialGroup()
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addGroup(elevatorModeGeneralPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING, false)
                    .addComponent(elevatorModeAnswerPanel, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(elevatorModeQuestionPanel, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(elevatorModeInfoPanel, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
            .addGroup(elevatorModeGeneralPanel3Layout.createSequentialGroup()
                .addGap(262, 262, 262)
                .addComponent(elevatorModeTitlePanel, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(285, Short.MAX_VALUE))
        );
        elevatorModeGeneralPanel3Layout.setVerticalGroup(
            elevatorModeGeneralPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(elevatorModeGeneralPanel3Layout.createSequentialGroup()
                .addGap(25, 25, 25)
                .addComponent(elevatorModeTitlePanel, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18)
                .addComponent(elevatorModeInfoPanel, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18)
                .addComponent(elevatorModeQuestionPanel, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18)
                .addComponent(elevatorModeAnswerPanel, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );

        javax.swing.GroupLayout elevatorModeGeneralPanel2Layout = new javax.swing.GroupLayout(elevatorModeGeneralPanel2);
        elevatorModeGeneralPanel2.setLayout(elevatorModeGeneralPanel2Layout);
        elevatorModeGeneralPanel2Layout.setHorizontalGroup(
            elevatorModeGeneralPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, elevatorModeGeneralPanel2Layout.createSequentialGroup()
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(elevatorModeGeneralPanel3, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(33, 33, 33))
        );
        elevatorModeGeneralPanel2Layout.setVerticalGroup(
            elevatorModeGeneralPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(elevatorModeGeneralPanel2Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(elevatorModeGeneralPanel3, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addContainerGap())
        );

        javax.swing.GroupLayout elevatorModeGeneralPanel1Layout = new javax.swing.GroupLayout(elevatorModeGeneralPanel1);
        elevatorModeGeneralPanel1.setLayout(elevatorModeGeneralPanel1Layout);
        elevatorModeGeneralPanel1Layout.setHorizontalGroup(
            elevatorModeGeneralPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 1221, Short.MAX_VALUE)
            .addGroup(elevatorModeGeneralPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                .addGroup(elevatorModeGeneralPanel1Layout.createSequentialGroup()
                    .addContainerGap()
                    .addComponent(elevatorModeGeneralPanel2, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)))
        );
        elevatorModeGeneralPanel1Layout.setVerticalGroup(
            elevatorModeGeneralPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 799, Short.MAX_VALUE)
            .addGroup(elevatorModeGeneralPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                .addGroup(elevatorModeGeneralPanel1Layout.createSequentialGroup()
                    .addContainerGap()
                    .addComponent(elevatorModeGeneralPanel2, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)))
        );

        javax.swing.GroupLayout elevatorModePanelLayout = new javax.swing.GroupLayout(elevatorModePanel);
        elevatorModePanel.setLayout(elevatorModePanelLayout);
        elevatorModePanelLayout.setHorizontalGroup(
            elevatorModePanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 0, Short.MAX_VALUE)
            .addGroup(elevatorModePanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                .addGroup(elevatorModePanelLayout.createSequentialGroup()
                    .addContainerGap()
                    .addComponent(elevatorModeGeneralPanel1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)))
        );
        elevatorModePanelLayout.setVerticalGroup(
            elevatorModePanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 0, Short.MAX_VALUE)
            .addGroup(elevatorModePanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                .addGroup(elevatorModePanelLayout.createSequentialGroup()
                    .addContainerGap()
                    .addComponent(elevatorModeGeneralPanel1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)))
        );

        oneminquestModePanel.setPreferredSize(new java.awt.Dimension(1201, 777));

        oneminquestModeTitleLabel1.setFont(new java.awt.Font("Arial Black", 0, 36)); // NOI18N
        oneminquestModeTitleLabel1.setText("ΓΥΡΟΣ");

        oneminquestModeTitleLabel2.setFont(new java.awt.Font("Arial Black", 0, 36)); // NOI18N

        javax.swing.GroupLayout oneminquestModeTitlePanelLayout = new javax.swing.GroupLayout(oneminquestModeTitlePanel);
        oneminquestModeTitlePanel.setLayout(oneminquestModeTitlePanelLayout);
        oneminquestModeTitlePanelLayout.setHorizontalGroup(
            oneminquestModeTitlePanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(oneminquestModeTitlePanelLayout.createSequentialGroup()
                .addGap(216, 216, 216)
                .addComponent(oneminquestModeTitleLabel1)
                .addGap(18, 18, 18)
                .addComponent(oneminquestModeTitleLabel2, javax.swing.GroupLayout.PREFERRED_SIZE, 71, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(225, Short.MAX_VALUE))
        );
        oneminquestModeTitlePanelLayout.setVerticalGroup(
            oneminquestModeTitlePanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(oneminquestModeTitlePanelLayout.createSequentialGroup()
                .addContainerGap()
                .addGroup(oneminquestModeTitlePanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(oneminquestModeTitleLabel2, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(oneminquestModeTitleLabel1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                .addContainerGap())
        );

        oneminquestModeQuestionScrollPane.setHorizontalScrollBarPolicy(javax.swing.ScrollPaneConstants.HORIZONTAL_SCROLLBAR_NEVER);
        oneminquestModeQuestionScrollPane.setVerticalScrollBarPolicy(javax.swing.ScrollPaneConstants.VERTICAL_SCROLLBAR_NEVER);

        oneminquestModeQuestionTextArea.setColumns(20);
        oneminquestModeQuestionTextArea.setFont(new java.awt.Font("Arial", 2, 24)); // NOI18N
        oneminquestModeQuestionTextArea.setLineWrap(true);
        oneminquestModeQuestionTextArea.setRows(5);
        oneminquestModeQuestionScrollPane.setViewportView(oneminquestModeQuestionTextArea);

        oneminquestModeQuestionLabel.setFont(new java.awt.Font("Arial", 0, 24)); // NOI18N
        oneminquestModeQuestionLabel.setText("ΕΡΩΤΗΣΗ ΓΙΑ ΤΟΝ ΠΑΙΚΤΗ:");

        oneminquestModePlayerLabel.setFont(new java.awt.Font("Arial", 2, 24)); // NOI18N

        javax.swing.GroupLayout oneminquestModeQuestionPanelLayout = new javax.swing.GroupLayout(oneminquestModeQuestionPanel);
        oneminquestModeQuestionPanel.setLayout(oneminquestModeQuestionPanelLayout);
        oneminquestModeQuestionPanelLayout.setHorizontalGroup(
            oneminquestModeQuestionPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(oneminquestModeQuestionPanelLayout.createSequentialGroup()
                .addGap(20, 20, 20)
                .addGroup(oneminquestModeQuestionPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(oneminquestModeQuestionScrollPane)
                    .addGroup(oneminquestModeQuestionPanelLayout.createSequentialGroup()
                        .addComponent(oneminquestModeQuestionLabel)
                        .addGap(18, 18, 18)
                        .addComponent(oneminquestModePlayerLabel, javax.swing.GroupLayout.PREFERRED_SIZE, 238, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(0, 445, Short.MAX_VALUE)))
                .addContainerGap())
        );
        oneminquestModeQuestionPanelLayout.setVerticalGroup(
            oneminquestModeQuestionPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, oneminquestModeQuestionPanelLayout.createSequentialGroup()
                .addGroup(oneminquestModeQuestionPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(oneminquestModeQuestionLabel, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(oneminquestModePlayerLabel, javax.swing.GroupLayout.PREFERRED_SIZE, 29, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(oneminquestModeQuestionScrollPane, javax.swing.GroupLayout.PREFERRED_SIZE, 90, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(20, 20, 20))
        );

        oneminquestModeAnswerLabel.setFont(new java.awt.Font("Arial", 0, 24)); // NOI18N
        oneminquestModeAnswerLabel.setText("ΑΠΑΝΤΗΣΕΙΣ:");

        oneminquestModeAnswer1.setFont(new java.awt.Font("Arial", 0, 24)); // NOI18N

        oneminquestModeAnswer2.setFont(new java.awt.Font("Arial", 0, 24)); // NOI18N

        oneminquestModeAnswer3.setFont(new java.awt.Font("Arial", 0, 24)); // NOI18N

        oneminquestModeAnswer4.setFont(new java.awt.Font("Arial", 0, 24)); // NOI18N

        javax.swing.GroupLayout oneminquestModeAnswerPanelLayout = new javax.swing.GroupLayout(oneminquestModeAnswerPanel);
        oneminquestModeAnswerPanel.setLayout(oneminquestModeAnswerPanelLayout);
        oneminquestModeAnswerPanelLayout.setHorizontalGroup(
            oneminquestModeAnswerPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(oneminquestModeAnswerPanelLayout.createSequentialGroup()
                .addGroup(oneminquestModeAnswerPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(oneminquestModeAnswerLabel)
                    .addGroup(oneminquestModeAnswerPanelLayout.createSequentialGroup()
                        .addContainerGap()
                        .addGroup(oneminquestModeAnswerPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                            .addComponent(oneminquestModeAnswer3, javax.swing.GroupLayout.DEFAULT_SIZE, 350, Short.MAX_VALUE)
                            .addComponent(oneminquestModeAnswer1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 159, Short.MAX_VALUE)
                        .addGroup(oneminquestModeAnswerPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                            .addComponent(oneminquestModeAnswer2, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                            .addComponent(oneminquestModeAnswer4, javax.swing.GroupLayout.DEFAULT_SIZE, 350, Short.MAX_VALUE))))
                .addGap(45, 45, 45))
        );
        oneminquestModeAnswerPanelLayout.setVerticalGroup(
            oneminquestModeAnswerPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(oneminquestModeAnswerPanelLayout.createSequentialGroup()
                .addContainerGap()
                .addComponent(oneminquestModeAnswerLabel, javax.swing.GroupLayout.PREFERRED_SIZE, 36, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(29, 29, 29)
                .addGroup(oneminquestModeAnswerPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(oneminquestModeAnswer1, javax.swing.GroupLayout.PREFERRED_SIZE, 80, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(oneminquestModeAnswer2, javax.swing.GroupLayout.PREFERRED_SIZE, 80, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(64, 64, 64)
                .addGroup(oneminquestModeAnswerPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(oneminquestModeAnswer4, javax.swing.GroupLayout.PREFERRED_SIZE, 81, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(oneminquestModeAnswer3, javax.swing.GroupLayout.PREFERRED_SIZE, 81, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addContainerGap(90, Short.MAX_VALUE))
        );

        oneminquestModeAInfoLabel.setFont(new java.awt.Font("Arial Narrow", 0, 30)); // NOI18N
        oneminquestModeAInfoLabel.setText("ΕΡΩΤΗΣΕΙΣ ΠΟΥ ΑΠΑΝΤΗΘΗΚΑΝ:");
        oneminquestModeAInfoLabel.setBorder(new javax.swing.border.SoftBevelBorder(javax.swing.border.BevelBorder.RAISED));

        oneminquestModeNoOfAnsLabel.setFont(new java.awt.Font("Arial Narrow", 0, 30)); // NOI18N
        oneminquestModeNoOfAnsLabel.setBorder(new javax.swing.border.SoftBevelBorder(javax.swing.border.BevelBorder.RAISED));

        oneminquestModeTimeInfoLabel.setFont(new java.awt.Font("Arial Narrow", 0, 30)); // NOI18N
        oneminquestModeTimeInfoLabel.setText("ΧΡΟΝΟΣ:");
        oneminquestModeTimeInfoLabel.setBorder(new javax.swing.border.SoftBevelBorder(javax.swing.border.BevelBorder.RAISED));

        oneminquestModeTimeLabel.setFont(new java.awt.Font("Arial Narrow", 0, 30)); // NOI18N
        oneminquestModeTimeLabel.setBorder(new javax.swing.border.SoftBevelBorder(javax.swing.border.BevelBorder.RAISED));

        javax.swing.GroupLayout oneminquestModeInfoPanelLayout = new javax.swing.GroupLayout(oneminquestModeInfoPanel);
        oneminquestModeInfoPanel.setLayout(oneminquestModeInfoPanelLayout);
        oneminquestModeInfoPanelLayout.setHorizontalGroup(
            oneminquestModeInfoPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(oneminquestModeInfoPanelLayout.createSequentialGroup()
                .addGap(71, 71, 71)
                .addComponent(oneminquestModeAInfoLabel)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(oneminquestModeNoOfAnsLabel, javax.swing.GroupLayout.PREFERRED_SIZE, 33, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(109, 109, 109)
                .addComponent(oneminquestModeTimeInfoLabel)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(oneminquestModeTimeLabel, javax.swing.GroupLayout.PREFERRED_SIZE, 33, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );
        oneminquestModeInfoPanelLayout.setVerticalGroup(
            oneminquestModeInfoPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, oneminquestModeInfoPanelLayout.createSequentialGroup()
                .addContainerGap()
                .addGroup(oneminquestModeInfoPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(oneminquestModeAInfoLabel, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(oneminquestModeTimeInfoLabel, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(oneminquestModeTimeLabel, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(oneminquestModeNoOfAnsLabel, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                .addContainerGap())
        );

        javax.swing.GroupLayout oneminquestModeGeneralPanelLayout = new javax.swing.GroupLayout(oneminquestModeGeneralPanel);
        oneminquestModeGeneralPanel.setLayout(oneminquestModeGeneralPanelLayout);
        oneminquestModeGeneralPanelLayout.setHorizontalGroup(
            oneminquestModeGeneralPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(oneminquestModeGeneralPanelLayout.createSequentialGroup()
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addGroup(oneminquestModeGeneralPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING, false)
                    .addComponent(oneminquestModeAnswerPanel, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(oneminquestModeQuestionPanel, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(oneminquestModeInfoPanel, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
            .addGroup(oneminquestModeGeneralPanelLayout.createSequentialGroup()
                .addGap(262, 262, 262)
                .addComponent(oneminquestModeTitlePanel, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(285, Short.MAX_VALUE))
        );
        oneminquestModeGeneralPanelLayout.setVerticalGroup(
            oneminquestModeGeneralPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(oneminquestModeGeneralPanelLayout.createSequentialGroup()
                .addGap(25, 25, 25)
                .addComponent(oneminquestModeTitlePanel, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18)
                .addComponent(oneminquestModeInfoPanel, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18)
                .addComponent(oneminquestModeQuestionPanel, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18)
                .addComponent(oneminquestModeAnswerPanel, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );

        javax.swing.GroupLayout oneminquestModePanelLayout = new javax.swing.GroupLayout(oneminquestModePanel);
        oneminquestModePanel.setLayout(oneminquestModePanelLayout);
        oneminquestModePanelLayout.setHorizontalGroup(
            oneminquestModePanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, oneminquestModePanelLayout.createSequentialGroup()
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(oneminquestModeGeneralPanel, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18))
        );
        oneminquestModePanelLayout.setVerticalGroup(
            oneminquestModePanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(oneminquestModePanelLayout.createSequentialGroup()
                .addContainerGap()
                .addComponent(oneminquestModeGeneralPanel, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addContainerGap())
        );

        bombModePanel.setPreferredSize(new java.awt.Dimension(1201, 777));

        bombModeTitleLabel1.setFont(new java.awt.Font("Arial Black", 0, 36)); // NOI18N
        bombModeTitleLabel1.setText("ΓΥΡΟΣ");

        bombModeTitleLabel2.setFont(new java.awt.Font("Arial Black", 0, 36)); // NOI18N

        javax.swing.GroupLayout bombModeTitlePanelLayout = new javax.swing.GroupLayout(bombModeTitlePanel);
        bombModeTitlePanel.setLayout(bombModeTitlePanelLayout);
        bombModeTitlePanelLayout.setHorizontalGroup(
            bombModeTitlePanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(bombModeTitlePanelLayout.createSequentialGroup()
                .addGap(216, 216, 216)
                .addComponent(bombModeTitleLabel1)
                .addGap(18, 18, 18)
                .addComponent(bombModeTitleLabel2, javax.swing.GroupLayout.PREFERRED_SIZE, 71, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(225, Short.MAX_VALUE))
        );
        bombModeTitlePanelLayout.setVerticalGroup(
            bombModeTitlePanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(bombModeTitlePanelLayout.createSequentialGroup()
                .addContainerGap()
                .addGroup(bombModeTitlePanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(bombModeTitleLabel2, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(bombModeTitleLabel1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                .addContainerGap())
        );

        bombModeQuestionScrollPane.setHorizontalScrollBarPolicy(javax.swing.ScrollPaneConstants.HORIZONTAL_SCROLLBAR_NEVER);
        bombModeQuestionScrollPane.setVerticalScrollBarPolicy(javax.swing.ScrollPaneConstants.VERTICAL_SCROLLBAR_NEVER);

        bombModeQuestionTextArea.setColumns(20);
        bombModeQuestionTextArea.setFont(new java.awt.Font("Arial", 2, 24)); // NOI18N
        bombModeQuestionTextArea.setLineWrap(true);
        bombModeQuestionTextArea.setRows(5);
        bombModeQuestionScrollPane.setViewportView(bombModeQuestionTextArea);

        bombModeQuestionLabel1.setFont(new java.awt.Font("Arial", 0, 24)); // NOI18N
        bombModeQuestionLabel1.setText("ΕΡΩΤΗΣΗ ΓΙΑ ΤΟΝ ΠΑΙΚΤΗ:");

        bombModePlayerLabel2.setFont(new java.awt.Font("Arial", 2, 24)); // NOI18N

        javax.swing.GroupLayout bombModeQuestionPanelLayout = new javax.swing.GroupLayout(bombModeQuestionPanel);
        bombModeQuestionPanel.setLayout(bombModeQuestionPanelLayout);
        bombModeQuestionPanelLayout.setHorizontalGroup(
            bombModeQuestionPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(bombModeQuestionPanelLayout.createSequentialGroup()
                .addGap(20, 20, 20)
                .addGroup(bombModeQuestionPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(bombModeQuestionScrollPane)
                    .addGroup(bombModeQuestionPanelLayout.createSequentialGroup()
                        .addComponent(bombModeQuestionLabel1)
                        .addGap(18, 18, 18)
                        .addComponent(bombModePlayerLabel2, javax.swing.GroupLayout.PREFERRED_SIZE, 238, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(0, 445, Short.MAX_VALUE)))
                .addContainerGap())
        );
        bombModeQuestionPanelLayout.setVerticalGroup(
            bombModeQuestionPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, bombModeQuestionPanelLayout.createSequentialGroup()
                .addGroup(bombModeQuestionPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(bombModeQuestionLabel1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(bombModePlayerLabel2, javax.swing.GroupLayout.PREFERRED_SIZE, 29, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(bombModeQuestionScrollPane, javax.swing.GroupLayout.PREFERRED_SIZE, 90, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(20, 20, 20))
        );

        bombModeAnswerLabel.setFont(new java.awt.Font("Arial", 0, 24)); // NOI18N
        bombModeAnswerLabel.setText("ΑΠΑΝΤΗΣΕΙΣ:");

        bombModeAnswer1.setFont(new java.awt.Font("Arial", 0, 24)); // NOI18N

        bombModeAnswer2.setFont(new java.awt.Font("Arial", 0, 24)); // NOI18N

        bombModeAnswer3.setFont(new java.awt.Font("Arial", 0, 24)); // NOI18N

        bombModeAnswer4.setFont(new java.awt.Font("Arial", 0, 24)); // NOI18N

        javax.swing.GroupLayout bombModeAnswerPanelLayout = new javax.swing.GroupLayout(bombModeAnswerPanel);
        bombModeAnswerPanel.setLayout(bombModeAnswerPanelLayout);
        bombModeAnswerPanelLayout.setHorizontalGroup(
            bombModeAnswerPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(bombModeAnswerPanelLayout.createSequentialGroup()
                .addGroup(bombModeAnswerPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(bombModeAnswerLabel)
                    .addGroup(bombModeAnswerPanelLayout.createSequentialGroup()
                        .addContainerGap()
                        .addGroup(bombModeAnswerPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                            .addComponent(bombModeAnswer3, javax.swing.GroupLayout.DEFAULT_SIZE, 350, Short.MAX_VALUE)
                            .addComponent(bombModeAnswer1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 159, Short.MAX_VALUE)
                        .addGroup(bombModeAnswerPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                            .addComponent(bombModeAnswer2, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                            .addComponent(bombModeAnswer4, javax.swing.GroupLayout.DEFAULT_SIZE, 350, Short.MAX_VALUE))))
                .addGap(45, 45, 45))
        );
        bombModeAnswerPanelLayout.setVerticalGroup(
            bombModeAnswerPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(bombModeAnswerPanelLayout.createSequentialGroup()
                .addContainerGap()
                .addComponent(bombModeAnswerLabel, javax.swing.GroupLayout.PREFERRED_SIZE, 36, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(29, 29, 29)
                .addGroup(bombModeAnswerPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(bombModeAnswer1, javax.swing.GroupLayout.PREFERRED_SIZE, 80, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(bombModeAnswer2, javax.swing.GroupLayout.PREFERRED_SIZE, 80, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(64, 64, 64)
                .addGroup(bombModeAnswerPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(bombModeAnswer4, javax.swing.GroupLayout.PREFERRED_SIZE, 81, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(bombModeAnswer3, javax.swing.GroupLayout.PREFERRED_SIZE, 81, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addContainerGap(90, Short.MAX_VALUE))
        );

        bombModeAInfoLabel.setFont(new java.awt.Font("Arial Narrow", 0, 30)); // NOI18N
        bombModeAInfoLabel.setText("ΛΑΘΟΣ ΑΠΑΝΤΗΣΕΙΣ:");
        bombModeAInfoLabel.setBorder(new javax.swing.border.SoftBevelBorder(javax.swing.border.BevelBorder.RAISED));

        bombModeNoOfAnsLabel.setFont(new java.awt.Font("Arial Narrow", 0, 30)); // NOI18N
        bombModeNoOfAnsLabel.setBorder(new javax.swing.border.SoftBevelBorder(javax.swing.border.BevelBorder.RAISED));

        javax.swing.GroupLayout bombModeInfoPanelLayout = new javax.swing.GroupLayout(bombModeInfoPanel);
        bombModeInfoPanel.setLayout(bombModeInfoPanelLayout);
        bombModeInfoPanelLayout.setHorizontalGroup(
            bombModeInfoPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(bombModeInfoPanelLayout.createSequentialGroup()
                .addGap(319, 319, 319)
                .addComponent(bombModeAInfoLabel)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(bombModeNoOfAnsLabel, javax.swing.GroupLayout.PREFERRED_SIZE, 33, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );
        bombModeInfoPanelLayout.setVerticalGroup(
            bombModeInfoPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, bombModeInfoPanelLayout.createSequentialGroup()
                .addContainerGap()
                .addGroup(bombModeInfoPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(bombModeAInfoLabel, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(bombModeNoOfAnsLabel, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                .addContainerGap())
        );

        javax.swing.GroupLayout bombModeGeneralPanel2Layout = new javax.swing.GroupLayout(bombModeGeneralPanel2);
        bombModeGeneralPanel2.setLayout(bombModeGeneralPanel2Layout);
        bombModeGeneralPanel2Layout.setHorizontalGroup(
            bombModeGeneralPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(bombModeGeneralPanel2Layout.createSequentialGroup()
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addGroup(bombModeGeneralPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING, false)
                    .addComponent(bombModeAnswerPanel, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(bombModeQuestionPanel, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(bombModeInfoPanel, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
            .addGroup(bombModeGeneralPanel2Layout.createSequentialGroup()
                .addGap(262, 262, 262)
                .addComponent(bombModeTitlePanel, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(285, Short.MAX_VALUE))
        );
        bombModeGeneralPanel2Layout.setVerticalGroup(
            bombModeGeneralPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(bombModeGeneralPanel2Layout.createSequentialGroup()
                .addGap(25, 25, 25)
                .addComponent(bombModeTitlePanel, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18)
                .addComponent(bombModeInfoPanel, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18)
                .addComponent(bombModeQuestionPanel, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18)
                .addComponent(bombModeAnswerPanel, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );

        javax.swing.GroupLayout bombModeGeneralPanelLayout = new javax.swing.GroupLayout(bombModeGeneralPanel);
        bombModeGeneralPanel.setLayout(bombModeGeneralPanelLayout);
        bombModeGeneralPanelLayout.setHorizontalGroup(
            bombModeGeneralPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, bombModeGeneralPanelLayout.createSequentialGroup()
                .addContainerGap(25, Short.MAX_VALUE)
                .addComponent(bombModeGeneralPanel2, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18))
        );
        bombModeGeneralPanelLayout.setVerticalGroup(
            bombModeGeneralPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(bombModeGeneralPanelLayout.createSequentialGroup()
                .addContainerGap()
                .addComponent(bombModeGeneralPanel2, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addContainerGap())
        );

        javax.swing.GroupLayout bombModePanelLayout = new javax.swing.GroupLayout(bombModePanel);
        bombModePanel.setLayout(bombModePanelLayout);
        bombModePanelLayout.setHorizontalGroup(
            bombModePanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 0, Short.MAX_VALUE)
            .addGroup(bombModePanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                .addGroup(bombModePanelLayout.createSequentialGroup()
                    .addGap(0, 0, Short.MAX_VALUE)
                    .addComponent(bombModeGeneralPanel, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addGap(0, 0, Short.MAX_VALUE)))
        );
        bombModePanelLayout.setVerticalGroup(
            bombModePanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 0, Short.MAX_VALUE)
            .addGroup(bombModePanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                .addGroup(bombModePanelLayout.createSequentialGroup()
                    .addGap(0, 0, Short.MAX_VALUE)
                    .addComponent(bombModeGeneralPanel, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addGap(0, 0, Short.MAX_VALUE)))
        );

        survivalModePanel.setPreferredSize(new java.awt.Dimension(1201, 777));

        survivalModeTitleLabel1.setFont(new java.awt.Font("Arial Black", 0, 36)); // NOI18N
        survivalModeTitleLabel1.setText("ΓΥΡΟΣ");

        survivalModeTitleLabel2.setFont(new java.awt.Font("Arial Black", 0, 36)); // NOI18N

        javax.swing.GroupLayout survivalModeTitlePanelLayout = new javax.swing.GroupLayout(survivalModeTitlePanel);
        survivalModeTitlePanel.setLayout(survivalModeTitlePanelLayout);
        survivalModeTitlePanelLayout.setHorizontalGroup(
            survivalModeTitlePanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(survivalModeTitlePanelLayout.createSequentialGroup()
                .addGap(216, 216, 216)
                .addComponent(survivalModeTitleLabel1)
                .addGap(18, 18, 18)
                .addComponent(survivalModeTitleLabel2, javax.swing.GroupLayout.PREFERRED_SIZE, 71, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(225, Short.MAX_VALUE))
        );
        survivalModeTitlePanelLayout.setVerticalGroup(
            survivalModeTitlePanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(survivalModeTitlePanelLayout.createSequentialGroup()
                .addContainerGap()
                .addGroup(survivalModeTitlePanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(survivalModeTitleLabel2, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(survivalModeTitleLabel1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                .addContainerGap())
        );

        survivalModeQuestionScrollPane.setHorizontalScrollBarPolicy(javax.swing.ScrollPaneConstants.HORIZONTAL_SCROLLBAR_NEVER);
        survivalModeQuestionScrollPane.setVerticalScrollBarPolicy(javax.swing.ScrollPaneConstants.VERTICAL_SCROLLBAR_NEVER);

        survivalModeQuestionTextArea.setColumns(20);
        survivalModeQuestionTextArea.setFont(new java.awt.Font("Arial", 2, 24)); // NOI18N
        survivalModeQuestionTextArea.setLineWrap(true);
        survivalModeQuestionTextArea.setRows(5);
        survivalModeQuestionScrollPane.setViewportView(survivalModeQuestionTextArea);

        survivalModeQuestionLabel1.setFont(new java.awt.Font("Arial", 0, 24)); // NOI18N
        survivalModeQuestionLabel1.setText("ΕΡΩΤΗΣΗ ΓΙΑ ΤΟΝ ΠΑΙΚΤΗ:");

        survivalModePlayerLabel.setFont(new java.awt.Font("Arial", 2, 24)); // NOI18N

        javax.swing.GroupLayout survivalModeQuestionPanelLayout = new javax.swing.GroupLayout(survivalModeQuestionPanel);
        survivalModeQuestionPanel.setLayout(survivalModeQuestionPanelLayout);
        survivalModeQuestionPanelLayout.setHorizontalGroup(
            survivalModeQuestionPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(survivalModeQuestionPanelLayout.createSequentialGroup()
                .addGap(20, 20, 20)
                .addGroup(survivalModeQuestionPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(survivalModeQuestionScrollPane)
                    .addGroup(survivalModeQuestionPanelLayout.createSequentialGroup()
                        .addComponent(survivalModeQuestionLabel1)
                        .addGap(18, 18, 18)
                        .addComponent(survivalModePlayerLabel, javax.swing.GroupLayout.PREFERRED_SIZE, 238, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(0, 445, Short.MAX_VALUE)))
                .addContainerGap())
        );
        survivalModeQuestionPanelLayout.setVerticalGroup(
            survivalModeQuestionPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, survivalModeQuestionPanelLayout.createSequentialGroup()
                .addGroup(survivalModeQuestionPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(survivalModeQuestionLabel1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(survivalModePlayerLabel, javax.swing.GroupLayout.PREFERRED_SIZE, 29, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(survivalModeQuestionScrollPane, javax.swing.GroupLayout.PREFERRED_SIZE, 90, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(20, 20, 20))
        );

        survivalModeAnswerLabel.setFont(new java.awt.Font("Arial", 0, 24)); // NOI18N
        survivalModeAnswerLabel.setText("ΑΠΑΝΤΗΣΕΙΣ:");

        survivalModeAnswer1.setFont(new java.awt.Font("Arial", 0, 24)); // NOI18N

        survivalModeAnswer2.setFont(new java.awt.Font("Arial", 0, 24)); // NOI18N

        survivalModeAnswer3.setFont(new java.awt.Font("Arial", 0, 24)); // NOI18N

        survivalModeAnswer4.setFont(new java.awt.Font("Arial", 0, 24)); // NOI18N

        javax.swing.GroupLayout survivalModeAnswerPanelLayout = new javax.swing.GroupLayout(survivalModeAnswerPanel);
        survivalModeAnswerPanel.setLayout(survivalModeAnswerPanelLayout);
        survivalModeAnswerPanelLayout.setHorizontalGroup(
            survivalModeAnswerPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(survivalModeAnswerPanelLayout.createSequentialGroup()
                .addGroup(survivalModeAnswerPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(survivalModeAnswerLabel)
                    .addGroup(survivalModeAnswerPanelLayout.createSequentialGroup()
                        .addContainerGap()
                        .addGroup(survivalModeAnswerPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                            .addComponent(survivalModeAnswer3, javax.swing.GroupLayout.DEFAULT_SIZE, 350, Short.MAX_VALUE)
                            .addComponent(survivalModeAnswer1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 159, Short.MAX_VALUE)
                        .addGroup(survivalModeAnswerPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                            .addComponent(survivalModeAnswer2, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                            .addComponent(survivalModeAnswer4, javax.swing.GroupLayout.DEFAULT_SIZE, 350, Short.MAX_VALUE))))
                .addGap(45, 45, 45))
        );
        survivalModeAnswerPanelLayout.setVerticalGroup(
            survivalModeAnswerPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(survivalModeAnswerPanelLayout.createSequentialGroup()
                .addContainerGap()
                .addComponent(survivalModeAnswerLabel, javax.swing.GroupLayout.PREFERRED_SIZE, 36, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(29, 29, 29)
                .addGroup(survivalModeAnswerPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(survivalModeAnswer1, javax.swing.GroupLayout.PREFERRED_SIZE, 80, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(survivalModeAnswer2, javax.swing.GroupLayout.PREFERRED_SIZE, 80, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(64, 64, 64)
                .addGroup(survivalModeAnswerPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(survivalModeAnswer4, javax.swing.GroupLayout.PREFERRED_SIZE, 81, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(survivalModeAnswer3, javax.swing.GroupLayout.PREFERRED_SIZE, 81, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addContainerGap(90, Short.MAX_VALUE))
        );

        survivalModeQInfoLabel.setFont(new java.awt.Font("Arial Narrow", 0, 30)); // NOI18N
        survivalModeQInfoLabel.setText("ΕΡΩΤΗΣΕΙΣ ΠΟΥ ΑΠΟΜΕΝΟΥΝ:");
        survivalModeQInfoLabel.setBorder(new javax.swing.border.SoftBevelBorder(javax.swing.border.BevelBorder.RAISED));

        survivalModeNoOfQuestLabel.setFont(new java.awt.Font("Arial Narrow", 0, 30)); // NOI18N
        survivalModeNoOfQuestLabel.setBorder(new javax.swing.border.SoftBevelBorder(javax.swing.border.BevelBorder.RAISED));

        survivalModeLifeInfoLabel.setFont(new java.awt.Font("Arial Narrow", 0, 30)); // NOI18N
        survivalModeLifeInfoLabel.setText("ΖΩΕΣ:");
        survivalModeLifeInfoLabel.setBorder(new javax.swing.border.SoftBevelBorder(javax.swing.border.BevelBorder.RAISED));

        survivalModeLifeLabel.setFont(new java.awt.Font("Arial Narrow", 0, 30)); // NOI18N
        survivalModeLifeLabel.setBorder(new javax.swing.border.SoftBevelBorder(javax.swing.border.BevelBorder.RAISED));

        javax.swing.GroupLayout survivalModeInfoPanelLayout = new javax.swing.GroupLayout(survivalModeInfoPanel);
        survivalModeInfoPanel.setLayout(survivalModeInfoPanelLayout);
        survivalModeInfoPanelLayout.setHorizontalGroup(
            survivalModeInfoPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(survivalModeInfoPanelLayout.createSequentialGroup()
                .addGap(71, 71, 71)
                .addComponent(survivalModeQInfoLabel)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(survivalModeNoOfQuestLabel, javax.swing.GroupLayout.PREFERRED_SIZE, 33, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(180, 180, 180)
                .addComponent(survivalModeLifeInfoLabel)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(survivalModeLifeLabel, javax.swing.GroupLayout.PREFERRED_SIZE, 33, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );
        survivalModeInfoPanelLayout.setVerticalGroup(
            survivalModeInfoPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, survivalModeInfoPanelLayout.createSequentialGroup()
                .addContainerGap()
                .addGroup(survivalModeInfoPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(survivalModeLifeInfoLabel, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(survivalModeLifeLabel, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addGroup(survivalModeInfoPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                        .addComponent(survivalModeQInfoLabel, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addComponent(survivalModeNoOfQuestLabel, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)))
                .addContainerGap())
        );

        javax.swing.GroupLayout survivalModeGeneralPanelLayout = new javax.swing.GroupLayout(survivalModeGeneralPanel);
        survivalModeGeneralPanel.setLayout(survivalModeGeneralPanelLayout);
        survivalModeGeneralPanelLayout.setHorizontalGroup(
            survivalModeGeneralPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(survivalModeGeneralPanelLayout.createSequentialGroup()
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addGroup(survivalModeGeneralPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING, false)
                    .addComponent(survivalModeAnswerPanel, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(survivalModeQuestionPanel, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(survivalModeInfoPanel, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
            .addGroup(survivalModeGeneralPanelLayout.createSequentialGroup()
                .addGap(262, 262, 262)
                .addComponent(survivalModeTitlePanel, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(285, Short.MAX_VALUE))
        );
        survivalModeGeneralPanelLayout.setVerticalGroup(
            survivalModeGeneralPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(survivalModeGeneralPanelLayout.createSequentialGroup()
                .addGap(25, 25, 25)
                .addComponent(survivalModeTitlePanel, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18)
                .addComponent(survivalModeInfoPanel, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18)
                .addComponent(survivalModeQuestionPanel, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18)
                .addComponent(survivalModeAnswerPanel, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );

        javax.swing.GroupLayout survivalModePanelLayout = new javax.swing.GroupLayout(survivalModePanel);
        survivalModePanel.setLayout(survivalModePanelLayout);
        survivalModePanelLayout.setHorizontalGroup(
            survivalModePanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, survivalModePanelLayout.createSequentialGroup()
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(survivalModeGeneralPanel, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18))
        );
        survivalModePanelLayout.setVerticalGroup(
            survivalModePanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(survivalModePanelLayout.createSequentialGroup()
                .addContainerGap()
                .addComponent(survivalModeGeneralPanel, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addContainerGap())
        );

        ftfModePanel.setPreferredSize(new java.awt.Dimension(1201, 777));

        ftfModeTitleLabel1.setFont(new java.awt.Font("Arial Black", 0, 36)); // NOI18N
        ftfModeTitleLabel1.setText("ΓΥΡΟΣ");

        ftfModeTitleLabel2.setFont(new java.awt.Font("Arial Black", 0, 36)); // NOI18N

        javax.swing.GroupLayout ftfModeTitlePanelLayout = new javax.swing.GroupLayout(ftfModeTitlePanel);
        ftfModeTitlePanel.setLayout(ftfModeTitlePanelLayout);
        ftfModeTitlePanelLayout.setHorizontalGroup(
            ftfModeTitlePanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(ftfModeTitlePanelLayout.createSequentialGroup()
                .addGap(216, 216, 216)
                .addComponent(ftfModeTitleLabel1)
                .addGap(18, 18, 18)
                .addComponent(ftfModeTitleLabel2, javax.swing.GroupLayout.PREFERRED_SIZE, 71, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(225, Short.MAX_VALUE))
        );
        ftfModeTitlePanelLayout.setVerticalGroup(
            ftfModeTitlePanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(ftfModeTitlePanelLayout.createSequentialGroup()
                .addContainerGap()
                .addGroup(ftfModeTitlePanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(ftfModeTitleLabel2, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(ftfModeTitleLabel1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                .addContainerGap())
        );

        ftfModeQuestionScrollPane.setHorizontalScrollBarPolicy(javax.swing.ScrollPaneConstants.HORIZONTAL_SCROLLBAR_NEVER);
        ftfModeQuestionScrollPane.setVerticalScrollBarPolicy(javax.swing.ScrollPaneConstants.VERTICAL_SCROLLBAR_NEVER);

        ftfModeQuestionTextArea.setColumns(20);
        ftfModeQuestionTextArea.setFont(new java.awt.Font("Arial", 2, 24)); // NOI18N
        ftfModeQuestionTextArea.setLineWrap(true);
        ftfModeQuestionTextArea.setRows(5);
        ftfModeQuestionScrollPane.setViewportView(ftfModeQuestionTextArea);

        ftfModeQuestionLabel.setFont(new java.awt.Font("Arial", 0, 24)); // NOI18N
        ftfModeQuestionLabel.setText("ΕΡΩΤΗΣΗ ΓΙΑ ΤΟΝ ΠΑΙΚΤΗ:");

        ftfModePlayerLabel.setFont(new java.awt.Font("Arial", 2, 24)); // NOI18N

        javax.swing.GroupLayout ftfModeQuestionPanelLayout = new javax.swing.GroupLayout(ftfModeQuestionPanel);
        ftfModeQuestionPanel.setLayout(ftfModeQuestionPanelLayout);
        ftfModeQuestionPanelLayout.setHorizontalGroup(
            ftfModeQuestionPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(ftfModeQuestionPanelLayout.createSequentialGroup()
                .addGap(20, 20, 20)
                .addGroup(ftfModeQuestionPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(ftfModeQuestionScrollPane)
                    .addGroup(ftfModeQuestionPanelLayout.createSequentialGroup()
                        .addComponent(ftfModeQuestionLabel)
                        .addGap(18, 18, 18)
                        .addComponent(ftfModePlayerLabel, javax.swing.GroupLayout.PREFERRED_SIZE, 238, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(0, 445, Short.MAX_VALUE)))
                .addContainerGap())
        );
        ftfModeQuestionPanelLayout.setVerticalGroup(
            ftfModeQuestionPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, ftfModeQuestionPanelLayout.createSequentialGroup()
                .addGroup(ftfModeQuestionPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(ftfModeQuestionLabel, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(ftfModePlayerLabel, javax.swing.GroupLayout.PREFERRED_SIZE, 29, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(ftfModeQuestionScrollPane, javax.swing.GroupLayout.PREFERRED_SIZE, 90, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(20, 20, 20))
        );

        ftfModeAnswerLabel.setFont(new java.awt.Font("Arial", 0, 24)); // NOI18N
        ftfModeAnswerLabel.setText("ΑΠΑΝΤΗΣΕΙΣ:");

        ftfModeAnswer1.setFont(new java.awt.Font("Arial", 0, 24)); // NOI18N

        ftfModeAnswer2.setFont(new java.awt.Font("Arial", 0, 24)); // NOI18N

        ftfModeAnswer3.setFont(new java.awt.Font("Arial", 0, 24)); // NOI18N

        ftfModeAnswer4.setFont(new java.awt.Font("Arial", 0, 24)); // NOI18N

        javax.swing.GroupLayout ftfModeAnswerPanelLayout = new javax.swing.GroupLayout(ftfModeAnswerPanel);
        ftfModeAnswerPanel.setLayout(ftfModeAnswerPanelLayout);
        ftfModeAnswerPanelLayout.setHorizontalGroup(
            ftfModeAnswerPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(ftfModeAnswerPanelLayout.createSequentialGroup()
                .addGroup(ftfModeAnswerPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(ftfModeAnswerLabel)
                    .addGroup(ftfModeAnswerPanelLayout.createSequentialGroup()
                        .addContainerGap()
                        .addGroup(ftfModeAnswerPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                            .addComponent(ftfModeAnswer3, javax.swing.GroupLayout.DEFAULT_SIZE, 350, Short.MAX_VALUE)
                            .addComponent(ftfModeAnswer1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 159, Short.MAX_VALUE)
                        .addGroup(ftfModeAnswerPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                            .addComponent(ftfModeAnswer2, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                            .addComponent(ftfModeAnswer4, javax.swing.GroupLayout.DEFAULT_SIZE, 350, Short.MAX_VALUE))))
                .addGap(45, 45, 45))
        );
        ftfModeAnswerPanelLayout.setVerticalGroup(
            ftfModeAnswerPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(ftfModeAnswerPanelLayout.createSequentialGroup()
                .addContainerGap()
                .addComponent(ftfModeAnswerLabel, javax.swing.GroupLayout.PREFERRED_SIZE, 36, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(29, 29, 29)
                .addGroup(ftfModeAnswerPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(ftfModeAnswer1, javax.swing.GroupLayout.PREFERRED_SIZE, 80, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(ftfModeAnswer2, javax.swing.GroupLayout.PREFERRED_SIZE, 80, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(64, 64, 64)
                .addGroup(ftfModeAnswerPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(ftfModeAnswer4, javax.swing.GroupLayout.PREFERRED_SIZE, 81, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(ftfModeAnswer3, javax.swing.GroupLayout.PREFERRED_SIZE, 81, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addContainerGap(90, Short.MAX_VALUE))
        );

        ftfModeAInfoLabel.setFont(new java.awt.Font("Arial Narrow", 0, 30)); // NOI18N
        ftfModeAInfoLabel.setText("ΣΩΣΤΕΣ ΑΠΑΝΤΗΣΕΙΣ:");
        ftfModeAInfoLabel.setBorder(new javax.swing.border.SoftBevelBorder(javax.swing.border.BevelBorder.RAISED));

        ftfModeNoOfAnsLabel.setFont(new java.awt.Font("Arial Narrow", 0, 30)); // NOI18N
        ftfModeNoOfAnsLabel.setBorder(new javax.swing.border.SoftBevelBorder(javax.swing.border.BevelBorder.RAISED));

        javax.swing.GroupLayout ftfModeInfoPanelLayout = new javax.swing.GroupLayout(ftfModeInfoPanel);
        ftfModeInfoPanel.setLayout(ftfModeInfoPanelLayout);
        ftfModeInfoPanelLayout.setHorizontalGroup(
            ftfModeInfoPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(ftfModeInfoPanelLayout.createSequentialGroup()
                .addGap(319, 319, 319)
                .addComponent(ftfModeAInfoLabel)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(ftfModeNoOfAnsLabel, javax.swing.GroupLayout.PREFERRED_SIZE, 33, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );
        ftfModeInfoPanelLayout.setVerticalGroup(
            ftfModeInfoPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, ftfModeInfoPanelLayout.createSequentialGroup()
                .addContainerGap()
                .addGroup(ftfModeInfoPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(ftfModeAInfoLabel, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(ftfModeNoOfAnsLabel, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                .addContainerGap())
        );

        javax.swing.GroupLayout ftfModeGeneralPanelLayout = new javax.swing.GroupLayout(ftfModeGeneralPanel);
        ftfModeGeneralPanel.setLayout(ftfModeGeneralPanelLayout);
        ftfModeGeneralPanelLayout.setHorizontalGroup(
            ftfModeGeneralPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(ftfModeGeneralPanelLayout.createSequentialGroup()
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addGroup(ftfModeGeneralPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING, false)
                    .addComponent(ftfModeAnswerPanel, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(ftfModeQuestionPanel, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(ftfModeInfoPanel, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
            .addGroup(ftfModeGeneralPanelLayout.createSequentialGroup()
                .addGap(262, 262, 262)
                .addComponent(ftfModeTitlePanel, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(285, Short.MAX_VALUE))
        );
        ftfModeGeneralPanelLayout.setVerticalGroup(
            ftfModeGeneralPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(ftfModeGeneralPanelLayout.createSequentialGroup()
                .addGap(25, 25, 25)
                .addComponent(ftfModeTitlePanel, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18)
                .addComponent(ftfModeInfoPanel, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18)
                .addComponent(ftfModeQuestionPanel, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18)
                .addComponent(ftfModeAnswerPanel, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );

        javax.swing.GroupLayout ftfModePanelLayout = new javax.swing.GroupLayout(ftfModePanel);
        ftfModePanel.setLayout(ftfModePanelLayout);
        ftfModePanelLayout.setHorizontalGroup(
            ftfModePanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, ftfModePanelLayout.createSequentialGroup()
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(ftfModeGeneralPanel, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18))
        );
        ftfModePanelLayout.setVerticalGroup(
            ftfModePanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(ftfModePanelLayout.createSequentialGroup()
                .addContainerGap()
                .addComponent(ftfModeGeneralPanel, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addContainerGap())
        );

        gamblingModePanel.setPreferredSize(new java.awt.Dimension(1201, 777));

        javax.swing.GroupLayout gamblingModePanelLayout = new javax.swing.GroupLayout(gamblingModePanel);
        gamblingModePanel.setLayout(gamblingModePanelLayout);
        gamblingModePanelLayout.setHorizontalGroup(
            gamblingModePanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 1201, Short.MAX_VALUE)
        );
        gamblingModePanelLayout.setVerticalGroup(
            gamblingModePanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 777, Short.MAX_VALUE)
        );

        quickGamePanel.setPreferredSize(new java.awt.Dimension(1201, 777));

        quickGameTitleLabel1.setFont(new java.awt.Font("Arial Black", 0, 36)); // NOI18N
        quickGameTitleLabel1.setText("ΓΥΡΟΣ");

        quickGameTitleLabel2.setFont(new java.awt.Font("Arial Black", 0, 36)); // NOI18N

        javax.swing.GroupLayout quickGameTitlePanelLayout = new javax.swing.GroupLayout(quickGameTitlePanel);
        quickGameTitlePanel.setLayout(quickGameTitlePanelLayout);
        quickGameTitlePanelLayout.setHorizontalGroup(
            quickGameTitlePanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(quickGameTitlePanelLayout.createSequentialGroup()
                .addGap(216, 216, 216)
                .addComponent(quickGameTitleLabel1)
                .addGap(18, 18, 18)
                .addComponent(quickGameTitleLabel2, javax.swing.GroupLayout.PREFERRED_SIZE, 71, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(225, Short.MAX_VALUE))
        );
        quickGameTitlePanelLayout.setVerticalGroup(
            quickGameTitlePanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(quickGameTitlePanelLayout.createSequentialGroup()
                .addContainerGap()
                .addGroup(quickGameTitlePanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(quickGameTitleLabel2, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(quickGameTitleLabel1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                .addContainerGap())
        );

        quickGameQuestionScrollPane.setHorizontalScrollBarPolicy(javax.swing.ScrollPaneConstants.HORIZONTAL_SCROLLBAR_NEVER);
        quickGameQuestionScrollPane.setVerticalScrollBarPolicy(javax.swing.ScrollPaneConstants.VERTICAL_SCROLLBAR_NEVER);

        quickGameQuestionTextArea.setColumns(20);
        quickGameQuestionTextArea.setFont(new java.awt.Font("Arial", 2, 24)); // NOI18N
        quickGameQuestionTextArea.setLineWrap(true);
        quickGameQuestionTextArea.setRows(5);
        quickGameQuestionScrollPane.setViewportView(quickGameQuestionTextArea);

        quickGameQuestionLabel.setFont(new java.awt.Font("Arial", 0, 24)); // NOI18N
        quickGameQuestionLabel.setText("ΕΡΩΤΗΣΗ ΓΙΑ ΤΟΝ ΠΑΙΚΤΗ:");

        quickGamePlayerLabel.setFont(new java.awt.Font("Arial", 2, 24)); // NOI18N

        javax.swing.GroupLayout quickGameQuestionPanelLayout = new javax.swing.GroupLayout(quickGameQuestionPanel);
        quickGameQuestionPanel.setLayout(quickGameQuestionPanelLayout);
        quickGameQuestionPanelLayout.setHorizontalGroup(
            quickGameQuestionPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(quickGameQuestionPanelLayout.createSequentialGroup()
                .addGap(20, 20, 20)
                .addGroup(quickGameQuestionPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(quickGameQuestionScrollPane)
                    .addGroup(quickGameQuestionPanelLayout.createSequentialGroup()
                        .addComponent(quickGameQuestionLabel)
                        .addGap(18, 18, 18)
                        .addComponent(quickGamePlayerLabel, javax.swing.GroupLayout.PREFERRED_SIZE, 238, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(0, 377, Short.MAX_VALUE)))
                .addContainerGap())
        );
        quickGameQuestionPanelLayout.setVerticalGroup(
            quickGameQuestionPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, quickGameQuestionPanelLayout.createSequentialGroup()
                .addGroup(quickGameQuestionPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(quickGameQuestionLabel, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(quickGamePlayerLabel, javax.swing.GroupLayout.PREFERRED_SIZE, 29, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(quickGameQuestionScrollPane, javax.swing.GroupLayout.PREFERRED_SIZE, 90, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap())
        );

        quickGameAnswerLabel.setFont(new java.awt.Font("Arial", 0, 24)); // NOI18N
        quickGameAnswerLabel.setText("ΑΠΑΝΤΗΣΕΙΣ:");

        quickGameAnswer1.setFont(new java.awt.Font("Arial", 0, 24)); // NOI18N

        quickGameAnswer2.setFont(new java.awt.Font("Arial", 0, 24)); // NOI18N

        quickGameAnswer3.setFont(new java.awt.Font("Arial", 0, 24)); // NOI18N

        quickGameAnswer4.setFont(new java.awt.Font("Arial", 0, 24)); // NOI18N

        javax.swing.GroupLayout quickGameAnswerPanelLayout = new javax.swing.GroupLayout(quickGameAnswerPanel);
        quickGameAnswerPanel.setLayout(quickGameAnswerPanelLayout);
        quickGameAnswerPanelLayout.setHorizontalGroup(
            quickGameAnswerPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(quickGameAnswerPanelLayout.createSequentialGroup()
                .addGroup(quickGameAnswerPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(quickGameAnswerLabel)
                    .addGroup(quickGameAnswerPanelLayout.createSequentialGroup()
                        .addContainerGap()
                        .addGroup(quickGameAnswerPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                            .addComponent(quickGameAnswer3, javax.swing.GroupLayout.DEFAULT_SIZE, 350, Short.MAX_VALUE)
                            .addComponent(quickGameAnswer1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 159, Short.MAX_VALUE)
                        .addGroup(quickGameAnswerPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                            .addComponent(quickGameAnswer2, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                            .addComponent(quickGameAnswer4, javax.swing.GroupLayout.DEFAULT_SIZE, 350, Short.MAX_VALUE))))
                .addGap(45, 45, 45))
        );
        quickGameAnswerPanelLayout.setVerticalGroup(
            quickGameAnswerPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(quickGameAnswerPanelLayout.createSequentialGroup()
                .addContainerGap()
                .addComponent(quickGameAnswerLabel, javax.swing.GroupLayout.PREFERRED_SIZE, 36, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(29, 29, 29)
                .addGroup(quickGameAnswerPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(quickGameAnswer1, javax.swing.GroupLayout.PREFERRED_SIZE, 80, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(quickGameAnswer2, javax.swing.GroupLayout.PREFERRED_SIZE, 80, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(64, 64, 64)
                .addGroup(quickGameAnswerPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(quickGameAnswer4, javax.swing.GroupLayout.PREFERRED_SIZE, 81, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(quickGameAnswer3, javax.swing.GroupLayout.PREFERRED_SIZE, 81, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(114, 114, 114))
        );

        javax.swing.GroupLayout quickGameGeneralPanelLayout = new javax.swing.GroupLayout(quickGameGeneralPanel);
        quickGameGeneralPanel.setLayout(quickGameGeneralPanelLayout);
        quickGameGeneralPanelLayout.setHorizontalGroup(
            quickGameGeneralPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(quickGameGeneralPanelLayout.createSequentialGroup()
                .addContainerGap(94, Short.MAX_VALUE)
                .addGroup(quickGameGeneralPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(quickGameGeneralPanelLayout.createSequentialGroup()
                        .addGap(126, 126, 126)
                        .addComponent(quickGameTitlePanel, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(quickGameGeneralPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                        .addComponent(quickGameAnswerPanel, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addComponent(quickGameQuestionPanel, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addContainerGap(102, Short.MAX_VALUE))
        );
        quickGameGeneralPanelLayout.setVerticalGroup(
            quickGameGeneralPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(quickGameGeneralPanelLayout.createSequentialGroup()
                .addGap(37, 37, 37)
                .addComponent(quickGameTitlePanel, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(79, 79, 79)
                .addComponent(quickGameQuestionPanel, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(quickGameAnswerPanel, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );

        javax.swing.GroupLayout quickGamePanelLayout = new javax.swing.GroupLayout(quickGamePanel);
        quickGamePanel.setLayout(quickGamePanelLayout);
        quickGamePanelLayout.setHorizontalGroup(
            quickGamePanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, quickGamePanelLayout.createSequentialGroup()
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(quickGameGeneralPanel, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(33, 33, 33))
        );
        quickGamePanelLayout.setVerticalGroup(
            quickGamePanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(quickGamePanelLayout.createSequentialGroup()
                .addContainerGap()
                .addComponent(quickGameGeneralPanel, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addContainerGap())
        );

        quickGRoundSelectPanel.setPreferredSize(new java.awt.Dimension(1201, 777));

        quickGRoundSelectTitleLabel.setFont(new java.awt.Font("Arial Black", 0, 36)); // NOI18N
        quickGRoundSelectTitleLabel.setText("ΕΠΙΛΕΞΤΕ ΑΡΙΘΜΟ ΓΥΡΩΝ");

        javax.swing.GroupLayout quickGRoundSelectTitlePanelLayout = new javax.swing.GroupLayout(quickGRoundSelectTitlePanel);
        quickGRoundSelectTitlePanel.setLayout(quickGRoundSelectTitlePanelLayout);
        quickGRoundSelectTitlePanelLayout.setHorizontalGroup(
            quickGRoundSelectTitlePanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(quickGRoundSelectTitlePanelLayout.createSequentialGroup()
                .addGap(106, 106, 106)
                .addComponent(quickGRoundSelectTitleLabel)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );
        quickGRoundSelectTitlePanelLayout.setVerticalGroup(
            quickGRoundSelectTitlePanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, quickGRoundSelectTitlePanelLayout.createSequentialGroup()
                .addContainerGap(25, Short.MAX_VALUE)
                .addComponent(quickGRoundSelectTitleLabel, javax.swing.GroupLayout.PREFERRED_SIZE, 64, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap())
        );

        quickGRoundSelectNoOfRLabel.setFont(new java.awt.Font("Arial", 2, 36)); // NOI18N
        quickGRoundSelectNoOfRLabel.setText("ΑΡΙΘΜΟΣ ΓΥΡΩΝ:");
        quickGRoundSelectNoOfRLabel.setBorder(javax.swing.BorderFactory.createBevelBorder(javax.swing.border.BevelBorder.RAISED));

        quickGRoundSelectRadioBtn1.setFont(new java.awt.Font("Arial", 0, 36)); // NOI18N
        quickGRoundSelectRadioBtn1.setText("1");
        quickGRoundSelectRadioBtn1.setBorder(javax.swing.BorderFactory.createBevelBorder(javax.swing.border.BevelBorder.RAISED));
        quickGRoundSelectRadioBtn1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                quickGRoundSelectRadioBtn1ActionPerformed(evt);
            }
        });

        quickGRoundSelectRadioBtn2.setFont(new java.awt.Font("Arial", 0, 36)); // NOI18N
        quickGRoundSelectRadioBtn2.setText("2");
        quickGRoundSelectRadioBtn2.setBorder(javax.swing.BorderFactory.createBevelBorder(javax.swing.border.BevelBorder.RAISED));
        quickGRoundSelectRadioBtn2.setPreferredSize(new java.awt.Dimension(45, 51));
        quickGRoundSelectRadioBtn2.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                quickGRoundSelectRadioBtn2ActionPerformed(evt);
            }
        });

        quickGRoundSelectRadioBtn3.setFont(new java.awt.Font("Arial", 0, 36)); // NOI18N
        quickGRoundSelectRadioBtn3.setText("5");
        quickGRoundSelectRadioBtn3.setBorder(javax.swing.BorderFactory.createBevelBorder(javax.swing.border.BevelBorder.RAISED));
        quickGRoundSelectRadioBtn3.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                quickGRoundSelectRadioBtn3ActionPerformed(evt);
            }
        });

        quickGRoundSelectRadioBtn4.setFont(new java.awt.Font("Arial", 0, 36)); // NOI18N
        quickGRoundSelectRadioBtn4.setText("3");
        quickGRoundSelectRadioBtn4.setBorder(javax.swing.BorderFactory.createBevelBorder(javax.swing.border.BevelBorder.RAISED));
        quickGRoundSelectRadioBtn4.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                quickGRoundSelectRadioBtn4ActionPerformed(evt);
            }
        });

        quickGRoundSelectRadioBtn5.setFont(new java.awt.Font("Arial", 0, 36)); // NOI18N
        quickGRoundSelectRadioBtn5.setText("4");
        quickGRoundSelectRadioBtn5.setBorder(javax.swing.BorderFactory.createBevelBorder(javax.swing.border.BevelBorder.RAISED));
        quickGRoundSelectRadioBtn5.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                quickGRoundSelectRadioBtn5ActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout quickGRoundSelectCheckPanelLayout = new javax.swing.GroupLayout(quickGRoundSelectCheckPanel);
        quickGRoundSelectCheckPanel.setLayout(quickGRoundSelectCheckPanelLayout);
        quickGRoundSelectCheckPanelLayout.setHorizontalGroup(
            quickGRoundSelectCheckPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(quickGRoundSelectCheckPanelLayout.createSequentialGroup()
                .addContainerGap()
                .addComponent(quickGRoundSelectNoOfRLabel, javax.swing.GroupLayout.PREFERRED_SIZE, 333, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(16, 16, 16)
                .addComponent(quickGRoundSelectRadioBtn1, javax.swing.GroupLayout.PREFERRED_SIZE, 65, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(10, 10, 10)
                .addComponent(quickGRoundSelectRadioBtn2, javax.swing.GroupLayout.PREFERRED_SIZE, 65, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18)
                .addComponent(quickGRoundSelectRadioBtn4, javax.swing.GroupLayout.PREFERRED_SIZE, 65, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(quickGRoundSelectRadioBtn5, javax.swing.GroupLayout.PREFERRED_SIZE, 65, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(quickGRoundSelectRadioBtn3, javax.swing.GroupLayout.PREFERRED_SIZE, 65, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(114, Short.MAX_VALUE))
        );
        quickGRoundSelectCheckPanelLayout.setVerticalGroup(
            quickGRoundSelectCheckPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(quickGRoundSelectCheckPanelLayout.createSequentialGroup()
                .addGap(122, 122, 122)
                .addGroup(quickGRoundSelectCheckPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(quickGRoundSelectNoOfRLabel, javax.swing.GroupLayout.PREFERRED_SIZE, 61, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(quickGRoundSelectRadioBtn1, javax.swing.GroupLayout.PREFERRED_SIZE, 33, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(quickGRoundSelectRadioBtn2, javax.swing.GroupLayout.PREFERRED_SIZE, 33, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(quickGRoundSelectRadioBtn4, javax.swing.GroupLayout.PREFERRED_SIZE, 33, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(quickGRoundSelectRadioBtn3, javax.swing.GroupLayout.PREFERRED_SIZE, 33, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(quickGRoundSelectRadioBtn5, javax.swing.GroupLayout.PREFERRED_SIZE, 33, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addContainerGap(231, Short.MAX_VALUE))
        );

        javax.swing.GroupLayout quickGRoundSelectGeneralPanelLayout = new javax.swing.GroupLayout(quickGRoundSelectGeneralPanel);
        quickGRoundSelectGeneralPanel.setLayout(quickGRoundSelectGeneralPanelLayout);
        quickGRoundSelectGeneralPanelLayout.setHorizontalGroup(
            quickGRoundSelectGeneralPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(quickGRoundSelectGeneralPanelLayout.createSequentialGroup()
                .addGap(185, 185, 185)
                .addGroup(quickGRoundSelectGeneralPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                    .addComponent(quickGRoundSelectTitlePanel, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(quickGRoundSelectCheckPanel, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                .addContainerGap(150, Short.MAX_VALUE))
        );
        quickGRoundSelectGeneralPanelLayout.setVerticalGroup(
            quickGRoundSelectGeneralPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(quickGRoundSelectGeneralPanelLayout.createSequentialGroup()
                .addGap(28, 28, 28)
                .addComponent(quickGRoundSelectTitlePanel, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(85, 85, 85)
                .addComponent(quickGRoundSelectCheckPanel, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(128, Short.MAX_VALUE))
        );

        javax.swing.GroupLayout quickGRoundSelectPanelLayout = new javax.swing.GroupLayout(quickGRoundSelectPanel);
        quickGRoundSelectPanel.setLayout(quickGRoundSelectPanelLayout);
        quickGRoundSelectPanelLayout.setHorizontalGroup(
            quickGRoundSelectPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(quickGRoundSelectPanelLayout.createSequentialGroup()
                .addContainerGap()
                .addComponent(quickGRoundSelectGeneralPanel, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addContainerGap())
        );
        quickGRoundSelectPanelLayout.setVerticalGroup(
            quickGRoundSelectPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, quickGRoundSelectPanelLayout.createSequentialGroup()
                .addContainerGap()
                .addComponent(quickGRoundSelectGeneralPanel, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addContainerGap())
        );

        modeCatSelPanel.setPreferredSize(new java.awt.Dimension(1201, 777));

        modeCatSelTitleLabel.setFont(new java.awt.Font("Arial Black", 0, 36)); // NOI18N
        modeCatSelTitleLabel.setText("ΕΠΙΛΟΓΗ MODE ΚΑΙ ΚΑΤΗΓΟΡΙΑΣ");

        javax.swing.GroupLayout modeCatSelTitlePanelLayout = new javax.swing.GroupLayout(modeCatSelTitlePanel);
        modeCatSelTitlePanel.setLayout(modeCatSelTitlePanelLayout);
        modeCatSelTitlePanelLayout.setHorizontalGroup(
            modeCatSelTitlePanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(modeCatSelTitlePanelLayout.createSequentialGroup()
                .addGap(118, 118, 118)
                .addComponent(modeCatSelTitleLabel)
                .addContainerGap(131, Short.MAX_VALUE))
        );
        modeCatSelTitlePanelLayout.setVerticalGroup(
            modeCatSelTitlePanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(modeCatSelTitlePanelLayout.createSequentialGroup()
                .addContainerGap()
                .addComponent(modeCatSelTitleLabel, javax.swing.GroupLayout.PREFERRED_SIZE, 54, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(35, Short.MAX_VALUE))
        );

        modeCatSelModeLabel.setFont(new java.awt.Font("Arial", 2, 36)); // NOI18N
        modeCatSelModeLabel.setText("ΕΠΙΛΟΓΗ MODE:");

        modeCatSelModeBtn1.setFont(new java.awt.Font("Arial", 0, 36)); // NOI18N
        modeCatSelModeBtn1.setText("Time Attack");

        modeCatSelModeBtn2.setFont(new java.awt.Font("Arial", 0, 36)); // NOI18N
        modeCatSelModeBtn2.setText("One Minute Question");

        modeCatSelModeBtn3.setFont(new java.awt.Font("Arial", 0, 36)); // NOI18N
        modeCatSelModeBtn3.setText("Elevator ");

        modeCatSelModeBtn4.setFont(new java.awt.Font("Arial", 0, 36)); // NOI18N
        modeCatSelModeBtn4.setText("Bomb");

        modeCatSelModeBtn5.setFont(new java.awt.Font("Arial", 0, 36)); // NOI18N
        modeCatSelModeBtn5.setText("Survival");

        modeCatSelModeBtn6.setFont(new java.awt.Font("Arial", 0, 36)); // NOI18N
        modeCatSelModeBtn6.setText("Fight To Five");

        javax.swing.GroupLayout modeCatSelModePanelLayout = new javax.swing.GroupLayout(modeCatSelModePanel);
        modeCatSelModePanel.setLayout(modeCatSelModePanelLayout);
        modeCatSelModePanelLayout.setHorizontalGroup(
            modeCatSelModePanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(modeCatSelModePanelLayout.createSequentialGroup()
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(modeCatSelModeLabel, javax.swing.GroupLayout.PREFERRED_SIZE, 287, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(150, 150, 150))
            .addGroup(modeCatSelModePanelLayout.createSequentialGroup()
                .addGap(179, 179, 179)
                .addGroup(modeCatSelModePanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                    .addComponent(modeCatSelModeBtn1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(modeCatSelModeBtn2, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(modeCatSelModeBtn3, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(modeCatSelModeBtn4, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(modeCatSelModeBtn5, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(modeCatSelModeBtn6, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                .addContainerGap(53, Short.MAX_VALUE))
        );
        modeCatSelModePanelLayout.setVerticalGroup(
            modeCatSelModePanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(modeCatSelModePanelLayout.createSequentialGroup()
                .addGap(66, 66, 66)
                .addComponent(modeCatSelModeLabel, javax.swing.GroupLayout.PREFERRED_SIZE, 43, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(53, 53, 53)
                .addComponent(modeCatSelModeBtn1, javax.swing.GroupLayout.PREFERRED_SIZE, 43, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(36, 36, 36)
                .addComponent(modeCatSelModeBtn3, javax.swing.GroupLayout.PREFERRED_SIZE, 43, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(27, 27, 27)
                .addComponent(modeCatSelModeBtn2, javax.swing.GroupLayout.PREFERRED_SIZE, 43, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(27, 27, 27)
                .addComponent(modeCatSelModeBtn4, javax.swing.GroupLayout.PREFERRED_SIZE, 43, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(27, 27, 27)
                .addComponent(modeCatSelModeBtn5, javax.swing.GroupLayout.PREFERRED_SIZE, 43, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 26, Short.MAX_VALUE)
                .addComponent(modeCatSelModeBtn6, javax.swing.GroupLayout.PREFERRED_SIZE, 43, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(24, 24, 24))
        );

        modeCatSelCatLabel.setFont(new java.awt.Font("Arial", 2, 36)); // NOI18N
        modeCatSelCatLabel.setText("ΕΠΙΛΟΓΗ ΚΑΤΗΓΟΡΙΑΣ:");
        modeCatSelCatLabel.setPreferredSize(new java.awt.Dimension(287, 43));

        modeCatSelCatBtn1.setFont(new java.awt.Font("Arial", 0, 30)); // NOI18N
        modeCatSelCatBtn1.setText("Γεωγραφία");

        modeCatSelCatBtn2.setFont(new java.awt.Font("Arial", 0, 30)); // NOI18N
        modeCatSelCatBtn2.setText("Μουσική");

        modeCatSelCatBtn3.setFont(new java.awt.Font("Arial", 0, 30)); // NOI18N
        modeCatSelCatBtn3.setText("Κατηγορία 3");

        modeCatSelCatBtn4.setFont(new java.awt.Font("Arial", 0, 30)); // NOI18N
        modeCatSelCatBtn4.setText("Κατηγορία 4");

        modeCatSelCatBtn5.setFont(new java.awt.Font("Arial", 0, 30)); // NOI18N
        modeCatSelCatBtn5.setText("Πολιτική");

        modeCatSelCatBtn6.setFont(new java.awt.Font("Arial", 0, 30)); // NOI18N
        modeCatSelCatBtn6.setText("Αθλητικά");

        modeCatSelCatBtn7.setFont(new java.awt.Font("Arial", 0, 30)); // NOI18N
        modeCatSelCatBtn7.setText("Κατηγορία 7");

        modeCatSelCatBtn8.setFont(new java.awt.Font("Arial", 0, 30)); // NOI18N
        modeCatSelCatBtn8.setText("Κατηγορία 8");

        modeCatSelNextBtn.setFont(new java.awt.Font("Arial", 0, 14)); // NOI18N
        modeCatSelNextBtn.setText("ΕΠΟΜΕΝΟΣ\n  ΓΥΡΟΣ");

        javax.swing.GroupLayout modeCatSelCatPanelLayout = new javax.swing.GroupLayout(modeCatSelCatPanel);
        modeCatSelCatPanel.setLayout(modeCatSelCatPanelLayout);
        modeCatSelCatPanelLayout.setHorizontalGroup(
            modeCatSelCatPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, modeCatSelCatPanelLayout.createSequentialGroup()
                .addGap(71, 71, 71)
                .addComponent(modeCatSelCatLabel, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addGap(70, 70, 70))
            .addGroup(modeCatSelCatPanelLayout.createSequentialGroup()
                .addGap(109, 109, 109)
                .addGroup(modeCatSelCatPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(modeCatSelCatBtn6, javax.swing.GroupLayout.PREFERRED_SIZE, 326, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(modeCatSelCatBtn5, javax.swing.GroupLayout.PREFERRED_SIZE, 326, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(modeCatSelCatBtn4, javax.swing.GroupLayout.PREFERRED_SIZE, 326, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(modeCatSelCatBtn3, javax.swing.GroupLayout.PREFERRED_SIZE, 326, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(modeCatSelCatBtn2, javax.swing.GroupLayout.PREFERRED_SIZE, 326, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(modeCatSelCatBtn1, javax.swing.GroupLayout.PREFERRED_SIZE, 326, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addGroup(modeCatSelCatPanelLayout.createSequentialGroup()
                        .addGroup(modeCatSelCatPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(modeCatSelCatBtn8, javax.swing.GroupLayout.PREFERRED_SIZE, 326, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(modeCatSelCatBtn7, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.PREFERRED_SIZE, 326, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(modeCatSelNextBtn, javax.swing.GroupLayout.PREFERRED_SIZE, 171, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addGap(0, 0, Short.MAX_VALUE))
        );
        modeCatSelCatPanelLayout.setVerticalGroup(
            modeCatSelCatPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(modeCatSelCatPanelLayout.createSequentialGroup()
                .addGap(66, 66, 66)
                .addComponent(modeCatSelCatLabel, javax.swing.GroupLayout.PREFERRED_SIZE, 43, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGroup(modeCatSelCatPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, modeCatSelCatPanelLayout.createSequentialGroup()
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addComponent(modeCatSelNextBtn, javax.swing.GroupLayout.PREFERRED_SIZE, 93, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(modeCatSelCatPanelLayout.createSequentialGroup()
                        .addGap(29, 29, 29)
                        .addComponent(modeCatSelCatBtn1, javax.swing.GroupLayout.PREFERRED_SIZE, 36, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(18, 18, 18)
                        .addComponent(modeCatSelCatBtn2, javax.swing.GroupLayout.PREFERRED_SIZE, 36, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(18, 18, 18)
                        .addComponent(modeCatSelCatBtn3, javax.swing.GroupLayout.PREFERRED_SIZE, 36, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(18, 18, 18)
                        .addComponent(modeCatSelCatBtn4, javax.swing.GroupLayout.PREFERRED_SIZE, 36, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(18, 18, 18)
                        .addComponent(modeCatSelCatBtn5, javax.swing.GroupLayout.PREFERRED_SIZE, 36, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(18, 18, 18)
                        .addComponent(modeCatSelCatBtn6, javax.swing.GroupLayout.PREFERRED_SIZE, 36, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addComponent(modeCatSelCatBtn7, javax.swing.GroupLayout.PREFERRED_SIZE, 36, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(18, 18, 18)
                        .addComponent(modeCatSelCatBtn8, javax.swing.GroupLayout.PREFERRED_SIZE, 36, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(20, 20, 20))))
        );

        javax.swing.GroupLayout modeCatSelMCPanelLayout = new javax.swing.GroupLayout(modeCatSelMCPanel);
        modeCatSelMCPanel.setLayout(modeCatSelMCPanelLayout);
        modeCatSelMCPanelLayout.setHorizontalGroup(
            modeCatSelMCPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(modeCatSelMCPanelLayout.createSequentialGroup()
                .addContainerGap()
                .addComponent(modeCatSelModePanel, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(modeCatSelCatPanel, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );
        modeCatSelMCPanelLayout.setVerticalGroup(
            modeCatSelMCPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(modeCatSelMCPanelLayout.createSequentialGroup()
                .addContainerGap()
                .addGroup(modeCatSelMCPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(modeCatSelModePanel, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addGroup(modeCatSelMCPanelLayout.createSequentialGroup()
                        .addComponent(modeCatSelCatPanel, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addContainerGap())))
        );

        javax.swing.GroupLayout modeCatSelGeneralPanelLayout = new javax.swing.GroupLayout(modeCatSelGeneralPanel);
        modeCatSelGeneralPanel.setLayout(modeCatSelGeneralPanelLayout);
        modeCatSelGeneralPanelLayout.setHorizontalGroup(
            modeCatSelGeneralPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(modeCatSelGeneralPanelLayout.createSequentialGroup()
                .addGap(127, 127, 127)
                .addComponent(modeCatSelTitlePanel, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
            .addGroup(modeCatSelGeneralPanelLayout.createSequentialGroup()
                .addContainerGap()
                .addComponent(modeCatSelMCPanel, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addContainerGap())
        );
        modeCatSelGeneralPanelLayout.setVerticalGroup(
            modeCatSelGeneralPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(modeCatSelGeneralPanelLayout.createSequentialGroup()
                .addGap(40, 40, 40)
                .addComponent(modeCatSelTitlePanel, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(modeCatSelMCPanel, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addContainerGap())
        );

        javax.swing.GroupLayout modeCatSelPanelLayout = new javax.swing.GroupLayout(modeCatSelPanel);
        modeCatSelPanel.setLayout(modeCatSelPanelLayout);
        modeCatSelPanelLayout.setHorizontalGroup(
            modeCatSelPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(modeCatSelPanelLayout.createSequentialGroup()
                .addContainerGap()
                .addComponent(modeCatSelGeneralPanel, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addContainerGap())
        );
        modeCatSelPanelLayout.setVerticalGroup(
            modeCatSelPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(modeCatSelPanelLayout.createSequentialGroup()
                .addContainerGap()
                .addComponent(modeCatSelGeneralPanel, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addContainerGap())
        );

        scoreTablePanel.setPreferredSize(new java.awt.Dimension(1201, 777));

        scoreTableTitleLabel.setFont(new java.awt.Font("Arial Black", 0, 36)); // NOI18N
        scoreTableTitleLabel.setText("ΒΑΘΜΟΛΟΓΙΑ");

        javax.swing.GroupLayout scoreTableTitlePanelLayout = new javax.swing.GroupLayout(scoreTableTitlePanel);
        scoreTableTitlePanel.setLayout(scoreTableTitlePanelLayout);
        scoreTableTitlePanelLayout.setHorizontalGroup(
            scoreTableTitlePanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(scoreTableTitlePanelLayout.createSequentialGroup()
                .addGap(181, 181, 181)
                .addComponent(scoreTableTitleLabel)
                .addContainerGap(237, Short.MAX_VALUE))
        );
        scoreTableTitlePanelLayout.setVerticalGroup(
            scoreTableTitlePanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(scoreTableTitlePanelLayout.createSequentialGroup()
                .addContainerGap()
                .addComponent(scoreTableTitleLabel, javax.swing.GroupLayout.PREFERRED_SIZE, 64, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(25, Short.MAX_VALUE))
        );

        scoreTableP1NameLabel.setFont(new java.awt.Font("Arial", 2, 24)); // NOI18N
        scoreTableP1NameLabel.setText("KIGITHIGAS");

        scoreTableP1PointsLabel.setFont(new java.awt.Font("Arial", 0, 24)); // NOI18N
        scoreTableP1PointsLabel.setText("10000");

        javax.swing.GroupLayout scoreTableP1PanelLayout = new javax.swing.GroupLayout(scoreTableP1Panel);
        scoreTableP1Panel.setLayout(scoreTableP1PanelLayout);
        scoreTableP1PanelLayout.setHorizontalGroup(
            scoreTableP1PanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(scoreTableP1PanelLayout.createSequentialGroup()
                .addGap(137, 137, 137)
                .addComponent(scoreTableP1NameLabel)
                .addGap(72, 72, 72)
                .addComponent(scoreTableP1PointsLabel)
                .addContainerGap(190, Short.MAX_VALUE))
        );
        scoreTableP1PanelLayout.setVerticalGroup(
            scoreTableP1PanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(scoreTableP1PanelLayout.createSequentialGroup()
                .addContainerGap()
                .addGroup(scoreTableP1PanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(scoreTableP1NameLabel, javax.swing.GroupLayout.DEFAULT_SIZE, 38, Short.MAX_VALUE)
                    .addComponent(scoreTableP1PointsLabel, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                .addContainerGap())
        );

        scoreTableP2NameLabel.setFont(new java.awt.Font("Arial", 2, 24)); // NOI18N
        scoreTableP2NameLabel.setText("KIGITHIGAS");

        scoreTableP2PointsLabel.setFont(new java.awt.Font("Arial", 0, 24)); // NOI18N
        scoreTableP2PointsLabel.setText("10000");

        javax.swing.GroupLayout scoreTableP2PanelLayout = new javax.swing.GroupLayout(scoreTableP2Panel);
        scoreTableP2Panel.setLayout(scoreTableP2PanelLayout);
        scoreTableP2PanelLayout.setHorizontalGroup(
            scoreTableP2PanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(scoreTableP2PanelLayout.createSequentialGroup()
                .addGap(137, 137, 137)
                .addComponent(scoreTableP2NameLabel)
                .addGap(72, 72, 72)
                .addComponent(scoreTableP2PointsLabel)
                .addContainerGap(190, Short.MAX_VALUE))
        );
        scoreTableP2PanelLayout.setVerticalGroup(
            scoreTableP2PanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(scoreTableP2PanelLayout.createSequentialGroup()
                .addContainerGap()
                .addGroup(scoreTableP2PanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(scoreTableP2NameLabel, javax.swing.GroupLayout.DEFAULT_SIZE, 38, Short.MAX_VALUE)
                    .addComponent(scoreTableP2PointsLabel, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                .addContainerGap())
        );

        scoreTableP3NameLabel.setFont(new java.awt.Font("Arial", 2, 24)); // NOI18N
        scoreTableP3NameLabel.setText("KIGITHIGAS");

        scoreTableP3PointsLabel.setFont(new java.awt.Font("Arial", 0, 24)); // NOI18N
        scoreTableP3PointsLabel.setText("10000");

        javax.swing.GroupLayout scoreTableP3PanelLayout = new javax.swing.GroupLayout(scoreTableP3Panel);
        scoreTableP3Panel.setLayout(scoreTableP3PanelLayout);
        scoreTableP3PanelLayout.setHorizontalGroup(
            scoreTableP3PanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(scoreTableP3PanelLayout.createSequentialGroup()
                .addGap(137, 137, 137)
                .addComponent(scoreTableP3NameLabel)
                .addGap(72, 72, 72)
                .addComponent(scoreTableP3PointsLabel)
                .addContainerGap(190, Short.MAX_VALUE))
        );
        scoreTableP3PanelLayout.setVerticalGroup(
            scoreTableP3PanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(scoreTableP3PanelLayout.createSequentialGroup()
                .addContainerGap()
                .addGroup(scoreTableP3PanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(scoreTableP3NameLabel, javax.swing.GroupLayout.DEFAULT_SIZE, 38, Short.MAX_VALUE)
                    .addComponent(scoreTableP3PointsLabel, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                .addContainerGap())
        );

        scoreTableP4NameLabel.setFont(new java.awt.Font("Arial", 2, 24)); // NOI18N
        scoreTableP4NameLabel.setText("KIGITHIGAS");

        scoreTableP4PointsLabel.setFont(new java.awt.Font("Arial", 0, 24)); // NOI18N
        scoreTableP4PointsLabel.setText("10000");

        javax.swing.GroupLayout scoreTableP4PanelLayout = new javax.swing.GroupLayout(scoreTableP4Panel);
        scoreTableP4Panel.setLayout(scoreTableP4PanelLayout);
        scoreTableP4PanelLayout.setHorizontalGroup(
            scoreTableP4PanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(scoreTableP4PanelLayout.createSequentialGroup()
                .addGap(137, 137, 137)
                .addComponent(scoreTableP4NameLabel)
                .addGap(72, 72, 72)
                .addComponent(scoreTableP4PointsLabel)
                .addContainerGap(190, Short.MAX_VALUE))
        );
        scoreTableP4PanelLayout.setVerticalGroup(
            scoreTableP4PanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(scoreTableP4PanelLayout.createSequentialGroup()
                .addContainerGap()
                .addGroup(scoreTableP4PanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(scoreTableP4NameLabel, javax.swing.GroupLayout.DEFAULT_SIZE, 38, Short.MAX_VALUE)
                    .addComponent(scoreTableP4PointsLabel, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                .addContainerGap())
        );

        scoreTableNextBtn.setFont(new java.awt.Font("Arial", 0, 24)); // NOI18N
        scoreTableNextBtn.setText("ΣΥΝΕΧΕΙΑ");

        javax.swing.GroupLayout scoreTableInfoPanelLayout = new javax.swing.GroupLayout(scoreTableInfoPanel);
        scoreTableInfoPanel.setLayout(scoreTableInfoPanelLayout);
        scoreTableInfoPanelLayout.setHorizontalGroup(
            scoreTableInfoPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(scoreTableInfoPanelLayout.createSequentialGroup()
                .addContainerGap(190, Short.MAX_VALUE)
                .addGroup(scoreTableInfoPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, scoreTableInfoPanelLayout.createSequentialGroup()
                        .addGroup(scoreTableInfoPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(scoreTableP4Panel, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(scoreTableP3Panel, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(scoreTableP2Panel, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(scoreTableP1Panel, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGap(189, 189, 189))
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, scoreTableInfoPanelLayout.createSequentialGroup()
                        .addComponent(scoreTableNextBtn, javax.swing.GroupLayout.PREFERRED_SIZE, 215, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addContainerGap())))
        );
        scoreTableInfoPanelLayout.setVerticalGroup(
            scoreTableInfoPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(scoreTableInfoPanelLayout.createSequentialGroup()
                .addGap(57, 57, 57)
                .addComponent(scoreTableP1Panel, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(30, 30, 30)
                .addComponent(scoreTableP2Panel, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(30, 30, 30)
                .addComponent(scoreTableP3Panel, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(30, 30, 30)
                .addComponent(scoreTableP4Panel, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 110, Short.MAX_VALUE)
                .addComponent(scoreTableNextBtn, javax.swing.GroupLayout.PREFERRED_SIZE, 80, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap())
        );

        javax.swing.GroupLayout scoreTableGeneralPanelLayout = new javax.swing.GroupLayout(scoreTableGeneralPanel);
        scoreTableGeneralPanel.setLayout(scoreTableGeneralPanelLayout);
        scoreTableGeneralPanelLayout.setHorizontalGroup(
            scoreTableGeneralPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, scoreTableGeneralPanelLayout.createSequentialGroup()
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(scoreTableTitlePanel, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(244, 244, 244))
            .addGroup(scoreTableGeneralPanelLayout.createSequentialGroup()
                .addGap(101, 101, 101)
                .addComponent(scoreTableInfoPanel, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(101, Short.MAX_VALUE))
        );
        scoreTableGeneralPanelLayout.setVerticalGroup(
            scoreTableGeneralPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(scoreTableGeneralPanelLayout.createSequentialGroup()
                .addGap(38, 38, 38)
                .addComponent(scoreTableTitlePanel, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18)
                .addComponent(scoreTableInfoPanel, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addContainerGap())
        );

        javax.swing.GroupLayout scoreTablePanelLayout = new javax.swing.GroupLayout(scoreTablePanel);
        scoreTablePanel.setLayout(scoreTablePanelLayout);
        scoreTablePanelLayout.setHorizontalGroup(
            scoreTablePanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(scoreTablePanelLayout.createSequentialGroup()
                .addContainerGap()
                .addComponent(scoreTableGeneralPanel, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addContainerGap())
        );
        scoreTablePanelLayout.setVerticalGroup(
            scoreTablePanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(scoreTablePanelLayout.createSequentialGroup()
                .addContainerGap()
                .addComponent(scoreTableGeneralPanel, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addContainerGap())
        );

        finalQPanel.setPreferredSize(new java.awt.Dimension(1201, 777));

        finalQTitleLabel.setFont(new java.awt.Font("Arial Black", 0, 36)); // NOI18N
        finalQTitleLabel.setText("ΤΕΛΙΚΗ ΕΡΩΤΗΣΗ");

        javax.swing.GroupLayout finalQTitlePanelLayout = new javax.swing.GroupLayout(finalQTitlePanel);
        finalQTitlePanel.setLayout(finalQTitlePanelLayout);
        finalQTitlePanelLayout.setHorizontalGroup(
            finalQTitlePanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(finalQTitlePanelLayout.createSequentialGroup()
                .addGap(216, 216, 216)
                .addComponent(finalQTitleLabel)
                .addContainerGap(314, Short.MAX_VALUE))
        );
        finalQTitlePanelLayout.setVerticalGroup(
            finalQTitlePanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(finalQTitlePanelLayout.createSequentialGroup()
                .addContainerGap()
                .addComponent(finalQTitleLabel, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addContainerGap())
        );

        finalQQuestionScrollPane.setHorizontalScrollBarPolicy(javax.swing.ScrollPaneConstants.HORIZONTAL_SCROLLBAR_NEVER);
        finalQQuestionScrollPane.setVerticalScrollBarPolicy(javax.swing.ScrollPaneConstants.VERTICAL_SCROLLBAR_NEVER);

        finalQQuestionTextArea.setColumns(20);
        finalQQuestionTextArea.setFont(new java.awt.Font("Arial", 2, 24)); // NOI18N
        finalQQuestionTextArea.setLineWrap(true);
        finalQQuestionTextArea.setRows(5);
        finalQQuestionScrollPane.setViewportView(finalQQuestionTextArea);

        finalQQuestionLabel.setFont(new java.awt.Font("Arial", 0, 24)); // NOI18N
        finalQQuestionLabel.setText("ΕΡΩΤΗΣΗ ΓΙΑ ΤΟΝ ΠΑΙΚΤΗ:");

        finalQPlayerLabel.setFont(new java.awt.Font("Arial", 2, 24)); // NOI18N

        javax.swing.GroupLayout finalQQuestionPanelLayout = new javax.swing.GroupLayout(finalQQuestionPanel);
        finalQQuestionPanel.setLayout(finalQQuestionPanelLayout);
        finalQQuestionPanelLayout.setHorizontalGroup(
            finalQQuestionPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(finalQQuestionPanelLayout.createSequentialGroup()
                .addGap(20, 20, 20)
                .addGroup(finalQQuestionPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(finalQQuestionScrollPane)
                    .addGroup(finalQQuestionPanelLayout.createSequentialGroup()
                        .addComponent(finalQQuestionLabel)
                        .addGap(18, 18, 18)
                        .addComponent(finalQPlayerLabel, javax.swing.GroupLayout.PREFERRED_SIZE, 238, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(0, 377, Short.MAX_VALUE)))
                .addContainerGap())
        );
        finalQQuestionPanelLayout.setVerticalGroup(
            finalQQuestionPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, finalQQuestionPanelLayout.createSequentialGroup()
                .addGroup(finalQQuestionPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(finalQQuestionLabel, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(finalQPlayerLabel, javax.swing.GroupLayout.PREFERRED_SIZE, 29, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(finalQQuestionScrollPane, javax.swing.GroupLayout.PREFERRED_SIZE, 90, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap())
        );

        finalQAnswerLabel.setFont(new java.awt.Font("Arial", 0, 24)); // NOI18N
        finalQAnswerLabel.setText("ΑΠΑΝΤΗΣΕΙΣ:");

        finalQAnswer1.setFont(new java.awt.Font("Arial", 0, 24)); // NOI18N

        finalQAnswer2.setFont(new java.awt.Font("Arial", 0, 24)); // NOI18N

        finalQAnswer3.setFont(new java.awt.Font("Arial", 0, 24)); // NOI18N

        finalQAnswer4.setFont(new java.awt.Font("Arial", 0, 24)); // NOI18N

        javax.swing.GroupLayout finalQAnswerPanelLayout = new javax.swing.GroupLayout(finalQAnswerPanel);
        finalQAnswerPanel.setLayout(finalQAnswerPanelLayout);
        finalQAnswerPanelLayout.setHorizontalGroup(
            finalQAnswerPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(finalQAnswerPanelLayout.createSequentialGroup()
                .addGroup(finalQAnswerPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(finalQAnswerLabel)
                    .addGroup(finalQAnswerPanelLayout.createSequentialGroup()
                        .addContainerGap()
                        .addGroup(finalQAnswerPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                            .addComponent(finalQAnswer3, javax.swing.GroupLayout.DEFAULT_SIZE, 350, Short.MAX_VALUE)
                            .addComponent(finalQAnswer1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 159, Short.MAX_VALUE)
                        .addGroup(finalQAnswerPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                            .addComponent(finalQAnswer2, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                            .addComponent(finalQAnswer4, javax.swing.GroupLayout.DEFAULT_SIZE, 350, Short.MAX_VALUE))))
                .addGap(45, 45, 45))
        );
        finalQAnswerPanelLayout.setVerticalGroup(
            finalQAnswerPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(finalQAnswerPanelLayout.createSequentialGroup()
                .addContainerGap()
                .addComponent(finalQAnswerLabel, javax.swing.GroupLayout.PREFERRED_SIZE, 36, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(29, 29, 29)
                .addGroup(finalQAnswerPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(finalQAnswer1, javax.swing.GroupLayout.PREFERRED_SIZE, 80, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(finalQAnswer2, javax.swing.GroupLayout.PREFERRED_SIZE, 80, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(64, 64, 64)
                .addGroup(finalQAnswerPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(finalQAnswer4, javax.swing.GroupLayout.PREFERRED_SIZE, 81, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(finalQAnswer3, javax.swing.GroupLayout.PREFERRED_SIZE, 81, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(114, 114, 114))
        );

        javax.swing.GroupLayout finalQGeneralPanelLayout = new javax.swing.GroupLayout(finalQGeneralPanel);
        finalQGeneralPanel.setLayout(finalQGeneralPanelLayout);
        finalQGeneralPanelLayout.setHorizontalGroup(
            finalQGeneralPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(finalQGeneralPanelLayout.createSequentialGroup()
                .addContainerGap(94, Short.MAX_VALUE)
                .addGroup(finalQGeneralPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(finalQGeneralPanelLayout.createSequentialGroup()
                        .addGap(126, 126, 126)
                        .addComponent(finalQTitlePanel, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(finalQGeneralPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                        .addComponent(finalQAnswerPanel, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addComponent(finalQQuestionPanel, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addContainerGap(102, Short.MAX_VALUE))
        );
        finalQGeneralPanelLayout.setVerticalGroup(
            finalQGeneralPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(finalQGeneralPanelLayout.createSequentialGroup()
                .addGap(37, 37, 37)
                .addComponent(finalQTitlePanel, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(79, 79, 79)
                .addComponent(finalQQuestionPanel, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(finalQAnswerPanel, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );

        javax.swing.GroupLayout finalQPanelLayout = new javax.swing.GroupLayout(finalQPanel);
        finalQPanel.setLayout(finalQPanelLayout);
        finalQPanelLayout.setHorizontalGroup(
            finalQPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, finalQPanelLayout.createSequentialGroup()
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(finalQGeneralPanel, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(33, 33, 33))
        );
        finalQPanelLayout.setVerticalGroup(
            finalQPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(finalQPanelLayout.createSequentialGroup()
                .addContainerGap()
                .addComponent(finalQGeneralPanel, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addContainerGap())
        );

        winnerPanel.setPreferredSize(new java.awt.Dimension(1201, 777));

        winnerTitleLabel.setFont(new java.awt.Font("Arial Black", 0, 36)); // NOI18N
        winnerTitleLabel.setText("ΤΕΛΙΚΗ ΒΑΘΜΟΛΟΓΙΑ");

        javax.swing.GroupLayout winnerTitlePanelLayout = new javax.swing.GroupLayout(winnerTitlePanel);
        winnerTitlePanel.setLayout(winnerTitlePanelLayout);
        winnerTitlePanelLayout.setHorizontalGroup(
            winnerTitlePanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(winnerTitlePanelLayout.createSequentialGroup()
                .addGap(181, 181, 181)
                .addComponent(winnerTitleLabel)
                .addContainerGap(237, Short.MAX_VALUE))
        );
        winnerTitlePanelLayout.setVerticalGroup(
            winnerTitlePanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(winnerTitlePanelLayout.createSequentialGroup()
                .addContainerGap()
                .addComponent(winnerTitleLabel, javax.swing.GroupLayout.PREFERRED_SIZE, 64, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(25, Short.MAX_VALUE))
        );

        winnerP1NameLabel.setFont(new java.awt.Font("Arial", 2, 24)); // NOI18N
        winnerP1NameLabel.setText("KIGITHIGAS");

        winnerP1PointsLabel.setFont(new java.awt.Font("Arial", 0, 24)); // NOI18N
        winnerP1PointsLabel.setText("10000");

        javax.swing.GroupLayout winnerP1PanelLayout = new javax.swing.GroupLayout(winnerP1Panel);
        winnerP1Panel.setLayout(winnerP1PanelLayout);
        winnerP1PanelLayout.setHorizontalGroup(
            winnerP1PanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(winnerP1PanelLayout.createSequentialGroup()
                .addGap(86, 86, 86)
                .addComponent(winnerP1NameLabel)
                .addGap(69, 69, 69)
                .addComponent(winnerP1PointsLabel)
                .addContainerGap(176, Short.MAX_VALUE))
        );
        winnerP1PanelLayout.setVerticalGroup(
            winnerP1PanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(winnerP1PanelLayout.createSequentialGroup()
                .addContainerGap()
                .addGroup(winnerP1PanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(winnerP1NameLabel, javax.swing.GroupLayout.DEFAULT_SIZE, 38, Short.MAX_VALUE)
                    .addComponent(winnerP1PointsLabel, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                .addContainerGap())
        );

        winnerP2NameLabel.setFont(new java.awt.Font("Arial", 2, 24)); // NOI18N
        winnerP2NameLabel.setText("KIGITHIGAS");

        winnerP2PointsLabel.setFont(new java.awt.Font("Arial", 0, 24)); // NOI18N
        winnerP2PointsLabel.setText("10000");

        javax.swing.GroupLayout winnerP2PanelLayout = new javax.swing.GroupLayout(winnerP2Panel);
        winnerP2Panel.setLayout(winnerP2PanelLayout);
        winnerP2PanelLayout.setHorizontalGroup(
            winnerP2PanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(winnerP2PanelLayout.createSequentialGroup()
                .addGap(137, 137, 137)
                .addComponent(winnerP2NameLabel)
                .addGap(72, 72, 72)
                .addComponent(winnerP2PointsLabel)
                .addContainerGap(190, Short.MAX_VALUE))
        );
        winnerP2PanelLayout.setVerticalGroup(
            winnerP2PanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(winnerP2PanelLayout.createSequentialGroup()
                .addContainerGap()
                .addGroup(winnerP2PanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(winnerP2NameLabel, javax.swing.GroupLayout.DEFAULT_SIZE, 38, Short.MAX_VALUE)
                    .addComponent(winnerP2PointsLabel, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                .addContainerGap())
        );

        winnerP3NameLabel.setFont(new java.awt.Font("Arial", 2, 24)); // NOI18N
        winnerP3NameLabel.setText("KIGITHIGAS");

        winnerP3PointsLabel.setFont(new java.awt.Font("Arial", 0, 24)); // NOI18N
        winnerP3PointsLabel.setText("10000");

        javax.swing.GroupLayout winnerP3PanelLayout = new javax.swing.GroupLayout(winnerP3Panel);
        winnerP3Panel.setLayout(winnerP3PanelLayout);
        winnerP3PanelLayout.setHorizontalGroup(
            winnerP3PanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(winnerP3PanelLayout.createSequentialGroup()
                .addGap(137, 137, 137)
                .addComponent(winnerP3NameLabel)
                .addGap(72, 72, 72)
                .addComponent(winnerP3PointsLabel)
                .addContainerGap(190, Short.MAX_VALUE))
        );
        winnerP3PanelLayout.setVerticalGroup(
            winnerP3PanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(winnerP3PanelLayout.createSequentialGroup()
                .addContainerGap()
                .addGroup(winnerP3PanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(winnerP3NameLabel, javax.swing.GroupLayout.DEFAULT_SIZE, 38, Short.MAX_VALUE)
                    .addComponent(winnerP3PointsLabel, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                .addContainerGap())
        );

        winnerP4NameLabel.setFont(new java.awt.Font("Arial", 2, 24)); // NOI18N
        winnerP4NameLabel.setText("KIGITHIGAS");

        winnerP4PointsLabel.setFont(new java.awt.Font("Arial", 0, 24)); // NOI18N
        winnerP4PointsLabel.setText("10000");

        javax.swing.GroupLayout winnerP4PanelLayout = new javax.swing.GroupLayout(winnerP4Panel);
        winnerP4Panel.setLayout(winnerP4PanelLayout);
        winnerP4PanelLayout.setHorizontalGroup(
            winnerP4PanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(winnerP4PanelLayout.createSequentialGroup()
                .addGap(137, 137, 137)
                .addComponent(winnerP4NameLabel)
                .addGap(72, 72, 72)
                .addComponent(winnerP4PointsLabel)
                .addContainerGap(190, Short.MAX_VALUE))
        );
        winnerP4PanelLayout.setVerticalGroup(
            winnerP4PanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(winnerP4PanelLayout.createSequentialGroup()
                .addContainerGap()
                .addGroup(winnerP4PanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(winnerP4NameLabel, javax.swing.GroupLayout.DEFAULT_SIZE, 38, Short.MAX_VALUE)
                    .addComponent(winnerP4PointsLabel, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                .addContainerGap())
        );

        winnerMMenutBtn.setFont(new java.awt.Font("Arial", 0, 24)); // NOI18N
        winnerMMenutBtn.setText("ΑΡΧΙΚΟ ΜΕΝΟΥ");

        winnerLabel.setFont(new java.awt.Font("Arial", 0, 36)); // NOI18N
        winnerLabel.setText("ΝΙΚΗΤΗΣ");
        winnerLabel.setBorder(new javax.swing.border.SoftBevelBorder(javax.swing.border.BevelBorder.RAISED));

        javax.swing.GroupLayout winnerInfoPanelLayout = new javax.swing.GroupLayout(winnerInfoPanel);
        winnerInfoPanel.setLayout(winnerInfoPanelLayout);
        winnerInfoPanelLayout.setHorizontalGroup(
            winnerInfoPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(winnerInfoPanelLayout.createSequentialGroup()
                .addContainerGap(190, Short.MAX_VALUE)
                .addGroup(winnerInfoPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, winnerInfoPanelLayout.createSequentialGroup()
                        .addGroup(winnerInfoPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(winnerP4Panel, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(winnerP3Panel, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(winnerP2Panel, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGap(189, 189, 189))
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, winnerInfoPanelLayout.createSequentialGroup()
                        .addComponent(winnerMMenutBtn, javax.swing.GroupLayout.PREFERRED_SIZE, 215, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addContainerGap())))
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, winnerInfoPanelLayout.createSequentialGroup()
                .addGap(81, 81, 81)
                .addComponent(winnerLabel)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(winnerP1Panel, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(0, 0, Short.MAX_VALUE))
        );
        winnerInfoPanelLayout.setVerticalGroup(
            winnerInfoPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(winnerInfoPanelLayout.createSequentialGroup()
                .addGap(57, 57, 57)
                .addGroup(winnerInfoPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                    .addComponent(winnerP1Panel, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(winnerLabel, javax.swing.GroupLayout.PREFERRED_SIZE, 50, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(30, 30, 30)
                .addComponent(winnerP2Panel, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(30, 30, 30)
                .addComponent(winnerP3Panel, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(30, 30, 30)
                .addComponent(winnerP4Panel, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 110, Short.MAX_VALUE)
                .addComponent(winnerMMenutBtn, javax.swing.GroupLayout.PREFERRED_SIZE, 80, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap())
        );

        javax.swing.GroupLayout winnerGeneralPanelLayout = new javax.swing.GroupLayout(winnerGeneralPanel);
        winnerGeneralPanel.setLayout(winnerGeneralPanelLayout);
        winnerGeneralPanelLayout.setHorizontalGroup(
            winnerGeneralPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(winnerGeneralPanelLayout.createSequentialGroup()
                .addGap(101, 101, 101)
                .addComponent(winnerInfoPanel, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(101, Short.MAX_VALUE))
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, winnerGeneralPanelLayout.createSequentialGroup()
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(winnerTitlePanel, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(140, 140, 140))
        );
        winnerGeneralPanelLayout.setVerticalGroup(
            winnerGeneralPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(winnerGeneralPanelLayout.createSequentialGroup()
                .addGap(45, 45, 45)
                .addComponent(winnerTitlePanel, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(winnerInfoPanel, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addContainerGap())
        );

        javax.swing.GroupLayout winnerPanelLayout = new javax.swing.GroupLayout(winnerPanel);
        winnerPanel.setLayout(winnerPanelLayout);
        winnerPanelLayout.setHorizontalGroup(
            winnerPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(winnerPanelLayout.createSequentialGroup()
                .addContainerGap()
                .addComponent(winnerGeneralPanel, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addContainerGap())
        );
        winnerPanelLayout.setVerticalGroup(
            winnerPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(winnerPanelLayout.createSequentialGroup()
                .addContainerGap()
                .addComponent(winnerGeneralPanel, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addContainerGap())
        );

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(openPanel, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
            .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                .addGroup(layout.createSequentialGroup()
                    .addGap(0, 0, Short.MAX_VALUE)
                    .addComponent(mainMenuPanel, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addGap(0, 0, Short.MAX_VALUE)))
            .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                .addGroup(layout.createSequentialGroup()
                    .addGap(0, 0, Short.MAX_VALUE)
                    .addComponent(playerNamePanel, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addGap(0, 0, Short.MAX_VALUE)))
            .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                .addGroup(layout.createSequentialGroup()
                    .addGap(0, 0, Short.MAX_VALUE)
                    .addComponent(classicModePanel, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addGap(0, 0, Short.MAX_VALUE)))
            .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                .addGroup(layout.createSequentialGroup()
                    .addGap(0, 0, Short.MAX_VALUE)
                    .addComponent(timeattackModePanel, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addGap(0, 0, Short.MAX_VALUE)))
            .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                .addGroup(layout.createSequentialGroup()
                    .addGap(0, 0, Short.MAX_VALUE)
                    .addComponent(elevatorModePanel, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addGap(0, 0, Short.MAX_VALUE)))
            .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                .addGroup(layout.createSequentialGroup()
                    .addGap(0, 0, Short.MAX_VALUE)
                    .addComponent(oneminquestModePanel, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addGap(0, 0, Short.MAX_VALUE)))
            .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                .addGroup(layout.createSequentialGroup()
                    .addGap(0, 0, Short.MAX_VALUE)
                    .addComponent(bombModePanel, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addGap(0, 0, Short.MAX_VALUE)))
            .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                .addGroup(layout.createSequentialGroup()
                    .addGap(0, 0, Short.MAX_VALUE)
                    .addComponent(survivalModePanel, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addGap(0, 0, Short.MAX_VALUE)))
            .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                .addGroup(layout.createSequentialGroup()
                    .addGap(0, 0, Short.MAX_VALUE)
                    .addComponent(ftfModePanel, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addGap(0, 0, Short.MAX_VALUE)))
            .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                .addGroup(layout.createSequentialGroup()
                    .addGap(0, 0, Short.MAX_VALUE)
                    .addComponent(gamblingModePanel, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addGap(0, 0, Short.MAX_VALUE)))
            .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                .addGroup(layout.createSequentialGroup()
                    .addGap(0, 0, Short.MAX_VALUE)
                    .addComponent(quickGamePanel, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addGap(0, 0, Short.MAX_VALUE)))
            .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                .addGroup(layout.createSequentialGroup()
                    .addGap(0, 0, Short.MAX_VALUE)
                    .addComponent(quickGRoundSelectPanel, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addGap(0, 0, Short.MAX_VALUE)))
            .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                .addGroup(layout.createSequentialGroup()
                    .addGap(0, 0, Short.MAX_VALUE)
                    .addComponent(modeCatSelPanel, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addGap(0, 0, Short.MAX_VALUE)))
            .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                .addGroup(layout.createSequentialGroup()
                    .addGap(0, 0, Short.MAX_VALUE)
                    .addComponent(scoreTablePanel, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addGap(0, 0, Short.MAX_VALUE)))
            .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                .addGroup(layout.createSequentialGroup()
                    .addGap(0, 0, Short.MAX_VALUE)
                    .addComponent(finalQPanel, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addGap(0, 0, Short.MAX_VALUE)))
            .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                .addGroup(layout.createSequentialGroup()
                    .addGap(0, 0, Short.MAX_VALUE)
                    .addComponent(winnerPanel, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addGap(0, 0, Short.MAX_VALUE)))
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(openPanel, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
            .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                .addGroup(layout.createSequentialGroup()
                    .addGap(0, 0, Short.MAX_VALUE)
                    .addComponent(mainMenuPanel, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addGap(0, 0, Short.MAX_VALUE)))
            .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                .addGroup(layout.createSequentialGroup()
                    .addGap(0, 0, Short.MAX_VALUE)
                    .addComponent(playerNamePanel, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addGap(0, 0, Short.MAX_VALUE)))
            .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                .addGroup(layout.createSequentialGroup()
                    .addGap(0, 0, Short.MAX_VALUE)
                    .addComponent(classicModePanel, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addGap(0, 0, Short.MAX_VALUE)))
            .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                .addGroup(layout.createSequentialGroup()
                    .addGap(0, 0, Short.MAX_VALUE)
                    .addComponent(timeattackModePanel, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addGap(0, 0, Short.MAX_VALUE)))
            .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                .addGroup(layout.createSequentialGroup()
                    .addGap(0, 0, Short.MAX_VALUE)
                    .addComponent(elevatorModePanel, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addGap(0, 0, Short.MAX_VALUE)))
            .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                .addGroup(layout.createSequentialGroup()
                    .addGap(0, 0, Short.MAX_VALUE)
                    .addComponent(oneminquestModePanel, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addGap(0, 0, Short.MAX_VALUE)))
            .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                .addGroup(layout.createSequentialGroup()
                    .addGap(0, 0, Short.MAX_VALUE)
                    .addComponent(bombModePanel, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addGap(0, 0, Short.MAX_VALUE)))
            .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                .addGroup(layout.createSequentialGroup()
                    .addGap(0, 0, Short.MAX_VALUE)
                    .addComponent(survivalModePanel, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addGap(0, 0, Short.MAX_VALUE)))
            .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                .addGroup(layout.createSequentialGroup()
                    .addGap(0, 0, Short.MAX_VALUE)
                    .addComponent(ftfModePanel, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addGap(0, 0, Short.MAX_VALUE)))
            .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                .addGroup(layout.createSequentialGroup()
                    .addGap(0, 0, Short.MAX_VALUE)
                    .addComponent(gamblingModePanel, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addGap(0, 0, Short.MAX_VALUE)))
            .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                .addGroup(layout.createSequentialGroup()
                    .addGap(0, 0, Short.MAX_VALUE)
                    .addComponent(quickGamePanel, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addGap(0, 0, Short.MAX_VALUE)))
            .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                .addGroup(layout.createSequentialGroup()
                    .addGap(0, 0, Short.MAX_VALUE)
                    .addComponent(quickGRoundSelectPanel, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addGap(0, 0, Short.MAX_VALUE)))
            .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                .addGroup(layout.createSequentialGroup()
                    .addGap(0, 0, Short.MAX_VALUE)
                    .addComponent(modeCatSelPanel, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addGap(0, 0, Short.MAX_VALUE)))
            .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                .addGroup(layout.createSequentialGroup()
                    .addGap(0, 0, Short.MAX_VALUE)
                    .addComponent(scoreTablePanel, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addGap(0, 0, Short.MAX_VALUE)))
            .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                .addGroup(layout.createSequentialGroup()
                    .addGap(0, 0, Short.MAX_VALUE)
                    .addComponent(finalQPanel, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addGap(0, 0, Short.MAX_VALUE)))
            .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                .addGroup(layout.createSequentialGroup()
                    .addGap(0, 0, Short.MAX_VALUE)
                    .addComponent(winnerPanel, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addGap(0, 0, Short.MAX_VALUE)))
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void changePanels(javax.swing.JPanel p1,javax.swing.JPanel p2){
        p1.setVisible(false);
        getContentPane().removeAll();
        getContentPane().add(p2);
        p2.setVisible(true);
    }
    
    private void openPanelStartBtnActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_openPanelStartBtnActionPerformed
        changePanels(openPanel,mainMenuPanel);
    }//GEN-LAST:event_openPanelStartBtnActionPerformed

    private void quickGameBtnActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_quickGameBtnActionPerformed
        changePanels(mainMenuPanel,playerNamePanel);
        //Δημιούργησε αντικείμενο τύπου Quick Game.
    }//GEN-LAST:event_quickGameBtnActionPerformed

    private void arcadeGameBtnActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_arcadeGameBtnActionPerformed
        changePanels(mainMenuPanel,playerNamePanel);
        //Δημιούργησε αντικείμενο τύπου Arcade Game.
    }//GEN-LAST:event_arcadeGameBtnActionPerformed

    private void playerNameBackBtnActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_playerNameBackBtnActionPerformed
        changePanels(playerNamePanel,mainMenuPanel);
    }//GEN-LAST:event_playerNameBackBtnActionPerformed

    private void quickGRoundSelectRadioBtn1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_quickGRoundSelectRadioBtn1ActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_quickGRoundSelectRadioBtn1ActionPerformed

    private void quickGRoundSelectRadioBtn2ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_quickGRoundSelectRadioBtn2ActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_quickGRoundSelectRadioBtn2ActionPerformed

    private void quickGRoundSelectRadioBtn3ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_quickGRoundSelectRadioBtn3ActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_quickGRoundSelectRadioBtn3ActionPerformed

    private void quickGRoundSelectRadioBtn4ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_quickGRoundSelectRadioBtn4ActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_quickGRoundSelectRadioBtn4ActionPerformed

    private void quickGRoundSelectRadioBtn5ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_quickGRoundSelectRadioBtn5ActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_quickGRoundSelectRadioBtn5ActionPerformed

    /*private void gameTypeChoiceActionPerformed(java.awt.event.ActionEvent evt){
        if(evt.getSource(quickGameBtn))
        {
            changePanels(mainMenuPanel,playerNamePanel);
            //Δημιούργησε αντικείμενο τύπου Quick Game.
        }
        else if(evt.getSource().equals(arcadeGameBtn))
        {
            changePanels(mainMenuPanel,playerNamePanel);
            //Δημιούργησε αντικείμενο τύπου Arcade Game.
        }
    }
    */

    public static void main(String args[]) {
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(GUI.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(GUI.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(GUI.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(GUI.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
       


        java.awt.EventQueue.invokeLater(new Runnable() {
            @Override
            public void run() {
                new GUI().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton arcadeGameBtn;
    private javax.swing.JLabel bombModeAInfoLabel;
    private javax.swing.JButton bombModeAnswer1;
    private javax.swing.JButton bombModeAnswer2;
    private javax.swing.JButton bombModeAnswer3;
    private javax.swing.JButton bombModeAnswer4;
    private javax.swing.JLabel bombModeAnswerLabel;
    private javax.swing.JPanel bombModeAnswerPanel;
    private javax.swing.JPanel bombModeGeneralPanel;
    private javax.swing.JPanel bombModeGeneralPanel2;
    private javax.swing.JPanel bombModeInfoPanel;
    private javax.swing.JLabel bombModeNoOfAnsLabel;
    private javax.swing.JPanel bombModePanel;
    private javax.swing.JLabel bombModePlayerLabel2;
    private javax.swing.JLabel bombModeQuestionLabel1;
    private javax.swing.JPanel bombModeQuestionPanel;
    private javax.swing.JScrollPane bombModeQuestionScrollPane;
    private javax.swing.JTextArea bombModeQuestionTextArea;
    private javax.swing.JLabel bombModeTitleLabel1;
    private javax.swing.JLabel bombModeTitleLabel2;
    private javax.swing.JPanel bombModeTitlePanel;
    private javax.swing.JButton classicModeAnswer1;
    private javax.swing.JButton classicModeAnswer2;
    private javax.swing.JButton classicModeAnswer3;
    private javax.swing.JButton classicModeAnswer4;
    private javax.swing.JLabel classicModeAnswerLabel;
    private javax.swing.JPanel classicModeAnswerPanel;
    private javax.swing.JPanel classicModeGeneralPanel;
    private javax.swing.JPanel classicModePanel;
    private javax.swing.JLabel classicModePlayerLabel;
    private javax.swing.JLabel classicModeQuestionLabel;
    private javax.swing.JPanel classicModeQuestionPanel;
    private javax.swing.JScrollPane classicModeQuestionScrollPane;
    private javax.swing.JTextArea classicModeQuestionTextArea;
    private javax.swing.JLabel classicModeTitleLabel1;
    private javax.swing.JLabel classicModeTitleLabel2;
    private javax.swing.JPanel classicModeTitlePanel;
    private javax.swing.JButton elevatorModeAnswer1;
    private javax.swing.JButton elevatorModeAnswer2;
    private javax.swing.JButton elevatorModeAnswer3;
    private javax.swing.JButton elevatorModeAnswer4;
    private javax.swing.JLabel elevatorModeAnswerLabel;
    private javax.swing.JPanel elevatorModeAnswerPanel;
    private javax.swing.JLabel elevatorModeCountInfoLabel;
    private javax.swing.JLabel elevatorModeCountLabel;
    private javax.swing.JPanel elevatorModeGeneralPanel1;
    private javax.swing.JPanel elevatorModeGeneralPanel2;
    private javax.swing.JPanel elevatorModeGeneralPanel3;
    private javax.swing.JPanel elevatorModeInfoPanel;
    private javax.swing.JLabel elevatorModeNoOfQuestLabel;
    private javax.swing.JPanel elevatorModePanel;
    private javax.swing.JLabel elevatorModePlayerLabel;
    private javax.swing.JLabel elevatorModeQInfoLabel;
    private javax.swing.JLabel elevatorModeQuestionLabel;
    private javax.swing.JPanel elevatorModeQuestionPanel;
    private javax.swing.JScrollPane elevatorModeQuestionScrollPane;
    private javax.swing.JTextArea elevatorModeQuestionTextArea;
    private javax.swing.JLabel elevatorModeTitleLabel1;
    private javax.swing.JLabel elevatorModeTitleLabel2;
    private javax.swing.JPanel elevatorModeTitlePanel;
    private javax.swing.JButton finalQAnswer1;
    private javax.swing.JButton finalQAnswer2;
    private javax.swing.JButton finalQAnswer3;
    private javax.swing.JButton finalQAnswer4;
    private javax.swing.JLabel finalQAnswerLabel;
    private javax.swing.JPanel finalQAnswerPanel;
    private javax.swing.JPanel finalQGeneralPanel;
    private javax.swing.JPanel finalQPanel;
    private javax.swing.JLabel finalQPlayerLabel;
    private javax.swing.JLabel finalQQuestionLabel;
    private javax.swing.JPanel finalQQuestionPanel;
    private javax.swing.JScrollPane finalQQuestionScrollPane;
    private javax.swing.JTextArea finalQQuestionTextArea;
    private javax.swing.JLabel finalQTitleLabel;
    private javax.swing.JPanel finalQTitlePanel;
    private javax.swing.JLabel ftfModeAInfoLabel;
    private javax.swing.JButton ftfModeAnswer1;
    private javax.swing.JButton ftfModeAnswer2;
    private javax.swing.JButton ftfModeAnswer3;
    private javax.swing.JButton ftfModeAnswer4;
    private javax.swing.JLabel ftfModeAnswerLabel;
    private javax.swing.JPanel ftfModeAnswerPanel;
    private javax.swing.JPanel ftfModeGeneralPanel;
    private javax.swing.JPanel ftfModeInfoPanel;
    private javax.swing.JLabel ftfModeNoOfAnsLabel;
    private javax.swing.JPanel ftfModePanel;
    private javax.swing.JLabel ftfModePlayerLabel;
    private javax.swing.JLabel ftfModeQuestionLabel;
    private javax.swing.JPanel ftfModeQuestionPanel;
    private javax.swing.JScrollPane ftfModeQuestionScrollPane;
    private javax.swing.JTextArea ftfModeQuestionTextArea;
    private javax.swing.JLabel ftfModeTitleLabel1;
    private javax.swing.JLabel ftfModeTitleLabel2;
    private javax.swing.JPanel ftfModeTitlePanel;
    private javax.swing.JPanel gamblingModePanel;
    private javax.swing.JPanel mainMenuBtnPanel;
    private javax.swing.JPanel mainMenuLabelPanel;
    private javax.swing.JPanel mainMenuPanel;
    private javax.swing.JPanel mainMenuPanel2;
    private javax.swing.JLabel mainMenuTitleLabel;
    private javax.swing.JRadioButton modeCatSelCatBtn1;
    private javax.swing.JRadioButton modeCatSelCatBtn2;
    private javax.swing.JRadioButton modeCatSelCatBtn3;
    private javax.swing.JRadioButton modeCatSelCatBtn4;
    private javax.swing.JRadioButton modeCatSelCatBtn5;
    private javax.swing.JRadioButton modeCatSelCatBtn6;
    private javax.swing.JRadioButton modeCatSelCatBtn7;
    private javax.swing.JRadioButton modeCatSelCatBtn8;
    private javax.swing.JLabel modeCatSelCatLabel;
    private javax.swing.JPanel modeCatSelCatPanel;
    private javax.swing.JPanel modeCatSelGeneralPanel;
    private javax.swing.JPanel modeCatSelMCPanel;
    private javax.swing.JRadioButton modeCatSelModeBtn1;
    private javax.swing.JRadioButton modeCatSelModeBtn2;
    private javax.swing.JRadioButton modeCatSelModeBtn3;
    private javax.swing.JRadioButton modeCatSelModeBtn4;
    private javax.swing.JRadioButton modeCatSelModeBtn5;
    private javax.swing.JRadioButton modeCatSelModeBtn6;
    private javax.swing.JLabel modeCatSelModeLabel;
    private javax.swing.JPanel modeCatSelModePanel;
    private javax.swing.JButton modeCatSelNextBtn;
    private javax.swing.JPanel modeCatSelPanel;
    private javax.swing.JLabel modeCatSelTitleLabel;
    private javax.swing.JPanel modeCatSelTitlePanel;
    private javax.swing.JLabel oneminquestModeAInfoLabel;
    private javax.swing.JButton oneminquestModeAnswer1;
    private javax.swing.JButton oneminquestModeAnswer2;
    private javax.swing.JButton oneminquestModeAnswer3;
    private javax.swing.JButton oneminquestModeAnswer4;
    private javax.swing.JLabel oneminquestModeAnswerLabel;
    private javax.swing.JPanel oneminquestModeAnswerPanel;
    private javax.swing.JPanel oneminquestModeGeneralPanel;
    private javax.swing.JPanel oneminquestModeInfoPanel;
    private javax.swing.JLabel oneminquestModeNoOfAnsLabel;
    private javax.swing.JPanel oneminquestModePanel;
    private javax.swing.JLabel oneminquestModePlayerLabel;
    private javax.swing.JLabel oneminquestModeQuestionLabel;
    private javax.swing.JPanel oneminquestModeQuestionPanel;
    private javax.swing.JScrollPane oneminquestModeQuestionScrollPane;
    private javax.swing.JTextArea oneminquestModeQuestionTextArea;
    private javax.swing.JLabel oneminquestModeTimeInfoLabel;
    private javax.swing.JLabel oneminquestModeTimeLabel;
    private javax.swing.JLabel oneminquestModeTitleLabel1;
    private javax.swing.JLabel oneminquestModeTitleLabel2;
    private javax.swing.JPanel oneminquestModeTitlePanel;
    private javax.swing.JPanel openPanel;
    private javax.swing.JPanel openPanel1;
    private javax.swing.JLabel openPanelIconLabel;
    private javax.swing.JButton openPanelStartBtn;
    private javax.swing.JLabel openPanelTitleLabel;
    private javax.swing.JButton playerNameBackBtn;
    private javax.swing.JButton playerNameBeginBtn;
    private javax.swing.JPanel playerNameGeneralPanel;
    private javax.swing.JPanel playerNameInfoPanel1;
    private javax.swing.JPanel playerNameInfoPanel2;
    private javax.swing.JPanel playerNameInfoPanel3;
    private javax.swing.JPanel playerNameInfoPanel4;
    private javax.swing.JPanel playerNamePanel;
    private javax.swing.JTextField playerNamePlayer1Field;
    private javax.swing.JLabel playerNamePlayer1Label;
    private javax.swing.JTextField playerNamePlayer2Field;
    private javax.swing.JLabel playerNamePlayer2Label;
    private javax.swing.JTextField playerNamePlayer3Field;
    private javax.swing.JLabel playerNamePlayer3Label;
    private javax.swing.JTextField playerNamePlayer4Field;
    private javax.swing.JLabel playerNamePlayer4Label;
    private javax.swing.JLabel playerNameTitleLabel;
    private javax.swing.JPanel playerNameTitlePanel;
    private javax.swing.JPanel quickGRoundSelectCheckPanel;
    private javax.swing.JPanel quickGRoundSelectGeneralPanel;
    private javax.swing.JLabel quickGRoundSelectNoOfRLabel;
    private javax.swing.JPanel quickGRoundSelectPanel;
    private javax.swing.JRadioButton quickGRoundSelectRadioBtn1;
    private javax.swing.JRadioButton quickGRoundSelectRadioBtn2;
    private javax.swing.JRadioButton quickGRoundSelectRadioBtn3;
    private javax.swing.JRadioButton quickGRoundSelectRadioBtn4;
    private javax.swing.JRadioButton quickGRoundSelectRadioBtn5;
    private javax.swing.JLabel quickGRoundSelectTitleLabel;
    private javax.swing.JPanel quickGRoundSelectTitlePanel;
    private javax.swing.JButton quickGameAnswer1;
    private javax.swing.JButton quickGameAnswer2;
    private javax.swing.JButton quickGameAnswer3;
    private javax.swing.JButton quickGameAnswer4;
    private javax.swing.JLabel quickGameAnswerLabel;
    private javax.swing.JPanel quickGameAnswerPanel;
    private javax.swing.JButton quickGameBtn;
    private javax.swing.JPanel quickGameGeneralPanel;
    private javax.swing.JPanel quickGamePanel;
    private javax.swing.JLabel quickGamePlayerLabel;
    private javax.swing.JLabel quickGameQuestionLabel;
    private javax.swing.JPanel quickGameQuestionPanel;
    private javax.swing.JScrollPane quickGameQuestionScrollPane;
    private javax.swing.JTextArea quickGameQuestionTextArea;
    private javax.swing.JLabel quickGameTitleLabel1;
    private javax.swing.JLabel quickGameTitleLabel2;
    private javax.swing.JPanel quickGameTitlePanel;
    private javax.swing.JPanel scoreTableGeneralPanel;
    private javax.swing.JPanel scoreTableInfoPanel;
    private javax.swing.JButton scoreTableNextBtn;
    private javax.swing.JLabel scoreTableP1NameLabel;
    private javax.swing.JPanel scoreTableP1Panel;
    private javax.swing.JLabel scoreTableP1PointsLabel;
    private javax.swing.JLabel scoreTableP2NameLabel;
    private javax.swing.JPanel scoreTableP2Panel;
    private javax.swing.JLabel scoreTableP2PointsLabel;
    private javax.swing.JLabel scoreTableP3NameLabel;
    private javax.swing.JPanel scoreTableP3Panel;
    private javax.swing.JLabel scoreTableP3PointsLabel;
    private javax.swing.JLabel scoreTableP4NameLabel;
    private javax.swing.JPanel scoreTableP4Panel;
    private javax.swing.JLabel scoreTableP4PointsLabel;
    private javax.swing.JPanel scoreTablePanel;
    private javax.swing.JLabel scoreTableTitleLabel;
    private javax.swing.JPanel scoreTableTitlePanel;
    private javax.swing.JButton survivalModeAnswer1;
    private javax.swing.JButton survivalModeAnswer2;
    private javax.swing.JButton survivalModeAnswer3;
    private javax.swing.JButton survivalModeAnswer4;
    private javax.swing.JLabel survivalModeAnswerLabel;
    private javax.swing.JPanel survivalModeAnswerPanel;
    private javax.swing.JPanel survivalModeGeneralPanel;
    private javax.swing.JPanel survivalModeInfoPanel;
    private javax.swing.JLabel survivalModeLifeInfoLabel;
    private javax.swing.JLabel survivalModeLifeLabel;
    private javax.swing.JLabel survivalModeNoOfQuestLabel;
    private javax.swing.JPanel survivalModePanel;
    private javax.swing.JLabel survivalModePlayerLabel;
    private javax.swing.JLabel survivalModeQInfoLabel;
    private javax.swing.JLabel survivalModeQuestionLabel1;
    private javax.swing.JPanel survivalModeQuestionPanel;
    private javax.swing.JScrollPane survivalModeQuestionScrollPane;
    private javax.swing.JTextArea survivalModeQuestionTextArea;
    private javax.swing.JLabel survivalModeTitleLabel1;
    private javax.swing.JLabel survivalModeTitleLabel2;
    private javax.swing.JPanel survivalModeTitlePanel;
    private javax.swing.JButton timeattackModeAnswer1;
    private javax.swing.JButton timeattackModeAnswer2;
    private javax.swing.JButton timeattackModeAnswer3;
    private javax.swing.JButton timeattackModeAnswer4;
    private javax.swing.JLabel timeattackModeAnswerLabel;
    private javax.swing.JPanel timeattackModeAnswerPanel;
    private javax.swing.JPanel timeattackModeGeneralPanel;
    private javax.swing.JPanel timeattackModeGeneralPanel2;
    private javax.swing.JPanel timeattackModeInfoPanel;
    private javax.swing.JLabel timeattackModeNoOfQuestLabel;
    private javax.swing.JPanel timeattackModePanel;
    private javax.swing.JLabel timeattackModePlayerLabel;
    private javax.swing.JLabel timeattackModeQInfoLabel;
    private javax.swing.JLabel timeattackModeQuestionLabel;
    private javax.swing.JPanel timeattackModeQuestionPanel;
    private javax.swing.JScrollPane timeattackModeQuestionScrollPane;
    private javax.swing.JLabel timeattackModeTimeInfoLabel;
    private javax.swing.JLabel timeattackModeTimeLabel;
    private javax.swing.JLabel timeattackModeTitleLabel1;
    private javax.swing.JLabel timeattackModeTitleLabel2;
    private javax.swing.JPanel timeattackModeTitlePanel;
    private javax.swing.JTextArea timeattackQuestionTextArea;
    private javax.swing.JPanel winnerGeneralPanel;
    private javax.swing.JPanel winnerInfoPanel;
    private javax.swing.JLabel winnerLabel;
    private javax.swing.JButton winnerMMenutBtn;
    private javax.swing.JLabel winnerP1NameLabel;
    private javax.swing.JPanel winnerP1Panel;
    private javax.swing.JLabel winnerP1PointsLabel;
    private javax.swing.JLabel winnerP2NameLabel;
    private javax.swing.JPanel winnerP2Panel;
    private javax.swing.JLabel winnerP2PointsLabel;
    private javax.swing.JLabel winnerP3NameLabel;
    private javax.swing.JPanel winnerP3Panel;
    private javax.swing.JLabel winnerP3PointsLabel;
    private javax.swing.JLabel winnerP4NameLabel;
    private javax.swing.JPanel winnerP4Panel;
    private javax.swing.JLabel winnerP4PointsLabel;
    private javax.swing.JPanel winnerPanel;
    private javax.swing.JLabel winnerTitleLabel;
    private javax.swing.JPanel winnerTitlePanel;
    // End of variables declaration//GEN-END:variables
}
